"""assets/servers.txt  ->  assets/servers.enc  (AES-256-GCM) ; کلید = SHA256(APP_KEY)"""
import base64
import hashlib
import os
import re

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

app_key = os.environ.get("APP_KEY") or "AlvlIRm-VPN-default-key"
key = hashlib.sha256(app_key.encode("utf-8")).digest()

src = "assets/servers.txt"
data = ""
if os.path.exists(src):
    data = open(src, encoding="utf-8", errors="ignore").read()

nonce = os.urandom(12)
blob = nonce + AESGCM(key).encrypt(nonce, data.encode("utf-8"), None)
os.makedirs("assets", exist_ok=True)
with open("assets/servers.enc", "w") as f:
    f.write(base64.b64encode(blob).decode())
print("seed encrypted, links:", len(re.findall(r"://", data)),
      "| custom APP_KEY:", bool(os.environ.get("APP_KEY")))
