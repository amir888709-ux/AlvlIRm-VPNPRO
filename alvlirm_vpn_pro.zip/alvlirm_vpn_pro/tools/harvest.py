"""جمع‌آوری خودکار سرور از کانال‌های تلگرام + تست سلامت + بروزرسانی لیست رسمی برنامه.

هر اجرا:
  1) لیست فعلی را از Supabase می‌خواند و رمزگشایی می‌کند
  2) سرورهای فعلی را تست می‌کند و مرده‌ها را حذف می‌کند
  3) از کانال‌های tools/channels.txt سرور جدید می‌گیرد، تست می‌کند و اضافه می‌کند
  4) اگر تغییر به اندازه‌ی کافی بود، لیست رمزشده را در Supabase می‌نویسد
تست = اتصال TCP (و دست‌دادن TLS برای لینک‌های TLS/Reality). تست پروتکلی کامل نیست.
"""
import asyncio
import base64
import hashlib
import html
import json
import os
import re
import socket
import ssl
import sys
import time
import urllib.parse
import urllib.request

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

URL = os.environ.get("SUPABASE_URL", "").rstrip("/")
KEY = os.environ.get("SUPABASE_KEY", "")
APP_KEY = os.environ.get("APP_KEY") or "AlvlIRm-VPN-default-key"
ADMIN = os.environ.get("ADMIN_PASSWORD", "")
MAX_SERVERS = int(os.environ.get("MAX_SERVERS") or 30)
MIN_CHANGE = int(os.environ.get("MIN_CHANGE") or 5)
PAGES = int(os.environ.get("PAGES") or 5)
IRAN_CHECK = os.environ.get("IRAN_CHECK", "0") == "1"  # check-host غیرفعال (نتیجه‌ی قابل اعتماد نمی‌داد)
# فقط این پروتکل‌ها نگه داشته می‌شوند (جدا با ویرگول) ؛ خالی = همه
PROTOS = {x.strip().lower() for x in os.environ.get("PROTOCOLS", "vless").split(",") if x.strip()}
MAX_CHECK = int(os.environ.get("MAX_CHECK") or 60)
DRY = os.environ.get("DRY_RUN") == "1"

SCHEMES = ("vless", "vmess", "trojan", "ss")
POOL = []  # کاندیدهای این اجرا
LINK_RE = re.compile(r"(?:vless|vmess|trojan|ss)://[^\s<>\"'`]+", re.I)
AES = AESGCM(hashlib.sha256(APP_KEY.encode()).digest())


def log(*a):
    print(*a, flush=True)


# ---------------------------------------------------------------- Supabase
def rpc(fn, body):
    req = urllib.request.Request(
        f"{URL}/rest/v1/rpc/{fn}", data=json.dumps(body).encode(), method="POST"
    )
    req.add_header("apikey", KEY)
    if KEY.startswith("eyJ"):
        req.add_header("Authorization", f"Bearer {KEY}")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=30) as r:
        t = r.read().decode()
    return json.loads(t) if t else None


def decrypt(blob):
    raw = base64.b64decode(blob)
    return AES.decrypt(raw[:12], raw[12:], None).decode("utf-8", "ignore")


def encrypt(text):
    n = os.urandom(12)
    return base64.b64encode(n + AES.encrypt(n, text.encode(), None)).decode()


# ---------------------------------------------------------------- parsing
def b64d(s):
    s = s.strip().replace("-", "+").replace("_", "/")
    s += "=" * (-len(s) % 4)
    return base64.b64decode(s).decode("utf-8", "ignore")


def clean(link):
    link = html.unescape(link).strip().rstrip(".,;)")
    return link


def info(link):
    """-> dict(host, port, tls, sni, key) یا None"""
    try:
        sch = link.split("://", 1)[0].lower()
        if sch == "vmess":
            j = json.loads(b64d(link[8:].split("#")[0]))
            host = str(j.get("add", ""))
            port = int(j.get("port", 0))
            tls = str(j.get("tls", "")).lower() in ("tls", "reality")
            sni = j.get("sni") or j.get("host") or host
            fp = "|".join([host.lower(), str(port), str(j.get("host", "")).lower(),
                           str(j.get("path", "")), str(j.get("net", ""))])
            return dict(host=host, port=port, tls=tls, sni=sni, key=str(j.get("id", "")), sch=sch, fp=fp)
        if sch == "ss":
            body = link[5:].split("#")[0]
            body = body.split("?")[0].split("/")[0] if "@" in body else body
            if "@" in body:
                user, hp = body.rsplit("@", 1)
            else:
                dec = b64d(body)
                user, hp = dec.rsplit("@", 1)
            host, port = hp.rsplit(":", 1)
            return dict(host=host.strip("[]"), port=int(port), tls=False, sni="", key=user, sch=sch,
                        fp=f"{host.strip('[]').lower()}|{int(port)}")
        u = urllib.parse.urlsplit(link)
        q = dict(urllib.parse.parse_qsl(u.query))
        sec = q.get("security", "").lower()
        tls = sec in ("tls", "reality", "xtls") or (sch == "trojan" and sec != "none")
        sni = q.get("sni") or q.get("host") or u.hostname
        fp = "|".join([(u.hostname or "").lower(), str(u.port or 0), q.get("host", "").lower(),
                       q.get("sni", "").lower(), q.get("path", ""), q.get("type", ""),
                       q.get("serviceName", "")])
        return dict(host=u.hostname or "", port=u.port or 0, tls=tls, sni=sni,
                    key=urllib.parse.unquote(u.username or ""), sch=sch, fp=fp)
    except Exception:
        return None


def ident(link, i):
    return i["fp"]


# ---------------------------------------------------------------- tests
async def probe(i, timeout=5.0):
    """زمان اتصال به میلی‌ثانیه یا None"""
    t0 = time.monotonic()
    ctx = None
    if i["tls"]:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    try:
        r, w = await asyncio.wait_for(
            asyncio.open_connection(
                i["host"], i["port"], ssl=ctx,
                server_hostname=(i["sni"] or i["host"]) if ctx else None),
            timeout)
        w.close()
        try:
            await w.wait_closed()
        except Exception:
            pass
        return int((time.monotonic() - t0) * 1000)
    except Exception:
        return None


async def test_all(items, tries=2, conc=80):
    sem = asyncio.Semaphore(conc)

    async def one(link, i):
        async with sem:
            for _ in range(tries):
                ms = await probe(i)
                if ms is not None:
                    return ms
                await asyncio.sleep(0.3)
            return None

    res = await asyncio.gather(*(one(l, i) for l, i in items))
    return res


# ---------------------------------------------------------------- Iran check
# تست اتصال TCP از نودهای ایران سرویس check-host.net (رایگان ؛ فقط اتصال IP/پورت)
CH = "https://check-host.net"


CH_FAILS = [0]  # تعداد شکست‌های پشت‌سرهم (۴۲۹ و ...)


def ch_get(path):
    """درخواست به check-host؛ روی ۴۲۹ صبر و دوباره تلاش می‌کند"""
    if CH_FAILS[0] >= 4:
        raise RuntimeError("check-host rate limit; skipped")
    last = None
    for wait in (0, 20, 45):
        if wait:
            time.sleep(wait)
        req = urllib.request.Request(CH + path, headers={
            "Accept": "application/json", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64)"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                CH_FAILS[0] = 0
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            last = e
            if e.code != 429:
                break
    CH_FAILS[0] += 1
    raise last


def iran_nodes():
    try:
        j = ch_get("/nodes/hosts")
        nodes = j.get("nodes", j)
        out = [n for n, v in nodes.items()
               if isinstance(v, dict) and str((v.get("location") or [""])[0]).lower() == "ir"]
        return sorted(out)[:4]
    except Exception as e:
        log("  ! check-host nodes:", e)
        return []


DBG = []


def dbg(msg):
    if len(DBG) < 6:
        DBG.append(msg)
        log("  [debug]", msg)


def iran_check(host, port, nodes):
    """-> (ok: bool|None, ms: int|None) ؛ None = نتیجه‌ی نامعلوم"""
    try:
        q = urllib.parse.urlencode([("host", f"{host}:{port}")] + [("node", n) for n in nodes])
        j = ch_get("/check-tcp?" + q)
        rid = j.get("request_id")
        if not rid:
            dbg(f"no request_id: {str(j)[:200]}")
            return None, None
        r = {}
        time.sleep(6)
        for _ in range(6):
            r = ch_get("/check-result/" + rid)
            if r and all(v is not None for v in r.values()):
                break
            time.sleep(3)
        oks, fails = [], 0
        for v in r.values():
            if not v:
                continue
            e = v[0] if isinstance(v, list) and v else None
            if isinstance(e, dict) and "time" in e:
                oks.append(e["time"] * 1000)
            elif isinstance(e, dict) and "error" in e:
                fails += 1
        total = len(oks) + fails
        if total == 0:
            dbg(f"no usable result for {host}:{port}: {str(r)[:300]}")
            return None, None
        ok = len(oks) * 2 >= total  # حداقل نصف نودهای ایران وصل شوند
        ms = int(sorted(oks)[len(oks) // 2]) if oks else None
        return ok, ms
    except Exception as ex:
        dbg(f"error for {host}:{port}: {ex}")
        return None, None


def iran_filter(entries, nodes):
    """e['irok'] و e['ir'] را پر می‌کند؛ تعداد نتیجه‌های نامعلوم را برمی‌گرداند"""
    from concurrent.futures import ThreadPoolExecutor
    unknown = 0

    def one(e):
        time.sleep(3)  # فاصله بین درخواست‌ها برای جلوگیری از محدودیت سرعت
        return iran_check(e["i"]["host"], e["i"]["port"], nodes)

    with ThreadPoolExecutor(max_workers=1) as ex:
        for e, (ok, ms) in zip(entries, ex.map(one, entries)):
            e["irok"], e["ir"] = ok, ms
            if ok is None:
                unknown += 1
    return unknown


# ---------------------------------------------------------------- telegram
def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64)"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read().decode("utf-8", "ignore")


def scrape_channel(name):
    links, before = [], None
    for _ in range(PAGES):
        try:
            page = fetch(f"https://t.me/s/{name}" + (f"?before={before}" if before else ""))
        except Exception as e:
            log(f"  ! {name}: {e}")
            break
        text = html.unescape(re.sub(r"<br\s*/?>", "\n", page))
        links += [clean(m) for m in LINK_RE.findall(text)]
        ids = [int(x) for x in re.findall(r'data-post="[^"/]+/(\d+)"', page)]
        if not ids or min(ids) <= 1:
            break
        before = min(ids)
        time.sleep(1)
    return links


# ---------------------------------------------------------------- flags
def has_flag(s):
    r = [ord(c) for c in s]
    return any(0x1F1E6 <= a <= 0x1F1FF and 0x1F1E6 <= b <= 0x1F1FF for a, b in zip(r, r[1:]))


def flag(cc):
    return "".join(chr(0x1F1E6 + ord(c) - 65) for c in cc.upper())


def get_remark(link):
    if link.lower().startswith("vmess://"):
        try:
            return str(json.loads(b64d(link[8:])).get("ps", ""))
        except Exception:
            return ""
    return urllib.parse.unquote(link.split("#", 1)[1]) if "#" in link else ""


def set_remark(link, text):
    if link.lower().startswith("vmess://"):
        j = json.loads(b64d(link[8:].split("#")[0]))
        j["ps"] = text
        return "vmess://" + base64.b64encode(json.dumps(j, ensure_ascii=False).encode()).decode()
    return link.split("#", 1)[0] + "#" + urllib.parse.quote(text)


def add_flags(entries):
    """برای لینک‌هایی که پرچم ندارند، کشور را از IP پیدا می‌کند (ip-api.com)"""
    todo = [e for e in entries if not has_flag(get_remark(e["link"]))]
    if not todo:
        return
    ips = {}
    for e in todo:
        try:
            ips[e["i"]["host"]] = socket.gethostbyname(e["i"]["host"])
        except Exception:
            pass
    uniq = sorted(set(ips.values()))
    cc = {}
    for k in range(0, len(uniq), 100):
        chunk = uniq[k:k + 100]
        try:
            req = urllib.request.Request(
                "http://ip-api.com/batch?fields=query,countryCode",
                data=json.dumps(chunk).encode(), method="POST")
            with urllib.request.urlopen(req, timeout=30) as r:
                for row in json.loads(r.read().decode()):
                    if row.get("countryCode"):
                        cc[row["query"]] = row["countryCode"]
        except Exception as ex:
            log("  ! geo lookup:", ex)
        time.sleep(5)
    for e in todo:
        c = cc.get(ips.get(e["i"]["host"], ""))
        if c:
            old = get_remark(e["link"]) or e["i"]["host"]
            try:
                e["link"] = set_remark(e["link"], f"{flag(c)} {old}")
            except Exception:
                pass


# ---------------------------------------------------------------- main
def main():
    if not (URL and KEY):
        sys.exit("SUPABASE_URL / SUPABASE_KEY تنظیم نشده")
    if not ADMIN and not DRY:
        sys.exit("ADMIN_PASSWORD تنظیم نشده")

    meta = rpc("get_meta", {"p_device": "harvest-bot-000", "p_have": ""})
    blob = (meta or {}).get("servers", "") or ""
    current_text = decrypt(blob) if blob else ""
    current = [clean(l) for l in LINK_RE.findall(current_text)]
    other = [l.strip() for l in current_text.splitlines()
             if l.strip() and not LINK_RE.fullmatch(l.strip()) and "://" in l]  # hysteria/tuic/wg
    log(f"لیست فعلی: {len(current)} لینک قابل تست + {len(other)} لینک دیگر")

    cur_items = []
    proto_dropped = 0
    for l in current:
        i = info(l)
        if i and i["host"] and i["port"]:
            if PROTOS and i["sch"] not in PROTOS:
                proto_dropped += 1
                continue
            cur_items.append((l, i))
    if PROTOS and other:
        proto_dropped += len(other)
        other = []
    if PROTOS:
        log(f"فقط پروتکل: {', '.join(sorted(PROTOS))} ؛ {proto_dropped} لینک از نوع دیگر کنار گذاشته شد")
    res = asyncio.run(test_all(cur_items))
    alive, dead = [], []
    for (l, i), ms in zip(cur_items, res):
        (alive if ms is not None else dead).append({"link": l, "i": i, "ms": ms})
    log(f"سالم: {len(alive)} | مرده: {len(dead)}")

    # تکراری‌های لیست فعلی (همان آدرس/پورت/مسیر با UUID متفاوت) مستقیم حذف می‌شوند
    seen_fp, uniq = set(), []
    for e in alive:
        k = ident(e["link"], e["i"])
        if k in seen_fp:
            continue
        seen_fp.add(k)
        uniq.append(e)
    dup_dropped = len(alive) - len(uniq)
    alive = uniq
    if dup_dropped:
        log(f"تکراری حذف شد: {dup_dropped}")

    if cur_items and len(dead) > 0.8 * len(cur_items):
        sys.exit("بیش از ۸۰٪ سرورها خراب دیده شد؛ احتمالاً مشکل شبکه‌ی تست است. چیزی تغییر نکرد.")

    # تست از ایران: سرورهایی که از نودهای ایران وصل نمی‌شوند حذف می‌شوند
    nodes = iran_nodes() if IRAN_CHECK else []
    iran_on = bool(nodes)
    log("نودهای ایران:", nodes if nodes else "در دسترس نیست (فقط تست آمریکا)")
    if iran_on and alive:
        unk = iran_filter(alive, nodes)
        bad = [e for e in alive if e["irok"] is False]
        good = [e for e in alive if e["irok"] is True]
        log(f"نتیجه‌ی تست ایران: وصل {len(good)} | بسته {len(bad)} | نامعلوم {unk} (از {len(alive)})")
        if unk > 0.5 * len(alive) or len(bad) > 0.8 * len(alive):
            log("نتیجه‌ی تست ایران قابل اعتماد نیست؛ این بار اعمال نشد")
            iran_on = False
        else:
            dead += bad
            alive = [e for e in alive if e["irok"] is not False]
            log(f"بعد از تست ایران: سالم {len(alive)} | حذف‌شده از ایران {len(bad)}")

    # اگر لیست از سقف بزرگ‌تر است، سریع‌ترین‌ها (از دید ایران) می‌مانند
    keep_n = max(0, MAX_SERVERS - len(other))
    trimmed = 0
    if len(alive) > keep_n:
        trimmed = len(alive) - keep_n
        if iran_on:
            alive.sort(key=lambda e: (e.get("ir") is None, e.get("ir") or 0))
            alive = alive[:keep_n]
        else:
            alive = alive[trimmed:]
        log(f"بیش از سقف ({MAX_SERVERS}) ؛ {trimmed} سرور کنار گذاشته شد")

    seen = {ident(e["link"], e["i"]) for e in alive}
    # اولویت با فایل channels.txt در ریشه‌ی مخزن (خودت از گیت‌هاب ویرایشش می‌کنی)
    cfile = "channels.txt" if os.path.exists("channels.txt") else "tools/channels.txt"
    log("فایل کانال‌ها:", cfile)
    chans = []
    if os.path.exists(cfile):
        for x in open(cfile, encoding="utf-8"):
            x = x.strip()
            if not x or x.startswith("#"):
                continue
            x = re.sub(r"^https?://t\.me/(s/)?", "", x).lstrip("@").split("/")[0].split("?")[0]
            if x:
                chans.append(x)
    cand = []
    for ch in chans:
        got = scrape_channel(ch)
        log(f"  {ch}: {len(got)} لینک")
        for l in got:
            i = info(l)
            if not i or not i["host"] or not i["port"]:
                continue
            if PROTOS and i["sch"] not in PROTOS:
                continue
            k = ident(l, i)
            if k in seen:
                continue
            seen.add(k)
            cand.append((l, i))
    log(f"لینک جدید برای تست: {len(cand)}")
    new = []
    if cand:
        res = asyncio.run(test_all(cand, tries=1))
        new = [{"link": l, "i": i, "ms": ms} for (l, i), ms in zip(cand, res) if ms is not None]
        log(f"سالم از دید آمریکا: {len(new)}")
        # مخزن کاندید برای تست از ایران توسط خود مدیر (از داخل برنامه)
        pool = new[:150]
        add_flags(pool)
        POOL.extend(e["link"] for e in pool)
        if iran_on and new:
            new = new[:MAX_CHECK]  # تست ایران محدود است (جدیدترین‌ها)
            iran_filter(new, nodes)
            new = [e for e in new if e["irok"] is True]
            new.sort(key=lambda e: e["ir"] if e.get("ir") is not None else 1 << 30)
            log(f"وصل از ایران: {len(new)}")
    room = max(0, MAX_SERVERS - len(alive) - len(other))
    new = new[:room]
    add_flags(new)
    log(f"جدید و سالم (اضافه می‌شود): {len(new)}")

    change = len(dead) + len(new) + trimmed + proto_dropped + dup_dropped
    final = [e["link"] for e in alive] + [e["link"] for e in new] + other
    summary = (f"قبلی {len(current)+len(other)} | حذف {len(dead)+trimmed+proto_dropped+dup_dropped} | اضافه {len(new)} | نهایی {len(final)}")
    log(summary)
    sp = os.environ.get("GITHUB_STEP_SUMMARY")
    if sp:
        open(sp, "a", encoding="utf-8").write("### سرورها\n" + summary + "\n")

    if POOL and not DRY:
        try:
            rpc("admin_set", {"p_pass": ADMIN, "p_key": "candidates", "p_value": encrypt("\n".join(POOL))})
            log(f"مخزن کاندید: {len(POOL)} لینک")
        except Exception as ex:
            log("  ! نوشتن کاندیدها:", ex)

    if len(final) < min(10, MAX_SERVERS) and not DRY:
        sys.exit("لیست نهایی خیلی کوچک است؛ چیزی نوشته نشد.")
    if change < MIN_CHANGE and blob:
        log(f"تغییر کم ({change} < {MIN_CHANGE}) ؛ برای صرفه‌جویی در حجم Supabase چیزی نوشته نشد.")
        return
    if DRY:
        log("DRY_RUN: نوشته نشد")
        return
    ok = rpc("admin_set", {"p_pass": ADMIN, "p_key": "servers", "p_value": encrypt("\n".join(final))})
    if ok is not True:
        sys.exit("نوشتن در Supabase ناموفق بود (رمز مدیر؟)")
    log("لیست رسمی بروزرسانی شد ✔")


if __name__ == "__main__":
    main()
