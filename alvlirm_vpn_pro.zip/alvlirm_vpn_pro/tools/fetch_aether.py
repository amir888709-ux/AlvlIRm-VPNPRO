"""دانلود فایل اجرایی Aether (پروژه‌ی CluvexStudio/Aether) برای اندروید یا ویندوز.

  python tools/fetch_aether.py android          -> android/app/src/main/jniLibs/<abi>/libaether.so
  python tools/fetch_aether.py windows <پوشه>   -> <پوشه>/aether.exe
"""
import hashlib
import io
import json
import pathlib
import sys
import tarfile
import urllib.request
import zipfile

REPO = "CluvexStudio/Aether"
FALLBACK = "v2.3.0"


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "alvlirm-ci"})
    return urllib.request.urlopen(req, timeout=180).read()


def releases():
    try:
        rels = json.loads(get(f"https://api.github.com/repos/{REPO}/releases?per_page=10"))
        return [r for r in rels if not r.get("draft")]
    except Exception as e:
        print("release list failed:", e)
        return []


def find_asset(rels, token):
    for r in rels:
        for a in r.get("assets", []):
            n = a["name"].lower()
            if token in n and not n.endswith(".sha256"):
                return r["tag_name"], a
    return None, None


def pick_binary(names_sizes, want):
    """از بین فایل‌های بسته، فایل اجرایی را انتخاب می‌کند"""
    exact = [x for x in names_sizes if x[0].split("/")[-1].lower() in want]
    if exact:
        return exact[0][0]
    cand = [x for x in names_sizes if not x[0].lower().endswith((".md", ".txt", ".sha256", ".toml", ".bat"))]
    return max(cand, key=lambda x: x[1])[0] if cand else None


def android():
    rels = releases()
    out = pathlib.Path("android/app/src/main/jniLibs")
    for arch, abi in (("android-arm64", "arm64-v8a"), ("android-armv7", "armeabi-v7a"), ("android-x86_64", "x86_64")):
        tag, a = find_asset(rels, arch)
        if a is None:
            url = f"https://github.com/{REPO}/releases/download/{FALLBACK}/aether-{arch}.tar.gz"
            tag = FALLBACK
        else:
            url = a["browser_download_url"]
        data = get(url)
        try:
            sha = get(url + ".sha256").decode().split()[0].lower()
            if hashlib.sha256(data).hexdigest() != sha:
                sys.exit(f"sha256 mismatch for {arch}")
        except SystemExit:
            raise
        except Exception:
            print("  (no sha256 check)", arch)
        tf = tarfile.open(fileobj=io.BytesIO(data), mode="r:gz")
        files = [(m.name, m.size) for m in tf.getmembers() if m.isfile()]
        name = pick_binary(files, {"aether"})
        if not name:
            sys.exit(f"no binary found in {arch}: {files}")
        d = out / abi
        d.mkdir(parents=True, exist_ok=True)
        (d / "libaether.so").write_bytes(tf.extractfile(name).read())
        print(f"{abi}: {tag} {name} -> libaether.so ({(d / 'libaether.so').stat().st_size} bytes)")


def windows(dest):
    rels = releases()
    tag, a = find_asset(rels, "windows-x86_64")
    if a is None:
        url = f"https://github.com/{REPO}/releases/download/{FALLBACK}/aether-windows-x86_64.zip"
        tag = FALLBACK
    else:
        url = a["browser_download_url"]
    z = zipfile.ZipFile(io.BytesIO(get(url)))
    files = [(i.filename, i.file_size) for i in z.infolist() if not i.is_dir()]
    name = pick_binary(files, {"aether.exe"})
    if not name:
        sys.exit(f"no aether.exe in zip: {files}")
    d = pathlib.Path(dest)
    d.mkdir(parents=True, exist_ok=True)
    (d / "aether.exe").write_bytes(z.read(name))
    print("windows:", tag, name)


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "android":
        android()
    elif len(sys.argv) >= 3 and sys.argv[1] == "windows":
        windows(sys.argv[2])
    else:
        sys.exit(__doc__)
