Psiphon server list is placed here at build time (servers.txt).
