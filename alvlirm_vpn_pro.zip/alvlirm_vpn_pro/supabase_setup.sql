-- ======================================================================
--  AlvlIRm VPN  |  راه‌اندازی دیتابیس در Supabase
--  1) در Supabase یک پروژه‌ی جدید بساز
--  2) SQL Editor -> New query -> همین فایل را paste کن
--  3) رمز ادمین را در خط  'CHANGE_ME_PASSWORD'  عوض کن و Run بزن
-- ======================================================================
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.app_config (
  key   text primary key,
  value text not null default ''
);

create table if not exists public.devices (
  id   text primary key,
  seen timestamptz not null default now()
);

create table if not exists public.admin_secret (
  id   int primary key default 1,
  hash text not null
);

-- هیچ‌کس مستقیم به جدول‌ها دسترسی ندارد؛ فقط از طریق توابع پایین
alter table public.app_config   enable row level security;
alter table public.devices      enable row level security;
alter table public.admin_secret enable row level security;

insert into public.admin_secret (id, hash)
values (1, extensions.crypt('CHANGE_ME_PASSWORD', extensions.gen_salt('bf')))
on conflict (id) do update set hash = excluded.hash;

insert into public.app_config (key, value) values ('servers', ''), ('announcement', '')
on conflict (key) do nothing;

-- دریافت اطلاعات + ثبت حضور دستگاه
create or replace function public.get_meta(p_device text)
returns json
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_device is not null and length(p_device) between 8 and 64 then
    insert into devices (id, seen) values (p_device, now())
    on conflict (id) do update set seen = now();
  end if;
  return json_build_object(
    'servers',      coalesce((select value from app_config where key = 'servers'), ''),
    'announcement', coalesce((select value from app_config where key = 'announcement'), ''),
    'total',        (select count(*) from devices),
    'online',       (select count(*) from devices where seen > now() - interval '3 minutes')
  );
end;
$$;

create or replace function public.admin_check(p_pass text)
returns boolean
language sql
security definer
set search_path = public, extensions
as $$
  select exists (
    select 1 from admin_secret
    where id = 1 and hash = extensions.crypt(p_pass, hash)
  );
$$;

create or replace function public.admin_set(p_pass text, p_key text, p_value text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_key not in ('servers', 'announcement') then
    return false;
  end if;
  if not exists (select 1 from admin_secret where id = 1 and hash = extensions.crypt(p_pass, hash)) then
    return false;
  end if;
  insert into app_config (key, value) values (p_key, p_value)
  on conflict (key) do update set value = excluded.value;
  return true;
end;
$$;

revoke all on function public.get_meta(text)            from public;
revoke all on function public.admin_check(text)         from public;
revoke all on function public.admin_set(text,text,text) from public;
grant execute on function public.get_meta(text)            to anon, authenticated;
grant execute on function public.admin_check(text)         to anon, authenticated;
grant execute on function public.admin_set(text,text,text) to anon, authenticated;
