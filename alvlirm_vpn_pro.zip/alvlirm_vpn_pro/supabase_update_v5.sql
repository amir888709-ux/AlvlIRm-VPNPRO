-- بروزرسانی دیتابیس برای نسخه 1.2.2 (آپدیت جدا برای اندروید/ویندوز + حمایت مالی + کاندیدهای ربات)
-- فقط یک بار در Supabase > SQL Editor اجرا کن. رمز مدیر و اطلاعات قبلی دست نمی‌خورد.

drop function if exists public.get_meta(text);

create or replace function public.get_meta(p_device text, p_have text default '')
returns json
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  s text;
  v text;
begin
  if p_device is not null and length(p_device) between 8 and 64 then
    insert into devices (id, seen) values (p_device, now())
    on conflict (id) do update set seen = now();
  end if;
  select value into s from app_config where key = 'servers';
  s := coalesce(s, '');
  v := md5(s);
  return json_build_object(
    'ver',          v,
    'servers',      case when v = coalesce(p_have, '') then '' else s end,
    'announcement', coalesce((select value from app_config where key = 'announcement'), ''),
    'channel',      coalesce((select value from app_config where key = 'channel'), ''),
    'latest',       coalesce((select value from app_config where key = 'latest'), ''),
    'latest_url',   coalesce((select value from app_config where key = 'latest_url'), ''),
    'latest_win',   coalesce((select value from app_config where key = 'latest_win'), ''),
    'latest_url_win', coalesce((select value from app_config where key = 'latest_url_win'), ''),
    'donate',       coalesce((select value from app_config where key = 'donate'), ''),
    'total',        (select count(*) from devices),
    'online',       (select count(*) from devices where seen > now() - interval '3 minutes')
  );
end;
$$;

create or replace function public.admin_set(p_pass text, p_key text, p_value text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_key not in ('servers', 'announcement', 'channel', 'latest', 'latest_url', 'donate', 'latest_win', 'latest_url_win', 'candidates') then
    return false;
  end if;
  if not exists (select 1 from admin_secret where id = 1 and hash = extensions.crypt(p_pass, hash)) then
    return false;
  end if;
  insert into app_config (key, value) values (p_key, p_value)
  on conflict (key) do update set value = excluded.value;
  return true;
end;
$$;

insert into public.app_config (key, value) values ('channel', ''), ('latest', ''), ('latest_url', ''), ('donate', ''), ('latest_win', ''), ('latest_url_win', ''), ('candidates', '')
on conflict (key) do nothing;

revoke all on function public.get_meta(text, text) from public;
grant execute on function public.get_meta(text, text) to anon, authenticated;

-- خواندن مخصوص مدیر (برای لیست کاندیدهای ربات؛ این مقدار هرگز به کاربران عادی داده نمی‌شود)
create or replace function public.admin_get(p_pass text, p_key text)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_key not in ('candidates') then
    return '';
  end if;
  if not exists (select 1 from admin_secret where id = 1 and hash = extensions.crypt(p_pass, hash)) then
    return '';
  end if;
  return coalesce((select value from app_config where key = p_key), '');
end;
$$;

revoke all on function public.admin_get(text, text) from public;
grant execute on function public.admin_get(text, text) to anon, authenticated;
