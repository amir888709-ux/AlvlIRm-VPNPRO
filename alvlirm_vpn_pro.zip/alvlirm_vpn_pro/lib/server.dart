import 'dart:convert';

import 'package:flutter_v2ray_client/flutter_v2ray.dart';

import 'aether.dart';

/// کشورهای نزدیک به ایران (پینگ کم) برای حالت گیمینگ
const Set<String> kGamingCountries = {
  'TR', 'AE', 'QA', 'BH', 'KW', 'OM', 'SA', 'AM', 'AZ', 'GE', 'IQ',
  'DE', 'NL', 'FI', 'FR',
};

const int kOfficial = 0;
const int kSub = 1;
const int kManual = 2;

/// یک سرور آماده‌ی اتصال
class VpnServer {
  VpnServer({
    required this.id,
    required this.name,
    required this.country,
    required this.protocol,
    required this.config,
    required this.source,
    this.link = '',
    this.subId,
  });

  final String id;
  String name;
  final String country;
  final String protocol;
  final String config;

  /// kOfficial / kSub / kManual
  final int source;

  /// لینک اصلی. برای سرورهای رسمی همیشه خالی است (محافظت‌شده)
  final String link;
  final String? subId;

  bool get official => source == kOfficial;

  /// سرور Aether / MASQUE-in-MASQUE
  bool get isAether => country == 'AETHER';

  /// null = تست نشده ، -1 = بدون پاسخ ، مثبت = میلی‌ثانیه
  int? ping;
}

String alvHash(String s) {
  var h1 = 0x811c9dc5;
  var h2 = 0x1b873593;
  for (final u in s.codeUnits) {
    h1 = ((h1 ^ u) * 0x01000193) & 0xFFFFFFFF;
    h2 = ((h2 * 31) + u) & 0xFFFFFFFF;
  }
  return h1.toRadixString(36) + h2.toRadixString(36);
}

/// پرچم ایموجی (دو Regional Indicator) را به کد کشور تبدیل می‌کند.
String? countryFromText(String text) {
  final r = text.runes.toList();
  for (var i = 0; i < r.length - 1; i++) {
    final a = r[i], b = r[i + 1];
    if (a >= 0x1F1E6 && a <= 0x1F1FF && b >= 0x1F1E6 && b <= 0x1F1FF) {
      return String.fromCharCodes([a - 0x1F1E6 + 65, b - 0x1F1E6 + 65]);
    }
  }
  return null;
}

String flagEmoji(String code) {
  if (code.length != 2 || code == 'XX') return '🌐';
  return String.fromCharCodes(
    code.toUpperCase().codeUnits.map((c) => c - 65 + 0x1F1E6),
  );
}

String stripFlags(String text) {
  final out = <int>[];
  for (final r in text.runes) {
    if (r >= 0x1F1E6 && r <= 0x1F1FF) continue;
    out.add(r);
  }
  return String.fromCharCodes(out).trim();
}

const _countryFa = <String, String>{
  'AE': 'امارات', 'CA': 'کانادا', 'CH': 'سوئیس', 'CL': 'شیلی',
  'DE': 'آلمان', 'ES': 'اسپانیا', 'FI': 'فنلاند', 'FR': 'فرانسه',
  'GB': 'انگلیس', 'HK': 'هنگ‌کنگ', 'IR': 'ایران', 'IT': 'ایتالیا',
  'JP': 'ژاپن', 'KR': 'کره‌ی جنوبی', 'MD': 'مولداوی', 'NL': 'هلند',
  'NO': 'نروژ', 'PL': 'لهستان', 'RU': 'روسیه', 'SC': 'سیشل',
  'SE': 'سوئد', 'SG': 'سنگاپور', 'US': 'آمریکا', 'ZA': 'آفریقای جنوبی',
  'XX': '—',
};

/// نام کشور؛ برای فارسی ترجمه ، برای بقیه‌ی زبان‌ها خود کد کشور
String countryLabel(String code, String lang) {
  if (lang == 'fa') return _countryFa[code.toUpperCase()] ?? code;
  return code == 'XX' ? '—' : code;
}

// ---------------------------------------------------------------------------
// استخراج لینک‌ها
// ---------------------------------------------------------------------------
final RegExp _linkRe = RegExp(
  r'(?<![A-Za-z0-9])(?:vless|vmess|trojan|ss|wireguard|wg|hysteria2|hysteria|hy2|tuic|aether)://[^\s<>"]+',
  caseSensitive: false,
);

List<String> extractLinks(String text) {
  var t = text;
  if (t.contains('[Interface]') && t.contains('[Peer]')) {
    final l = wgConfToLink(t);
    if (l != null) return [l];
  }
  return _linkRe.allMatches(t).map((m) => m.group(0)!.trim()).toList();
}

String schemeOf(String link) {
  final i = link.indexOf('://');
  return i < 0 ? '' : link.substring(0, i).toLowerCase();
}

const _native = {'vless', 'vmess', 'trojan', 'ss'};
const _wgSchemes = {'wireguard', 'wg'};

bool isSupportedLink(String link) {
  final s = schemeOf(link);
  return _native.contains(s) || _wgSchemes.contains(s) || s == 'aether';
}

/// محتوای یک لینک ساب (متن ساده یا base64) را به لیست لینک تبدیل می‌کند
List<String> parseSubscription(String body) {
  var t = body.trim();
  if (extractLinks(t).isEmpty) {
    try {
      final norm = t
          .replaceAll(RegExp(r'\s+'), '')
          .replaceAll('-', '+')
          .replaceAll('_', '/');
      t = utf8.decode(base64.decode(base64.normalize(norm)),
          allowMalformed: true);
    } catch (_) {}
  }
  return extractLinks(t);
}

// ---------------------------------------------------------------------------
// WireGuard
// ---------------------------------------------------------------------------
class WgInfo {
  WgInfo({
    required this.priv,
    required this.pub,
    required this.host,
    required this.port,
    required this.address,
    required this.mtu,
    required this.reserved,
    required this.name,
    this.psk = '',
  });
  final String priv;
  final String pub;
  final String host;
  final int port;
  final List<String> address;
  final int mtu;
  final List<int> reserved;
  final String name;
  final String psk;
}

String _dec(String s) {
  try {
    return Uri.decodeComponent(s);
  } catch (_) {
    return s;
  }
}

WgInfo parseWgLink(String link) {
  var s = link.substring(link.indexOf('://') + 3);
  var name = '';
  final h = s.indexOf('#');
  if (h >= 0) {
    name = _dec(s.substring(h + 1));
    s = s.substring(0, h);
  }
  var q = '';
  final qi = s.indexOf('?');
  if (qi >= 0) {
    q = s.substring(qi + 1);
    s = s.substring(0, qi);
  }
  final at = s.lastIndexOf('@');
  if (at < 0) throw const FormatException('wg');
  final priv = _dec(s.substring(0, at));
  var hp = s.substring(at + 1);
  if (hp.endsWith('/')) hp = hp.substring(0, hp.length - 1);
  final colon = hp.lastIndexOf(':');
  if (colon < 0) throw const FormatException('wg');
  var host = hp.substring(0, colon);
  if (host.startsWith('[') && host.endsWith(']')) {
    host = host.substring(1, host.length - 1);
  }
  final port = int.parse(hp.substring(colon + 1));

  final params = <String, String>{};
  for (final part in q.split('&')) {
    final e = part.indexOf('=');
    if (e <= 0) continue;
    params[part.substring(0, e).toLowerCase()] = _dec(part.substring(e + 1));
  }
  String p(List<String> keys) {
    for (final k in keys) {
      final v = params[k];
      if (v != null && v.isNotEmpty) return v;
    }
    return '';
  }

  final pub = p(['publickey', 'public_key', 'pbk', 'peer']);
  if (priv.isEmpty || pub.isEmpty) throw const FormatException('wg');
  final addr = p(['address', 'ip', 'addr'])
      .split(',')
      .map((e) => e.trim())
      .where((e) => e.isNotEmpty)
      .map((e) => e.contains('/') ? e : (e.contains(':') ? '$e/128' : '$e/32'))
      .toList();
  if (addr.isEmpty) addr.add('172.16.0.2/32');
  final mtu = int.tryParse(p(['mtu'])) ?? 1280;
  final res = p(['reserved'])
      .split(',')
      .map((e) => int.tryParse(e.trim()))
      .whereType<int>()
      .toList();
  return WgInfo(
    priv: priv,
    pub: pub,
    host: host,
    port: port,
    address: addr,
    mtu: mtu,
    reserved: res.length == 3 ? res : <int>[0, 0, 0],
    name: name,
    psk: p(['presharedkey', 'psk', 'preshared_key']),
  );
}

/// متن فایل WireGuard (.conf) را به لینک wireguard:// تبدیل می‌کند
String? wgConfToLink(String conf) {
  try {
    final kv = <String, String>{};
    for (final raw in conf.split('\n')) {
      final line = raw.trim();
      final e = line.indexOf('=');
      if (e <= 0 || line.startsWith('#') || line.startsWith('[')) continue;
      kv[line.substring(0, e).trim().toLowerCase()] =
          line.substring(e + 1).trim();
    }
    final priv = kv['privatekey'];
    final pub = kv['publickey'];
    final ep = kv['endpoint'];
    if (priv == null || pub == null || ep == null) return null;
    final addr = (kv['address'] ?? '172.16.0.2/32').replaceAll(' ', '');
    final b = StringBuffer('wireguard://${Uri.encodeComponent(priv)}@$ep');
    b.write('?publickey=${Uri.encodeComponent(pub)}');
    b.write('&address=${Uri.encodeComponent(addr)}');
    if (kv['mtu'] != null) b.write('&mtu=${kv['mtu']}');
    if (kv['presharedkey'] != null) {
      b.write('&presharedkey=${Uri.encodeComponent(kv['presharedkey']!)}');
    }
    if (kv['reserved'] != null) {
      b.write('&reserved=${Uri.encodeComponent(kv['reserved']!.replaceAll(' ', ''))}');
    }
    b.write('#WireGuard');
    return b.toString();
  } catch (_) {
    return null;
  }
}

Map<String, dynamic>? _base;

Map<String, dynamic> _baseConfig() {
  final cached = _base;
  if (cached != null) return cached;
  final dummy = base64
      .encode(utf8.encode('aes-256-gcm:abc'))
      .replaceAll('=', '');
  final p = V2ray.parseFromURL('ss://$dummy@127.0.0.1:1080#x');
  final m = jsonDecode(p.getFullConfiguration()) as Map<String, dynamic>;
  _base = m;
  return m;
}

/// حالت «فقط DNS»: همه‌ی ترافیک مستقیم می‌رود و فقط پرسش‌های DNS با سرورهای انتخابی جواب داده می‌شود
String dnsOnlyConfig(List<String> ips) {
  final cfg = jsonDecode(jsonEncode(_baseConfig())) as Map<String, dynamic>;
  final tags = <String>[];
  final ins = cfg['inbounds'];
  if (ins is List) {
    for (final i in ins) {
      if (i is Map && i['tag'] is String) tags.add(i['tag'] as String);
    }
  }
  // خروجی‌های اصلی (proxy ساختگی در جایگاه اول) نگه داشته می‌شوند تا هسته/افزونه
  // همان ساختار معتبر همیشگی را ببینند؛ فقط direct و dns-out تضمین می‌شوند.
  final outs = <dynamic>[
    ...((cfg['outbounds'] as List?) ?? const <dynamic>[]),
  ];
  bool hasTag(String t) => outs.any((o) => o is Map && o['tag'] == t);
  if (!hasTag('direct')) {
    outs.add({'tag': 'direct', 'protocol': 'freedom', 'settings': {}});
  }
  if (!hasTag('dns-out')) {
    outs.add({'tag': 'dns-out', 'protocol': 'dns', 'settings': {}});
  }
  cfg['outbounds'] = outs;
  cfg['dns'] = {
    'tag': 'dns-internal',
    'servers': ips,
    'queryStrategy': 'UseIPv4',
  };
  final rules = <Map<String, dynamic>>[
    {
      'type': 'field',
      'inboundTag': ['dns-internal'],
      'outboundTag': 'direct',
    },
    {
      'type': 'field',
      if (tags.isNotEmpty) 'inboundTag': tags,
      'port': '53',
      'outboundTag': 'dns-out',
    },
    {'type': 'field', 'network': 'tcp,udp', 'outboundTag': 'direct'},
  ];
  cfg['routing'] = {'domainStrategy': 'AsIs', 'rules': rules};
  return jsonEncode(cfg);
}

/// Aether: هسته به یک پروکسی SOCKS5 محلی وصل می‌شود که خود برنامه‌ی aether می‌سازد
String _aetherConfig(AetherSpec spec) {
  final cfg = jsonDecode(jsonEncode(_baseConfig())) as Map<String, dynamic>;
  final outs = (cfg['outbounds'] as List).cast<dynamic>();
  var idx = outs.indexWhere((o) => o is Map && o['tag'] == 'proxy');
  if (idx < 0) idx = 0;
  outs[idx] = {
    'tag': 'proxy',
    'protocol': 'socks',
    'settings': {
      'servers': [
        {'address': '127.0.0.1', 'port': kAetherPort},
      ],
    },
  };
  cfg[kAetherKey] = spec.toJson();
  return jsonEncode(cfg);
}

String _wgConfig(WgInfo w) {
  final cfg = jsonDecode(jsonEncode(_baseConfig())) as Map<String, dynamic>;
  final outs = (cfg['outbounds'] as List).cast<dynamic>();
  var idx = outs.indexWhere((o) => o is Map && o['tag'] == 'proxy');
  if (idx < 0) idx = 0;
  final peer = <String, dynamic>{
    'publicKey': w.pub,
    'endpoint': '${w.host.contains(':') ? '[${w.host}]' : w.host}:${w.port}',
    'allowedIPs': ['0.0.0.0/0', '::/0'],
  };
  if (w.psk.isNotEmpty) peer['preSharedKey'] = w.psk;
  outs[idx] = {
    'tag': 'proxy',
    'protocol': 'wireguard',
    'settings': {
      'secretKey': w.priv,
      'address': w.address,
      'peers': [peer],
      'mtu': w.mtu,
      'reserved': w.reserved,
    },
  };
  cfg['outbounds'] = outs;
  return jsonEncode(cfg);
}

// ---------------------------------------------------------------------------
// ساخت سرور از لینک
// ---------------------------------------------------------------------------
String _remarkOf(String link) {
  try {
    if (link.startsWith('vmess://')) {
      final body = link.substring(8).trim();
      final map = jsonDecode(utf8.decode(base64.decode(base64.normalize(body))))
          as Map<String, dynamic>;
      return (map['ps'] ?? '').toString();
    }
    final i = link.indexOf('#');
    if (i < 0) return '';
    return _dec(link.substring(i + 1));
  } catch (_) {
    return '';
  }
}

/// لینک بدون نام (برای تشخیص تکراری)
String linkCore(String link) => link.split('#').first;

/// null یعنی لینک خراب یا پروتکل پشتیبانی‌نشده
/// نام اولیه = نام داخل لینک بدون پرچم (ممکن است خالی باشد)
VpnServer? makeServer(String raw, int source, {String? subId}) {
  final link = raw.trim();
  final scheme = schemeOf(link);
  try {
    String config;
    String remark;
    String proto;
    var aether = false;
    if (scheme == 'aether') {
      final spec = parseAetherLink(link);
      if (spec == null) return null;
      config = _aetherConfig(spec);
      remark = spec.name;
      proto = spec.protocol == 'mim' ? 'MIM' : spec.protocol.toUpperCase();
      aether = true;
    } else if (_wgSchemes.contains(scheme)) {
      final w = parseWgLink(link);
      config = _wgConfig(w);
      remark = w.name;
      proto = 'WIREGUARD';
    } else if (_native.contains(scheme)) {
      final parsed = V2ray.parseFromURL(link);
      config = parsed.getFullConfiguration();
      if (config.isEmpty) return null;
      remark = _remarkOf(link);
      proto = scheme.toUpperCase();
    } else {
      return null;
    }
    final country = aether ? 'AETHER' : (countryFromText(remark) ?? 'XX');
    final prefix = source == kOfficial ? 'o' : (source == kSub ? 's' : 'm');
    return VpnServer(
      id: '$prefix${alvHash(linkCore(link))}',
      name: stripFlags(remark),
      country: country,
      protocol: proto,
      config: config,
      source: source,
      // سرورهای رسمی هیچ‌وقت لینک را نگه نمی‌دارند
      link: source == kOfficial ? '' : link,
      subId: subId,
    );
  } catch (_) {
    return null;
  }
}
