import 'dart:io';

import 'package:flutter/material.dart';

import 'dns.dart';
import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

/// بخش DNS: انتخاب DNS برای اتصال یا بازی و فعال‌سازی حالت «فقط DNS»
class DnsPanel extends StatefulWidget {
  const DnsPanel({super.key, required this.controller});
  final VpnController controller;

  @override
  State<DnsPanel> createState() => _DnsPanelState();
}

class _DnsPanelState extends State<DnsPanel> {
  VpnController get c => widget.controller;
  String _testText = '';
  bool _testing = false;

  Future<void> _toggle() async {
    final wasOn = c.dnsOn;
    await c.toggleDns();
    if (!mounted) return;
    if (!wasOn && !c.dnsOn) {
      toast(
        context,
        c.dnsFail == 'perm'
            ? tr('err_perm')
            : '${tr('dns_start_failed')}\n${c.dnsFail}',
      );
    }
  }

  Future<void> _test() async {
    setState(() {
      _testing = true;
      _testText = '';
    });
    final sw = Stopwatch()..start();
    String text;
    try {
      final r = await InternetAddress.lookup('google.com')
          .timeout(const Duration(seconds: 6));
      text = r.isEmpty
          ? tr('dns_test_fail')
          : tr('dns_test_ok',
              ['google.com', r.first.address, sw.elapsedMilliseconds]);
    } catch (_) {
      text = tr('dns_test_fail');
    }
    if (!mounted) return;
    setState(() {
      _testing = false;
      _testText = text;
    });
  }

  Future<void> _askCustom(String purpose) async {
    final ctrl = TextEditingController(text: c.dnsCustomOf(purpose));
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.card,
        title: Text(tr('dns_custom'),
            style: TextStyle(color: AppColors.text, fontSize: 16)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          textDirection: TextDirection.ltr,
          style: TextStyle(color: AppColors.text),
          decoration: InputDecoration(hintText: tr('dns_custom_hint')),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(tr('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text),
            child: Text(tr('ok')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (text == null) return;
    if (parseDnsList(text).isEmpty) {
      if (mounted) toast(context, tr('dns_pick'));
      return;
    }
    await c.chooseDns(purpose, 'custom', text.trim());
  }

  Widget _statusButton() {
    final on = c.dnsOn;
    final color = on ? AppColors.ok : AppColors.purple;
    return Column(
      children: [
        GestureDetector(
          onTap: c.dnsBusy ? null : _toggle,
          child: Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.card,
              border: Border.all(color: color, width: 3),
              boxShadow: [
                BoxShadow(
                  color: color.withValues(alpha: on ? 0.45 : 0.2),
                  blurRadius: 28,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: c.dnsBusy
                ? Padding(
                    padding: const EdgeInsets.all(40),
                    child: CircularProgressIndicator(
                        strokeWidth: 3, color: AppColors.purpleLight),
                  )
                : Icon(Icons.dns_rounded, size: 52, color: color),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          on ? tr('dns_on') : tr('dns_off'),
          style: TextStyle(
              color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 4),
        Text(
          on ? tr('dns_using', [c.dnsActiveName]) : tr('dns_pick'),
          style: TextStyle(color: AppColors.muted, fontSize: 13),
        ),
        if (on)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(c.duration,
                style: TextStyle(
                    color: AppColors.muted,
                    fontSize: 22,
                    fontWeight: FontWeight.w300,
                    letterSpacing: 1.2)),
          ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: c.dnsBusy ? null : _toggle,
          icon: Icon(on ? Icons.stop_rounded : Icons.play_arrow_rounded),
          label: Text(on ? tr('dns_stop') : tr('dns_start')),
        ),
      ],
    );
  }

  Widget _purposeChips() {
    Widget chip(String p, String label, IconData icon) {
      final sel = c.dnsPurpose == p;
      return Expanded(
        child: GestureDetector(
          onTap: () async {
            await c.setDnsPurpose(p);
            if (c.dnsOn) {
              await c.stopDns();
              await c.startDns();
            }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: BoxDecoration(
              color: sel
                  ? AppColors.purple.withValues(alpha: 0.22)
                  : AppColors.card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: sel
                    ? AppColors.purple
                    : AppColors.purple.withValues(alpha: 0.2),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon,
                    size: 17,
                    color: sel ? AppColors.purpleLight : AppColors.muted),
                const SizedBox(width: 6),
                Text(label,
                    style: TextStyle(
                        color: sel ? AppColors.text : AppColors.muted,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        chip('conn', tr('dns_purpose_conn'), Icons.public_rounded),
        const SizedBox(width: 10),
        chip('game', tr('dns_purpose_game'), Icons.sports_esports_rounded),
      ],
    );
  }

  Widget _option({
    required String purpose,
    required String keyName,
    required String title,
    required String sub,
    VoidCallback? onTap,
  }) {
    final sel = c.dnsKeyOf(purpose) == keyName;
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Material(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap ?? () => c.chooseDns(purpose, keyName),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: sel
                    ? AppColors.purple
                    : AppColors.purple.withValues(alpha: 0.15),
                width: sel ? 1.6 : 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  sel
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_off_rounded,
                  color: sel ? AppColors.purpleLight : AppColors.muted,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              color: AppColors.text,
                              fontWeight: FontWeight.w700,
                              fontSize: 15)),
                      if (sub.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(sub,
                            textDirection: TextDirection.ltr,
                            style:
                                TextStyle(color: AppColors.muted, fontSize: 12)),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _options() {
    final p = c.dnsPurpose;
    final list = p == 'game' ? kDnsGame : kDnsConn;
    final custom = c.dnsCustomOf(p);
    return [
      if (p == 'conn')
        _option(
          purpose: p,
          keyName: 'default',
          title: tr('dns_default'),
          sub: 'Cloudflare 1.1.1.1',
        ),
      for (final d in list)
        _option(
          purpose: p,
          keyName: d.key,
          title: d.name,
          sub: d.ips.join('  ·  '),
        ),
      _option(
        purpose: p,
        keyName: 'custom',
        title: tr('dns_custom'),
        sub: custom.isEmpty ? tr('dns_custom_hint') : custom,
        onTap: () => _askCustom(p),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final game = c.dnsPurpose == 'game';
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
      children: [
        Center(child: _statusButton()),
        const SizedBox(height: 22),
        _purposeChips(),
        const SizedBox(height: 8),
        Text(
          game ? tr('dns_game_d') : tr('dns_conn_d'),
          style: TextStyle(color: AppColors.muted, fontSize: 12),
        ),
        ..._options(),
        if (game)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(tr('dns_game_note'),
                style: TextStyle(color: AppColors.muted, fontSize: 12)),
          ),
        const SizedBox(height: 16),
        Row(
          children: [
            OutlinedButton.icon(
              onPressed: _testing ? null : _test,
              icon: _testing
                  ? const SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.speed_rounded, size: 18),
              label: Text(tr('dns_test')),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(_testText,
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: AppColors.muted, fontSize: 12)),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Text(tr('dns_how'),
            style: TextStyle(color: AppColors.muted, fontSize: 12)),
      ],
    );
  }
}
