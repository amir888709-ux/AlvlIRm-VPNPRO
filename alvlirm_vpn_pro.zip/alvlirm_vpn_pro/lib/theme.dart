import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// یک پالت رنگی کامل
class Pal {
  const Pal({
    required this.b,
    required this.bg,
    required this.card,
    required this.primary,
    required this.primaryLight,
    required this.primaryDeep,
    required this.text,
    required this.muted,
    required this.glow,
  });

  final Brightness b;
  final Color bg;
  final Color card;
  final Color primary;
  final Color primaryLight;
  final Color primaryDeep;
  final Color text;
  final Color muted;
  final Color glow;
}

const _night = Pal(
  b: Brightness.dark,
  bg: Color(0xFF07050D),
  card: Color(0xFF130D22),
  primary: Color(0xFF8B3DFF),
  primaryLight: Color(0xFFB985FF),
  primaryDeep: Color(0xFF4B1A9E),
  text: Color(0xFFF3ECFF),
  muted: Color(0xFF8E80A8),
  glow: Color(0xFF1E0F3D),
);

const _amoled = Pal(
  b: Brightness.dark,
  bg: Color(0xFF000000),
  card: Color(0xFF0E0A16),
  primary: Color(0xFF9A52FF),
  primaryLight: Color(0xFFC59BFF),
  primaryDeep: Color(0xFF4B1A9E),
  text: Color(0xFFF3ECFF),
  muted: Color(0xFF857A99),
  glow: Color(0xFF0A0614),
);

const _light = Pal(
  b: Brightness.light,
  bg: Color(0xFFF6F1FF),
  card: Color(0xFFFFFFFF),
  primary: Color(0xFF7A2BF0),
  primaryLight: Color(0xFF8B3DFF),
  primaryDeep: Color(0xFF4B1A9E),
  text: Color(0xFF1A1030),
  muted: Color(0xFF6F6488),
  glow: Color(0xFFE6D8FF),
);

const _ocean = Pal(
  b: Brightness.dark,
  bg: Color(0xFF040B14),
  card: Color(0xFF0A1726),
  primary: Color(0xFF1E90FF),
  primaryLight: Color(0xFF7CC4FF),
  primaryDeep: Color(0xFF0B3C8A),
  text: Color(0xFFEAF4FF),
  muted: Color(0xFF7E92A8),
  glow: Color(0xFF0B2A4A),
);

const _emerald = Pal(
  b: Brightness.dark,
  bg: Color(0xFF040D0A),
  card: Color(0xFF0A1A14),
  primary: Color(0xFF12B981),
  primaryLight: Color(0xFF6EE7B7),
  primaryDeep: Color(0xFF065F46),
  text: Color(0xFFEAFFF6),
  muted: Color(0xFF7BA192),
  glow: Color(0xFF0B3B2C),
);

const _sunset = Pal(
  b: Brightness.dark,
  bg: Color(0xFF0E0605),
  card: Color(0xFF1F100C),
  primary: Color(0xFFFF6B35),
  primaryLight: Color(0xFFFFA574),
  primaryDeep: Color(0xFF9A2A0C),
  text: Color(0xFFFFF1EA),
  muted: Color(0xFFA88478),
  glow: Color(0xFF45160A),
);

const _rose = Pal(
  b: Brightness.dark,
  bg: Color(0xFF10050B),
  card: Color(0xFF22101A),
  primary: Color(0xFFF43F7F),
  primaryLight: Color(0xFFFF8FB5),
  primaryDeep: Color(0xFF9B1450),
  text: Color(0xFFFFEEF4),
  muted: Color(0xFFA8788C),
  glow: Color(0xFF4A0F2B),
);

const Map<String, Pal> kThemes = {
  'night': _night,
  'amoled': _amoled,
  'light': _light,
  'ocean': _ocean,
  'emerald': _emerald,
  'sunset': _sunset,
  'rose': _rose,
};

/// کلید تم‌ها به ترتیب نمایش (system اول)
const List<String> kThemeKeys = [
  'system',
  'night',
  'amoled',
  'light',
  'ocean',
  'emerald',
  'sunset',
  'rose',
];

/// پالت فعلی برنامه
Pal pal = _night;

/// با هر تغییر تم/زبان عدد زیاد می‌شود تا کل برنامه دوباره ساخته شود
final ValueNotifier<int> look = ValueNotifier<int>(0);

void applyTheme(String key) {
  if (key == 'system') {
    final dark = ui.PlatformDispatcher.instance.platformBrightness ==
        Brightness.dark;
    pal = dark ? _night : _light;
  } else {
    pal = kThemes[key] ?? _night;
  }
}

/// رنگ‌ها: همه‌ی این‌ها getter هستند (const نیستند)
class AppColors {
  static Color get bg => pal.bg;
  static Color get card => pal.card;
  static Color get purple => pal.primary;
  static Color get purpleLight => pal.primaryLight;
  static Color get purpleDeep => pal.primaryDeep;
  static Color get text => pal.text;
  static Color get muted => pal.muted;
  static Color get glow => pal.glow;
  static const ok = Color(0xFF2BD99A);
  static const warn = Color(0xFFFFC857);
  static const bad = Color(0xFFFF5C7A);
}

/// رنگ پینگ: سبز سریع ، زرد متوسط ، قرمز کند یا ناموفق
Color pingColor(int? ping) {
  if (ping == null) return AppColors.muted;
  if (ping <= 0) return AppColors.bad;
  if (ping < 250) return AppColors.ok;
  if (ping < 600) return AppColors.warn;
  return AppColors.bad;
}

ThemeData buildTheme() {
  final base = ColorScheme.fromSeed(
    seedColor: pal.primary,
    brightness: pal.b,
  );
  return ThemeData(
    brightness: pal.b,
    useMaterial3: true,
    scaffoldBackgroundColor: pal.bg,
    colorScheme: base.copyWith(
      primary: pal.primary,
      secondary: pal.primaryLight,
      surface: pal.card,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      foregroundColor: pal.text,
    ),
    popupMenuTheme: PopupMenuThemeData(color: pal.card),
    canvasColor: pal.card,
  );
}
