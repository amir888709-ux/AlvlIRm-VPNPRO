import 'package:flutter/material.dart';

import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

/// پیام سه‌مرحله‌ای و بامزه‌ی حمایت مالی هنگام ورود به برنامه.
/// هر مرحله یک دکمه‌ی «باشه» دارد ؛ مرحله‌ی آخر می‌تواند به لینک حمایت برود.
Future<void> showDonatePrompt(BuildContext context, VpnController c) async {
  c.donateShown();
  final yes = await showGeneralDialog<bool>(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'donate',
    barrierColor: Colors.black.withValues(alpha: 0.72),
    transitionDuration: const Duration(milliseconds: 320),
    pageBuilder: (ctx, a, b) => const _DonateCard(),
    transitionBuilder: (ctx, a, b, child) => FadeTransition(
      opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.88, end: 1.0)
            .animate(CurvedAnimation(parent: a, curve: Curves.easeOutBack)),
        child: child,
      ),
    ),
  );
  if (yes == true) {
    c.donateDone();
    if (context.mounted) await openUrl(context, c.donateUrl);
  }
}

class _DonateCard extends StatefulWidget {
  const _DonateCard();

  @override
  State<_DonateCard> createState() => _DonateCardState();
}

class _DonateCardState extends State<_DonateCard> {
  int _i = 0;

  static const _emoji = ['😎', '🤫', '🥺'];

  Widget _page() {
    final n = _i + 1;
    return Column(
      key: ValueKey<int>(_i),
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 78,
          height: 78,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.purpleDeep, AppColors.purple],
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.purple.withValues(alpha: 0.5),
                blurRadius: 24,
              ),
            ],
          ),
          child: Text(_emoji[_i], style: const TextStyle(fontSize: 38)),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: Text(
            tr('dn${n}_t'),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.text,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: Text(
            tr('dn${n}_b'),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.muted,
              fontSize: 14,
              height: 1.75,
            ),
          ),
        ),
      ],
    );
  }

  Widget _dots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (var k = 0; k < 3; k++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: k == _i ? 22 : 7,
            height: 7,
            decoration: BoxDecoration(
              color: k == _i
                  ? AppColors.purple
                  : AppColors.muted.withValues(alpha: 0.35),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final last = _i == 2;
    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(maxWidth: 360),
          margin: const EdgeInsets.symmetric(horizontal: 22),
          padding: const EdgeInsets.fromLTRB(22, 28, 22, 16),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.purple.withValues(alpha: 0.5)),
            boxShadow: [
              BoxShadow(
                color: AppColors.purple.withValues(alpha: 0.3),
                blurRadius: 40,
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ConstrainedBox(
                  constraints: const BoxConstraints(minHeight: 230),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 260),
                    transitionBuilder: (w, a) => FadeTransition(
                      opacity: a,
                      child: ScaleTransition(
                        scale: Tween<double>(begin: 0.94, end: 1.0).animate(a),
                        child: w,
                      ),
                    ),
                    child: _page(),
                  ),
                ),
                const SizedBox(height: 14),
                _dots(),
                const SizedBox(height: 16),
                if (!last)
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => setState(() => _i++),
                      child: Text(tr('dn${_i + 1}_btn')),
                    ),
                  )
                else ...[
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: Text(tr('dn3_yes')),
                    ),
                  ),
                  const SizedBox(height: 4),
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: Text(
                      tr('dn3_no'),
                      style: TextStyle(color: AppColors.muted),
                    ),
                  ),
                  Text(
                    tr('dn_foot'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.muted, fontSize: 11),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
