import 'dart:async';
import 'dart:convert';
import 'dart:io' show Socket;
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_v2ray_client/flutter_v2ray.dart';

import 'api.dart';
import 'aether.dart';
import 'config.dart';
import 'crypto_box.dart';
import 'dns.dart';
import 'i18n.dart' as i18n;
import 'server.dart';
import 'store.dart';
import 'theme.dart';

enum VpnPhase { idle, searching, connecting, connected, failed }

const testUrls = <String, String>{
  'Google': 'https://www.google.com/generate_204',
  'Cloudflare': 'https://cp.cloudflare.com/generate_204',
  'Gstatic': 'https://www.gstatic.com/generate_204',
};

const _lanSubnets = <String>[
  '10.0.0.0/8',
  '172.16.0.0/12',
  '192.168.0.0/16',
  '127.0.0.0/8',
];

/// یک لینک اشتراک (ساب)
class SubInfo {
  SubInfo({
    required this.id,
    required this.name,
    required this.url,
    this.updated = 0,
    this.count = 0,
  });
  final String id;
  String name;
  final String url;
  int updated; // میلی‌ثانیه
  int count;

  String toJson() => jsonEncode({
        'id': id,
        'name': name,
        'url': url,
        'updated': updated,
        'count': count,
      });

  static SubInfo? fromJson(String s) {
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      return SubInfo(
        id: m['id'] as String,
        name: (m['name'] ?? '') as String,
        url: m['url'] as String,
        updated: (m['updated'] ?? 0) as int,
        count: (m['count'] ?? 0) as int,
      );
    } catch (_) {
      return null;
    }
  }
}

class AddResult {
  AddResult(this.added, this.skipped);
  final int added;
  final int skipped;
}

class VpnController extends ChangeNotifier {
  VpnController();

  late final V2ray _v2ray = V2ray(onStatusChanged: _onStatus);
  late Store _store;

  // ---------- داده‌ها ----------
  List<VpnServer> servers = [];

  /// کشور خروجی تشخیص‌داده‌شده‌ی سرورهای Aether (شناسه ← کد دو حرفی)
  final Map<String, String> _exit = {};
  List<String> _seedLinks = [];
  List<String> _officialLinks = [];
  List<SubInfo> subs = [];
  Set<String> favorites = {};
  String? selectedId;

  // ---------- تنظیمات ----------
  bool autoConnectOnLaunch = false;
  bool bypassLan = false;
  bool proxyOnly = false;
  bool gamingMode = false;
  String dnsKey = 'default';
  String dnsCustom = '';
  String dnsGameKey = 'shecan';
  String dnsGameCustom = '';
  String dnsPurpose = 'conn'; // conn | game
  String appMode = 'vpn'; // vpn | dns

  // ---------- حالت فقط DNS ----------
  bool dnsOn = false;
  bool dnsBusy = false;
  String dnsFail = ''; // '', 'perm' یا متن خطا
  bool _dnsRun = false;
  String dnsActiveName = '';
  String? notice;
  String testUrlKey = 'Google';
  int timeoutSec = 10;
  int subHours = 6;
  String themeKey = 'night';
  bool welcomed = false;
  String get testUrl => testUrls[testUrlKey] ?? testUrls.values.first;

  // ---------- آنلاین / اطلاعیه ----------
  int? online;
  int? totalUsers;
  String announcement = '';
  String dismissedAnn = '';
  bool get showAnnouncement =>
      announcement.isNotEmpty && announcement != dismissedAnn;
  Timer? _beat;
  String channelUrl = '';
  String donateUrl = '';
  String latestAndroid = '';
  String urlAndroid = '';
  String latestWin = '';
  String urlWin = '';
  String get latestVersion => kPlatform == 'win' ? latestWin : latestAndroid;
  String get latestUrl => kPlatform == 'win' ? urlWin : urlAndroid;
  String dismissedUpd = '';

  static bool _newer(String a, String b) {
    List<int> p(String s) =>
        s.split('.').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    final x = p(a), y = p(b);
    for (var i = 0; i < 3; i++) {
      final xi = i < x.length ? x[i] : 0;
      final yi = i < y.length ? y[i] : 0;
      if (xi != yi) return xi > yi;
    }
    return false;
  }

  bool get updateAvailable =>
      latestUrl.startsWith('http') &&
      latestVersion.isNotEmpty &&
      _newer(latestVersion, kVersion) &&
      latestVersion != dismissedUpd;

  Future<void> dismissUpdate() async {
    dismissedUpd = latestVersion;
    await _store.setDismissedUpd(latestVersion);
    notifyListeners();
  }
  String _adminPass = '';

  // ---------- وضعیت اتصال ----------
  VpnPhase phase = VpnPhase.idle;
  VpnServer? current;
  String? msgKey;
  List<Object> msgArgs = const [];
  String duration = '00:00:00';
  int upload = 0;
  int download = 0;
  int uploadSpeed = 0;
  int downloadSpeed = 0;
  int? connectedPing;
  bool testingPing = false;

  // ---------- تست پینگ ----------
  final Set<String> pinging = {};
  bool pingingAll = false;
  int pingDone = 0;
  int pingTotal = 0;
  bool updatingSubs = false;

  Completer<bool>? _connectedWaiter;
  bool _cancel = false;
  String aetherError = '';

  /// آخرین خط گزارش Aether/Psiphon (نمایش زنده هنگام اتصال)
  String get aetherLive => AetherRunner.liveLine;

  Future<bool> resetAetherData() => AetherRunner.resetData();
  bool _cancelPing = false;

  VpnServer? byId(String? id) {
    if (id == null) return null;
    for (final s in servers) {
      if (s.id == id) return s;
    }
    return null;
  }

  VpnServer? get selected => byId(selectedId);
  String get officialText => _officialLinks.join('\n');
  int get officialCount => _officialLinks.length;

  // =====================================================================
  // راه‌اندازی
  // =====================================================================
  Future<void> init() async {
    _store = await Store.open();
    for (final e in _store.exitList) {
      final i = e.indexOf('=');
      if (i > 0 && e.length - i - 1 == 2) {
        _exit[e.substring(0, i)] = e.substring(i + 1);
      }
    }
    AetherRunner.warmUp();
    AetherRunner.onLog = () => notifyListeners();

    i18n.lang = _store.lang ?? 'fa';
    themeKey = _store.theme;
    applyTheme(themeKey);
    welcomed = _store.welcomed;
    dismissedAnn = _store.dismissedAnn;
    dismissedUpd = _store.dismissedUpd;

    favorites = _store.favorites.toSet();
    selectedId = _store.selected;
    autoConnectOnLaunch = _store.autoConnect;
    bypassLan = _store.bypassLan;
    proxyOnly = _store.proxyOnly;
    gamingMode = _store.gaming;
    dnsKey = _store.dnsKey;
    dnsCustom = _store.dnsCustom;
    dnsGameKey = _store.dnsGameKey;
    dnsGameCustom = _store.dnsGameCustom;
    dnsPurpose = _store.dnsPurpose;
    appMode = _store.appMode;
    testUrlKey = _store.testUrlKey;
    if (!testUrls.containsKey(testUrlKey)) testUrlKey = 'Google';
    timeoutSec = _store.timeoutSec;
    subHours = _store.subHours;
    autoSwitch = _store.autoSwitch;
    hotStandby = _store.hotStandby;
    for (final e in _store.okList) {
      final i = e.indexOf('=');
      final v = i > 0 ? int.tryParse(e.substring(i + 1)) : null;
      if (v != null && v > 0) _okMs[e.substring(0, i)] = v;
    }

    // سرورهای اولیه‌ی داخل برنامه (رمزشده)
    try {
      final enc = await rootBundle.loadString('assets/servers.enc');
      final clear = await CryptoBox.decrypt(enc);
      _seedLinks = clear == null ? <String>[] : extractLinks(clear);
    } catch (_) {
      _seedLinks = <String>[];
    }
    _officialLinks = _seedLinks;

    // آخرین لیست دریافت‌شده از سرور (کش)
    final cached = _store.officialBlob;
    if (cached.isNotEmpty) {
      final clear = await CryptoBox.decrypt(cached);
      if (clear != null) _officialLinks = extractLinks(clear);
    }

    _setChannel(_store.channel);
    donateUrl = _store.donate;
    subs = _store.subs.map(SubInfo.fromJson).whereType<SubInfo>().toList();

    _rebuild();

    try {
      await _v2ray.initialize(
        notificationIconResourceType: 'mipmap',
        notificationIconResourceName: 'ic_launcher',
      );
    } catch (e) {
      msgKey = 'err_core';
      msgArgs = [e];
    }

    unawaited(refreshRemote());
    unawaited(updateSubsIfDue());
    _beat = Timer.periodic(const Duration(seconds: 60), (_) => refreshRemote());
  }

  void _rebuild() {
    final old = <String, int?>{for (final s in servers) s.id: s.ping};
    final out = <VpnServer>[];
    final seen = <String>{};
    final counters = <String, int>{};

    void addAll(List<String> links, int src, String? subId) {
      for (final l in links) {
        final s = makeServer(l, src, subId: subId);
        if (s == null) continue;
        if (!seen.add(s.id.substring(1))) continue;
        if (src == kOfficial || s.name.isEmpty) {
          final n = (counters[s.country] ?? 0) + 1;
          counters[s.country] = n;
          s.name = n == 1 ? 'AlvlIRm-${s.country}' : 'AlvlIRm-${s.country}-$n';
        } else if (s.name.length > 30) {
          s.name = s.name.substring(0, 30);
        }
        s.ping = old[s.id];
        final ex = _exit[s.id];
        if (s.isAether && ex != null) s.exitCountry = ex;
        out.add(s);
      }
    }

    addAll(_officialLinks, kOfficial, null);
    for (final sub in subs) {
      addAll(_splitLines(_store.subLinks(sub.id)), kSub, sub.id);
    }
    addAll(_store.manual, kManual, null);

    servers = out;
    if (selectedId != null && byId(selectedId) == null) selectedId = null;
  }

  List<String> _splitLines(String s) =>
      s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

  Future<String> coreVersion() async {
    try {
      return await _v2ray.getCoreVersion();
    } catch (_) {
      return '-';
    }
  }

  // =====================================================================
  // سرورهای رسمی از راه دور + شمارنده‌ی آنلاین
  // =====================================================================
  Future<bool> refreshRemote() async {
    if (!apiEnabled) return false;
    var ok = false;
    try {
      final j = await Api.meta(_store.deviceId, _store.officialVer);
      if (j is Map) {
        online = (j['online'] as num?)?.toInt();
        totalUsers = (j['total'] as num?)?.toInt();
        announcement = (j['announcement'] ?? '').toString();
        _setChannel((j['channel'] ?? '').toString());
        _setDonate((j['donate'] ?? '').toString());
        latestAndroid = (j['latest'] ?? '').toString().trim();
        urlAndroid = (j['latest_url'] ?? '').toString().trim();
        latestWin = (j['latest_win'] ?? '').toString().trim();
        urlWin = (j['latest_url_win'] ?? '').toString().trim();
        final ver = (j['ver'] ?? '').toString();
        final blob = (j['servers'] ?? '').toString();
        if (blob.isNotEmpty) {
          if (blob != _store.officialBlob) {
            final clear = await CryptoBox.decrypt(blob);
            if (clear != null) {
              _officialLinks = extractLinks(clear);
              await _store.setOfficialBlob(blob);
              await _store.setOfficialVer(ver);
              _rebuild();
            }
          } else {
            await _store.setOfficialVer(ver);
          }
        }
        ok = true;
      }
    } catch (_) {}
    notifyListeners();
    return ok;
  }

  void _setDonate(String raw) {
    final t = raw.trim();
    donateUrl = t.startsWith('http') ? t : '';
    unawaited(_store.setDonate(donateUrl));
  }

  void _setChannel(String raw) {
    var t = raw.trim();
    if (t.startsWith('@')) {
      t = 'https://t.me/${t.substring(1)}';
    } else if (t.startsWith('t.me/')) {
      t = 'https://$t';
    }
    channelUrl = t.startsWith('http') ? t : '';
    unawaited(_store.setChannel(channelUrl));
  }

  Future<void> dismissAnnouncement() async {
    dismissedAnn = announcement;
    await _store.setDismissedAnn(announcement);
    notifyListeners();
  }

  // =====================================================================
  // پنل مدیر
  // =====================================================================
  String adminError = '';

  Future<bool> adminLogin(String pass) async {
    adminError = '';
    try {
      if (await Api.adminCheck(pass)) {
        _adminPass = pass;
        return true;
      }
      adminError = 'wrong password';
    } catch (e) {
      adminError = e.toString();
    }
    return false;
  }

  Future<bool> adminSaveServers(String text) async {
    try {
      final links = extractLinks(text);
      final blob = await CryptoBox.encrypt(links.join('\n'));
      final ok = await Api.adminSet(_adminPass, 'servers', blob);
      if (ok) {
        _officialLinks = links;
        await _store.setOfficialBlob(blob);
        await _store.setOfficialVer('');
        _rebuild();
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  Future<bool> adminSaveAnnouncement(String text) async {
    try {
      final ok = await Api.adminSet(_adminPass, 'announcement', text.trim());
      if (ok) {
        announcement = text.trim();
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  /// همه‌ی سرورهای رسمی را از همین شبکه (ایران) تست می‌کند و مرده‌ها را برمی‌گرداند
  Future<({Set<String> dead, int tested})?> adminTestOfficial() async {
    if (pingingAll) return null;
    final off = servers.where((s) => s.source == kOfficial).toList();
    if (off.isEmpty) return (dead: <String>{}, tested: 0);
    for (final s in off) {
      s.ping = null;
    }
    _cancelPing = false;
    pingingAll = true;
    pingDone = 0;
    pingTotal = off.length;
    notifyListeners();
    await _pingPool(off);
    pingingAll = false;
    notifyListeners();
    final tested = off.where((s) => s.ping != null).length;
    final dead = off.where((s) => (s.ping ?? 0) < 0).map((s) => s.id).toSet();
    return (dead: dead, tested: tested);
  }

  /// سرورهای رسمی با این شناسه‌ها را از لیست همه‌ی کاربران حذف می‌کند
  Future<bool> adminRemoveOfficial(Set<String> ids) async {
    final keep = <String>[];
    for (final l in _officialLinks) {
      final s = makeServer(l, kOfficial);
      if (s != null && ids.contains(s.id)) continue;
      keep.add(l);
    }
    return adminSaveServers(keep.join('\n'));
  }

  /// سرورهای کاندید ربات را با اینترنت همین گوشی (ایران) واقعاً تست می‌کند،
  /// مرده‌های فعلی را پیدا می‌کند و بهترین‌های تازه را برای اضافه شدن آماده می‌کند.
  /// null = مخزن کاندید خالی است یا تست ممکن نبود
  Future<({Set<String> dead, List<String> add, int tested, int candidates})?>
      adminFindServers({int maxTotal = 30}) async {
    if (pingingAll) return null;
    final blob = await Api.adminGet(_adminPass, 'candidates');
    if (blob.isEmpty) return null;
    final clear = await CryptoBox.decrypt(blob);
    if (clear == null) return null;
    final links = extractLinks(clear);

    // ۱) سرورهای فعلی
    final cur = await adminTestOfficial();
    if (cur == null) return null;
    if (cur.tested > 0 && cur.dead.length > cur.tested * 0.8) {
      return (dead: cur.dead, add: <String>[], tested: cur.tested, candidates: -1);
    }

    // ۲) کاندیدها (غیرتکراری)
    final have = <String>{
      for (final l in _officialLinks) (makeServer(l, kOfficial)?.id ?? '').replaceFirst('o', ''),
    };
    final tmp = <VpnServer>[];
    for (final l in links) {
      final s = makeServer(l, kManual);
      if (s == null) continue;
      if (have.contains(s.id.substring(1))) continue;
      have.add(s.id.substring(1));
      tmp.add(s);
      if (tmp.length >= 150) break;
    }
    if (tmp.isNotEmpty) {
      _cancelPing = false;
      pingingAll = true;
      pingDone = 0;
      pingTotal = tmp.length;
      notifyListeners();
      await _pingPool(tmp);
      pingingAll = false;
      notifyListeners();
    }
    final ok = tmp.where((s) => (s.ping ?? 0) > 0).toList()
      ..sort((a, b) => a.ping!.compareTo(b.ping!));
    final keepCount = _officialLinks.length - cur.dead.length;
    final room = (maxTotal - keepCount).clamp(0, 1000);
    return (
      dead: cur.dead,
      add: [for (final s in ok.take(room)) s.link],
      tested: tmp.length,
      candidates: ok.length,
    );
  }

  Future<bool> adminApplyFind(Set<String> dead, List<String> add) async {
    final keep = <String>[];
    for (final l in _officialLinks) {
      final s = makeServer(l, kOfficial);
      if (s != null && dead.contains(s.id)) continue;
      keep.add(l);
    }
    return adminSaveServers([...keep, ...add].join('\n'));
  }

  Future<bool> adminSaveUpdate(String platform, String ver, String url) async {
    final win = platform == 'win';
    try {
      final a = await Api.adminSet(
          _adminPass, win ? 'latest_win' : 'latest', ver.trim());
      final b = await Api.adminSet(
          _adminPass, win ? 'latest_url_win' : 'latest_url', url.trim());
      if (a && b) {
        if (win) {
          latestWin = ver.trim();
          urlWin = url.trim();
        } else {
          latestAndroid = ver.trim();
          urlAndroid = url.trim();
        }
        notifyListeners();
      }
      return a && b;
    } catch (_) {
      return false;
    }
  }

  Future<bool> adminSaveDonate(String text) async {
    try {
      final ok = await Api.adminSet(_adminPass, 'donate', text.trim());
      if (ok) {
        _setDonate(text);
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  Future<bool> adminSaveChannel(String text) async {
    try {
      final ok = await Api.adminSet(_adminPass, 'channel', text.trim());
      if (ok) {
        _setChannel(text);
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  // =====================================================================
  // ساب‌ها
  // =====================================================================
  Future<void> _saveSubs() =>
      _store.setSubs(subs.map((e) => e.toJson()).toList());

  /// خطا را به‌صورت کلید ترجمه برمی‌گرداند ، در موفقیت null
  Future<String?> addSub(String name, String url) async {
    final u = url.trim();
    final uri = Uri.tryParse(u);
    if (uri == null ||
        !(uri.scheme == 'http' || uri.scheme == 'https') ||
        uri.host.isEmpty) {
      return 'err_url';
    }
    final id = alvHash(u);
    if (subs.any((s) => s.id == id)) return null;
    final sub = SubInfo(
      id: id,
      name: name.trim().isEmpty ? uri.host : name.trim(),
      url: u,
    );
    final n = await _fetchSub(sub);
    if (n == null || n == 0) return 'err_sub_empty';
    subs.add(sub);
    await _saveSubs();
    _rebuild();
    notifyListeners();
    return null;
  }

  Future<int?> _fetchSub(SubInfo sub) async {
    try {
      final body = await Api.fetchText(sub.url);
      final links = parseSubscription(body);
      if (links.isEmpty) return null;
      await _store.setSubLinks(sub.id, links.join('\n'));
      sub.updated = DateTime.now().millisecondsSinceEpoch;
      sub.count = links.where(isSupportedLink).length;
      return sub.count;
    } catch (_) {
      return null;
    }
  }

  /// تعداد سرور بعد از به‌روزرسانی ، یا null در صورت خطا
  Future<int?> updateSub(SubInfo sub) async {
    final n = await _fetchSub(sub);
    if (n != null) {
      await _saveSubs();
      _rebuild();
      notifyListeners();
    }
    return n;
  }

  Future<void> updateAllSubs() async {
    if (updatingSubs || subs.isEmpty) return;
    updatingSubs = true;
    notifyListeners();
    for (final s in subs.toList()) {
      await _fetchSub(s);
    }
    await _saveSubs();
    _rebuild();
    updatingSubs = false;
    notifyListeners();
  }

  Future<void> updateSubsIfDue() async {
    if (subHours <= 0 || subs.isEmpty) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final limit = subHours * 3600 * 1000;
    final due = subs.where((s) => now - s.updated > limit).toList();
    if (due.isEmpty) return;
    for (final s in due) {
      await _fetchSub(s);
    }
    await _saveSubs();
    _rebuild();
    notifyListeners();
  }

  Future<void> removeSub(SubInfo sub) async {
    subs.removeWhere((s) => s.id == sub.id);
    await _store.removeSubLinks(sub.id);
    await _saveSubs();
    _rebuild();
    notifyListeners();
  }

  // =====================================================================
  // وضعیت زنده از هسته
  // =====================================================================
  void _onStatus(V2RayStatus s) {
    if (_dnsRun) {
      if (s.state == 'CONNECTED') {
        dnsOn = true;
        duration = s.duration;
        final w = _connectedWaiter;
        if (w != null && !w.isCompleted) w.complete(true);
      } else if (s.state == 'DISCONNECTED' && dnsOn) {
        dnsOn = false;
        _dnsRun = false;
        duration = '00:00:00';
      }
      notifyListeners();
      return;
    }
    duration = s.duration;
    upload = s.upload;
    download = s.download;
    uploadSpeed = s.uploadSpeed;
    downloadSpeed = s.downloadSpeed;

    if (s.state == 'CONNECTED') {
      final first = phase != VpnPhase.connected;
      phase = VpnPhase.connected;
      final w = _connectedWaiter;
      if (w != null && !w.isCompleted) w.complete(true);
      if (first) {
        connectedPing = null;
        Future.delayed(const Duration(seconds: 1), testConnectedPing);
      }
    } else if (s.state == 'DISCONNECTED') {
      if (phase == VpnPhase.connected && !switching) {
        _stopGuards();
        phase = VpnPhase.idle;
        _resetStats();
        unawaited(AetherRunner.stop());
      }
    }
    notifyListeners();
  }

  void _resetStats() {
    duration = '00:00:00';
    upload = download = uploadSpeed = downloadSpeed = 0;
    connectedPing = null;
  }

  // =====================================================================
  // جایگزینی خودکار سرور هنگام قطع ، سرور آماده‌باش ، مسابقه‌ی اتصال
  // =====================================================================
  bool autoSwitch = true;
  bool hotStandby = true;
  bool switching = false;
  int switchCount = 0;
  List<Object> noticeArgs = const [];
  int _wdGen = 0;
  int _sbGen = 0;
  int _pingGen = 0;
  bool _aetherPingBusy = false;
  final Map<String, DateTime> _bad = {};
  final Map<String, int> _okMs = {};
  final List<DateTime> _switchTimes = [];

  /// سرورهای Aether به ترتیب اولویت: سالم‌ها ، هم‌کشور با [like] ، کم‌پینگ ، قبلاً وصل‌شده
  List<VpnServer> _aetherCands({Set<String> exclude = const {}, VpnServer? like}) {
    final now = DateTime.now();
    final list =
        servers.where((s) => s.isAether && !exclude.contains(s.id)).toList();
    int cool(VpnServer s) {
      final t = _bad[s.id];
      return (t != null && now.difference(t).inSeconds < 150) ? 1 : 0;
    }

    int score(VpnServer s) {
      final p = s.ping;
      if (p != null && p > 0) return p;
      final k = _okMs[s.id];
      if (k != null && k > 0) return 3000 + k ~/ 4;
      if (p != null && p < 0) return 60000;
      return 20000;
    }

    int region(VpnServer s) =>
        (like != null && like.shownCountry == s.shownCountry) ? 0 : 1;

    list.sort((a, b) {
      final c = cool(a).compareTo(cool(b));
      if (c != 0) return c;
      final r = region(a).compareTo(region(b));
      if (r != 0) return r;
      return score(a).compareTo(score(b));
    });
    return list;
  }

  void _markOk(VpnServer s, int ms) {
    _bad.remove(s.id);
    if (ms <= 0) return;
    final old = _okMs[s.id];
    _okMs[s.id] = old == null ? ms : ((old * 2 + ms) ~/ 3);
    unawaited(_saveOk());
  }

  Future<void> _saveOk() async {
    try {
      await _store.setOkList(
          _okMs.entries.map((e) => '${e.key}=${e.value}').toList());
    } catch (_) {}
  }

  void _stopGuards() {
    _wdGen++;
    _sbGen++;
    final st = AetherRunner.standby;
    if (st != null) unawaited(AetherRunner.release(st));
  }

  void _startGuards() {
    _wdGen++;
    _sbGen++;
    if (!autoSwitch) return;
    final s = current;
    if (s == null) return;
    unawaited(_watchLoop(_wdGen));
    if (s.isAether && hotStandby) unawaited(_standbyLoop(_sbGen));
  }

  void _noteConnected(VpnServer s, int readyMs) {
    if (s.isAether) _markOk(s, readyMs);
    _startGuards();
  }

  /// آیا خود اینترنت گوشی کار می‌کند؟ (اتصال مستقیم ؛ برنامه‌ی ما از تونل مستثناست)
  Future<bool> _netUp() async {
    if (kPlatform == 'win') return true;
    const hosts = ['1.1.1.1', '8.8.8.8', '9.9.9.9'];
    final done = Completer<bool>();
    var left = hosts.length;
    for (final h in hosts) {
      unawaited(() async {
        try {
          final sk = await Socket.connect(h, 443,
              timeout: const Duration(milliseconds: 2500));
          sk.destroy();
          if (!done.isCompleted) done.complete(true);
        } catch (_) {
          left--;
          if (left == 0 && !done.isCompleted) done.complete(false);
        }
      }());
    }
    return done.future;
  }

  /// آیا تونل واقعاً ترافیک عبور می‌دهد؟
  Future<bool> _tunnelOk(VpnServer s) async {
    if (s.isAether) {
      if (!AetherRunner.running) return false;
      final ms =
          await AetherRunner.probe(wait: const Duration(milliseconds: 3500));
      return ms > 0;
    }
    try {
      final d = await _v2ray
          .getConnectedServerDelay(url: testUrl)
          .timeout(const Duration(seconds: 8));
      return d > 0;
    } catch (_) {
      return false;
    }
  }

  /// نگهبان: هر چند ثانیه سلامت تونل را می‌سنجد ؛ با قطع‌شدن سرور را عوض می‌کند
  Future<void> _watchLoop(int gen) async {
    var fails = 0;
    var netDown = false;
    var netDownSince = DateTime.now();
    var lastDown = download;
    while (gen == _wdGen) {
      await Future.delayed(Duration(milliseconds: fails > 0 ? 700 : 3000));
      if (gen != _wdGen) return;
      if (phase != VpnPhase.connected || switching || _dnsRun) continue;
      final s = current;
      if (s == null) continue;
      final dead = s.isAether && !AetherRunner.running;
      final ok = dead ? false : await _tunnelOk(s);
      if (gen != _wdGen || phase != VpnPhase.connected || switching) continue;
      // اگر داده در جریان است ، آزمایش ناموفق فقط از شلوغی تونل است (قطع نیست)
      final flowing = download - lastDown > 6000;
      lastDown = download;
      if (ok || (flowing && !dead)) {
        fails = 0;
        netDown = false;
        continue;
      }
      fails = dead ? 2 : fails + 1;
      if (fails < 2) continue;
      if (s.isAether) {
        // اگر خود اینترنت قطع است ، عوض‌کردن سرور فایده ندارد ؛ تا ۴۵ ثانیه منتظر می‌مانیم
        final up = await _netUp();
        if (gen != _wdGen) return;
        if (!up) {
          if (!netDown) {
            netDown = true;
            netDownSince = DateTime.now();
          }
          if (DateTime.now().difference(netDownSince).inSeconds < 45) {
            fails = 1;
            await Future.delayed(const Duration(milliseconds: 1500));
            continue;
          }
        } else if (netDown && !dead) {
          // اینترنت تازه برگشته: کمی صبر تا تونل خودش سالم شود
          netDown = false;
          var back = false;
          for (var k = 0; k < 5 && gen == _wdGen; k++) {
            await Future.delayed(const Duration(milliseconds: 1500));
            if (await _tunnelOk(s)) {
              back = true;
              break;
            }
          }
          if (back) {
            fails = 0;
            continue;
          }
        }
      }
      if (gen != _wdGen) return;
      fails = 0;
      netDown = false;
      await _failover(s, gen);
    }
  }

  /// سرور آماده‌باش: همیشه یک سرور Aether دیگر آماده نگه داشته می‌شود
  Future<void> _standbyLoop(int gen) async {
    var sbFails = 0;
    var lastCheck = DateTime.now();
    while (gen == _sbGen) {
      await Future.delayed(const Duration(milliseconds: 1500));
      if (gen != _sbGen) return;
      if (phase != VpnPhase.connected || switching) continue;
      final cur = current;
      if (cur == null || !cur.isAether) return;
      final st = AetherRunner.standby;
      if (st != null && st.busy) continue;
      if (st != null && st.ready) {
        sbFails = 0;
        if (DateTime.now().difference(lastCheck).inSeconds >= 20) {
          lastCheck = DateTime.now();
          final ms = await AetherRunner.probe(
              via: st.port, wait: const Duration(seconds: 5));
          if (gen != _sbGen) return;
          if (ms <= 0 && identical(AetherRunner.standby, st)) {
            final b = byId(st.tag);
            if (b != null) _bad[b.id] = DateTime.now();
            await AetherRunner.release(st);
          }
        }
        continue;
      }
      if (st != null) {
        // آماده‌باش قبلی خراب شد
        final b = byId(st.tag);
        if (b != null) _bad[b.id] = DateTime.now();
        await AetherRunner.release(st);
        sbFails++;
        final wait = sbFails * 5 > 60 ? 60 : sbFails * 5;
        await Future.delayed(Duration(seconds: wait));
        continue;
      }
      VpnServer? pick;
      AetherSpec? pickSpec;
      for (final c in _aetherCands(exclude: {cur.id}, like: cur)) {
        final sp = aetherFromConfig(c.config);
        if (sp == null) continue;
        if (!AetherRunner.hasKey(sp) || !AetherRunner.parallelOk(sp)) continue;
        pick = c;
        pickSpec = sp;
        break;
      }
      if (pick == null || pickSpec == null) {
        await Future.delayed(const Duration(seconds: 15));
        continue;
      }
      final lane = AetherRunner.newLane();
      if (lane == null) continue;
      AetherRunner.standby = lane;
      lastCheck = DateTime.now();
      unawaited(AetherRunner.launch(lane, pickSpec, pick.id,
          timeout: const Duration(seconds: 60)));
    }
  }

  /// هسته‌ی VPN را روی پورت فعلی Aether دوباره راه می‌اندازد (برای جایگزینی سرور)
  Future<bool> _restartCore(VpnServer s) async {
    try {
      try {
        await _v2ray.stopV2Ray();
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 350));
      final w = Completer<bool>();
      _connectedWaiter = w;
      final pkg = s.isAether ? androidPackageName() : null;
      await _v2ray.startV2Ray(
        remark: s.name,
        config: _coreConfig(s),
        proxyOnly: proxyOnly,
        bypassSubnets: bypassLan ? _lanSubnets : null,
        blockedApps: pkg == null ? null : [pkg],
        notificationDisconnectButtonName: 'X',
      );
      return await w.future
          .timeout(Duration(seconds: timeoutSec + 4), onTimeout: () => false);
    } catch (_) {
      return false;
    }
  }

  String _coreConfig(VpnServer s) {
    final c = stripAether(_applyDns(s.config));
    return s.isAether ? withAetherPort(c, AetherRunner.activePort) : c;
  }

  /// سرور فعلی قطع شد: سرور آماده‌باش (یا برنده‌ی مسابقه) جایگزین می‌شود
  Future<void> _failover(VpnServer from, int gen) async {
    final now = DateTime.now();
    _switchTimes.removeWhere((t) => now.difference(t).inMinutes >= 5);
    if (_switchTimes.length >= 6) {
      // احتمالاً مشکل از اینترنت است ؛ مدتی آرام می‌گیریم
      await Future.delayed(const Duration(seconds: 20));
      return;
    }
    _switchTimes.add(now);
    switching = true;
    _bad[from.id] = now;
    AetherRunner.note('== failover: ${from.name} stopped answering ==');
    notifyListeners();
    VpnServer? to;
    try {
      for (var round = 0; round < 2 && to == null && gen == _wdGen; round++) {
        to = from.isAether
            ? await _switchAether(from, gen)
            : await _switchNative(from, gen);
      }
    } catch (e) {
      AetherRunner.note('failover error: $e');
      to = null;
    }
    if (gen != _wdGen) {
      // کاربر در همین حین قطع کرد
      switching = false;
      return;
    }
    if (to != null) {
      switchCount++;
      current = to;
      connectedPing = null;
      notice = 'auto_switched';
      noticeArgs = [to.name];
      switching = false;
      notifyListeners();
      if (to.isAether) unawaited(_detectExit(to));
      Future.delayed(const Duration(seconds: 1), testConnectedPing);
      return;
    }
    switching = false;
    await disconnect();
    _fail('err_failed');
  }

  Future<VpnServer?> _switchAether(VpnServer from, int gen) async {
    AetherLane? lane = AetherRunner.standby;
    if (lane != null && lane.failed) {
      await AetherRunner.release(lane);
      lane = null;
    }
    if (lane != null && lane.ready) {
      // آماده‌باش هنوز زنده است؟ (آزمایش سریع)
      final ms = await AetherRunner.probe(
          via: lane.port, wait: const Duration(seconds: 3));
      if (ms <= 0) {
        final b = byId(lane.tag);
        if (b != null) _bad[b.id] = DateTime.now();
        await AetherRunner.release(lane);
        lane = null;
      }
    }
    if (gen != _wdGen) return null;
    VpnServer? target;
    if (lane != null && lane.ready) {
      target = byId(lane.tag);
    } else {
      final fs = aetherFromConfig(from.config);
      if (fs != null && !AetherRunner.parallelOk(fs)) {
        // پروتکل‌هایی که کلید مشترک دارند هم‌زمان اجرا نمی‌شوند
        await AetherRunner.stop();
        lane = null;
      }
      final seed = (lane != null && lane.busy) ? lane : null;
      final specs = <AetherSpec>[];
      final tags = <String>[];
      for (final c in _aetherCands(exclude: {from.id}, like: from)) {
        if (seed != null && seed.tag == c.id) continue;
        final sp = aetherFromConfig(c.config);
        if (sp == null) continue;
        specs.add(sp);
        tags.add(c.id);
      }
      lane = await AetherRunner.race(specs, tags,
          width: 3, cancelled: () => gen != _wdGen, seed: seed);
      target = lane == null ? null : byId(lane.tag);
    }
    if (lane == null) return null;
    if (target == null || gen != _wdGen) {
      await AetherRunner.release(lane);
      return null;
    }
    AetherRunner.adopt(lane);
    current = target;
    notifyListeners();
    final ok = await _restartCore(target);
    if (gen != _wdGen) {
      try {
        await _v2ray.stopV2Ray();
      } catch (_) {}
      await AetherRunner.stop();
      return null;
    }
    if (ok) {
      _markOk(target, lane.readyMs);
      AetherRunner.note('failover done: now on ${target.name}');
      return target;
    }
    AetherRunner.note('failover: the vpn core did not start on ${target.name}');
    _bad[target.id] = DateTime.now();
    await AetherRunner.stop();
    return null;
  }

  /// جایگزینی برای سرورهای غیر Aether: بهترین سرور بعدی را آزمایش و وصل می‌کند
  Future<VpnServer?> _switchNative(VpnServer from, int gen) async {
    final now = DateTime.now();
    final pool = _autoServers.where((s) => s.id != from.id).toList();
    bool cool(VpnServer s) {
      final t = _bad[s.id];
      return t != null && now.difference(t).inSeconds < 150;
    }

    pool.sort((a, b) {
      final c = (cool(a) ? 1 : 0).compareTo(cool(b) ? 1 : 0);
      return c != 0 ? c : _rank(a).compareTo(_rank(b));
    });
    var tries = 0;
    for (final s in pool) {
      if (gen != _wdGen || tries >= 5) break;
      tries++;
      await _measure(s);
      if ((s.ping ?? -1) <= 0) {
        _bad[s.id] = DateTime.now();
        continue;
      }
      if (gen != _wdGen) return null;
      if (await _restartCore(s)) return s;
      _bad[s.id] = DateTime.now();
    }
    return null;
  }

  /// اتصال اولیه: همه‌ی سرورهای Aether (رتبه‌بندی‌شده) را هم‌زمان می‌آزماید ؛ اولین آماده می‌شود
  Future<bool> _connectAetherRace({VpnServer? like, Set<String> exclude = const {}}) async {
    final specs = <AetherSpec>[];
    final tags = <String>[];
    for (final s in _aetherCands(exclude: exclude, like: like)) {
      final sp = aetherFromConfig(s.config);
      if (sp == null) continue;
      specs.add(sp);
      tags.add(s.id);
    }
    if (specs.isEmpty) return false;
    phase = VpnPhase.connecting;
    current = null;
    aetherError = '';
    notifyListeners();
    await AetherRunner.stop();
    AetherRunner.resetLog(
        '== ${DateTime.now().toIso8601String()} | race ${specs.length} aether servers ==');
    await AetherRunner.ensureKeys(specs);
    if (_cancel) return false;
    final lane = await AetherRunner.race(specs, tags,
        width: 3, cancelled: () => _cancel);
    if (_cancel) {
      await AetherRunner.stop();
      return false;
    }
    final s = lane == null ? null : byId(lane.tag);
    if (lane == null || s == null) {
      aetherError = AetherRunner.summary();
      await AetherRunner.stop();
      return false;
    }
    return _startOn(s, lane: lane);
  }

  /// پینگ هم‌زمان همه‌ی سرورهای Aether (چند نمونه با هم)
  Future<void> _pingAetherAll() async {
    if (_cancelPing) return;
    if (phase == VpnPhase.connected ||
        phase == VpnPhase.connecting ||
        phase == VpnPhase.searching) {
      return;
    }
    final specs = <AetherSpec>[];
    final owners = <VpnServer>[];
    for (final s in servers) {
      if (!s.isAether) continue;
      final sp = aetherFromConfig(s.config);
      if (sp == null) {
        s.ping = -1;
        continue;
      }
      specs.add(sp);
      owners.add(s);
      s.ping = null;
      pinging.add(s.id);
    }
    if (specs.isEmpty) return;
    _aetherPingBusy = true;
    final gen = ++_pingGen;
    notifyListeners();
    try {
      await AetherRunner.pingMany(
        specs,
        cancelled: () => gen != _pingGen || _cancelPing,
        onResult: (i, ms, cc) {
          if (gen != _pingGen) return;
          final s = owners[i];
          pinging.remove(s.id);
          s.ping = ms > 0 ? ms : -1;
          if (ms > 0 && cc.length == 2) unawaited(_setExit(s, cc));
          pingDone++;
          notifyListeners();
        },
      );
    } catch (_) {}
    for (final s in owners) {
      pinging.remove(s.id);
    }
    _aetherPingBusy = false;
    notifyListeners();
  }

  // =====================================================================
  // دکمه‌ی اصلی
  // =====================================================================
  Future<void> toggle() async {
    if (phase == VpnPhase.searching || phase == VpnPhase.connecting) {
      await cancelConnect();
    } else if (phase == VpnPhase.connected) {
      await disconnect();
    } else {
      await connect();
    }
  }

  Future<void> cancelConnect() async {
    _cancel = true;
    _cancelPing = true;
    _stopGuards();
    switching = false;
    final w = _connectedWaiter;
    if (w != null && !w.isCompleted) w.complete(false);
    try {
      await _v2ray.stopV2Ray();
    } catch (_) {}
    await AetherRunner.stop();
    phase = VpnPhase.idle;
    notifyListeners();
  }

  Future<void> disconnect() async {
    _stopGuards();
    switching = false;
    try {
      await _v2ray.stopV2Ray();
    } catch (_) {}
    await AetherRunner.stop();
    _resetStats();
    phase = VpnPhase.idle;
    notifyListeners();
  }

  void _fail(String key, [List<Object> args = const []]) {
    phase = VpnPhase.failed;
    msgKey = key;
    msgArgs = args;
    notifyListeners();
  }

  Future<void> connect() async {
    if (dnsOn || _dnsRun) {
      await stopDns();
      notice = 'dns_stopped_for_vpn';
    }
    _cancel = false;
    _cancelPing = false;
    msgKey = null;
    if (_aetherPingBusy) {
      _pingGen++;
      await AetherRunner.stop();
    }

    if (servers.isEmpty) {
      _fail('err_no_server');
      return;
    }

    var allowed = false;
    try {
      allowed = await _v2ray.requestPermission();
    } catch (_) {}
    if (!allowed) {
      _fail('err_perm');
      return;
    }

    final sel = selected;
    if (sel != null) {
      final ok = await _startOn(sel,
          aetherTimeout: autoSwitch ? const Duration(seconds: 50) : null);
      if (_cancel) return;
      if (!ok && sel.isAether && autoSwitch) {
        // سرور انتخابی وصل نشد ← بهترین جایگزین (ترجیحاً هم‌کشور) را هم‌زمان می‌آزماییم
        final ok2 = await _connectAetherRace(like: sel, exclude: {sel.id});
        if (_cancel) return;
        if (ok2) {
          notice = 'auto_switched';
          noticeArgs = [current?.name ?? ''];
          notifyListeners();
          return;
        }
      }
      if (!ok) {
        if (sel.isAether) {
          _fail('err_aether', [aetherError]);
        } else {
          _fail('err_sel', [sel.name]);
        }
      }
      return;
    }
    await _connectFastest();
  }

  Future<void> _connectFastest() async {
    if (_aetherCands().isNotEmpty) {
      final ok = await _connectAetherRace();
      if (_cancel || ok) return;
      if (_autoServers.isEmpty) {
        _fail('err_aether', [aetherError]);
        return;
      }
    }
    phase = VpnPhase.searching;
    pingDone = 0;
    notifyListeners();

    final pool = gamingMode ? _gamingPool() : _autoServers;
    final order = [...pool]..sort((a, b) => _rank(a).compareTo(_rank(b)));
    for (final s in servers) {
      s.ping = null;
    }
    await _pingPool(order, stopAfter: gamingMode ? 20 : 8);
    if (_cancel) return;

    final ranked = pool.where((s) => (s.ping ?? -1) > 0).toList()
      ..sort((a, b) => a.ping!.compareTo(b.ping!));

    if (ranked.isEmpty) {
      _fail('err_none');
      return;
    }

    for (final s in _gamingOrder(ranked)) {
      if (_cancel) return;
      if (await _startOn(s)) return;
    }
    if (_cancel) return;
    _fail('err_failed');
  }

  /// Aether در انتخاب خودکار نمی‌آید (پینگ ندارد ؛ فقط دستی انتخاب می‌شود)
  List<VpnServer> get _autoServers =>
      servers.where((s) => !s.isAether).toList();

  List<VpnServer> _gamingPool() {
    final g = _autoServers.where((s) => kGamingCountries.contains(s.country)).toList();
    return g.isEmpty ? _autoServers : g;
  }

  /// حالت گیمینگ: بین ۳ سرور کم‌پینگ‌تر تصادفی انتخاب می‌کند
  List<VpnServer> _gamingOrder(List<VpnServer> ranked) {
    if (!gamingMode || ranked.length < 2) return ranked.take(5).toList();
    final top = ranked.take(3).toList()..shuffle(Random());
    return [...top, ...ranked.skip(3)].take(5).toList();
  }

  List<String> _dnsServers() => dnsIps('conn');

  /// آدرس‌های DNS برای هدف «conn» یا «game»
  List<String> dnsIps(String purpose) {
    final game = purpose == 'game';
    final key = game ? dnsGameKey : dnsKey;
    final custom = game ? dnsGameCustom : dnsCustom;
    if (key == 'custom') return parseDnsList(custom);
    for (final p in (game ? kDnsGame : kDnsConn)) {
      if (p.key == key) return p.ips;
    }
    return <String>[];
  }

  String _applyDns(String cfg) {
    final list = _dnsServers();
    if (list.isEmpty) return cfg;
    try {
      final m = jsonDecode(cfg) as Map<String, dynamic>;
      final d = m['dns'] is Map
          ? Map<String, dynamic>.from(m['dns'] as Map)
          : <String, dynamic>{};
      d['servers'] = list;
      m['dns'] = d;
      return jsonEncode(m);
    } catch (_) {
      return cfg;
    }
  }

  int _rank(VpnServer s) {
    final p = s.ping;
    if (p == null) return 1 << 20;
    if (p > 0) return p;
    return 1 << 21;
  }

  Future<void> _setExit(VpnServer s, String cc) async {
    if (cc.length != 2) return;
    s.exitCountry = cc;
    if (_exit[s.id] != cc) {
      _exit[s.id] = cc;
      try {
        await _store.setExitList(
            _exit.entries.map((e) => '${e.key}=${e.value}').toList());
      } catch (_) {}
    }
    notifyListeners();
  }

  /// کشور خروجی سرور Aether را از راه خود تونل می‌پرسد (بی‌صدا ؛ اگر نشد هیچ اتفاقی نمی‌افتد)
  Future<void> _detectExit(VpnServer s) async {
    try {
      final cc = await AetherRunner.exitCountry();
      if (cc.isNotEmpty) await _setExit(s, cc);
    } catch (_) {}
  }

  Future<bool> _startOn(VpnServer s,
      {AetherLane? lane, Duration? aetherTimeout}) async {
    current = s;
    phase = VpnPhase.connecting;
    notifyListeners();

    aetherError = '';
    var readyMs = -1;
    if (s.isAether) {
      if (lane != null) {
        AetherRunner.adopt(lane);
        readyMs = lane.readyMs;
      } else {
        final sw = Stopwatch()..start();
        final spec = aetherFromConfig(s.config);
        if (spec == null ||
            !await AetherRunner.start(spec, timeout: aetherTimeout)) {
          aetherError = AetherRunner.summary();
          await AetherRunner.stop();
          return false;
        }
        readyMs = sw.elapsedMilliseconds;
      }
      unawaited(_detectExit(s));
      AetherRunner.note('aether ready; starting the vpn core');
    } else {
      await AetherRunner.stop();
    }

    final w = Completer<bool>();
    _connectedWaiter = w;
    try {
      final pkg = s.isAether ? androidPackageName() : null;
      await _v2ray.startV2Ray(
        remark: s.name,
        config: _coreConfig(s),
        proxyOnly: proxyOnly,
        bypassSubnets: bypassLan ? _lanSubnets : null,
        blockedApps: pkg == null ? null : [pkg],
        notificationDisconnectButtonName: 'X',
      );
    } catch (_) {
      await AetherRunner.stop();
      return false;
    }
    if (s.isAether) AetherRunner.note('startV2Ray returned; waiting for the connected state');
    final ok = await w.future
        .timeout(Duration(seconds: timeoutSec), onTimeout: () => false);
    if (s.isAether) AetherRunner.note('vpn core connected: $ok');
    if (!ok) {
      try {
        await _v2ray.stopV2Ray();
      } catch (_) {}
      await AetherRunner.stop();
    }
    if (ok && !_cancel) _noteConnected(s, readyMs);
    return ok && !_cancel;
  }

  // =====================================================================
  // انتخاب سرور
  // =====================================================================
  Future<void> select(String? id) async {
    selectedId = id;
    await _store.setSelected(id);
    notifyListeners();
    if (phase == VpnPhase.connected) {
      await disconnect();
      await Future.delayed(const Duration(milliseconds: 400));
      await connect();
    }
  }

  Future<void> toggleFavorite(VpnServer s) async {
    if (!favorites.add(s.id)) favorites.remove(s.id);
    await _store.setFavorites(favorites.toList());
    notifyListeners();
  }

  // =====================================================================
  // تست پینگ
  // =====================================================================
  Future<void> pingOne(VpnServer s) async {
    pinging.add(s.id);
    notifyListeners();
    await _measure(s);
    pinging.remove(s.id);
    notifyListeners();
  }

  Future<void> _measure(VpnServer s) async {
    if (s.isAether) {
      // پینگ Aether: خودش را اجرا می‌کند ؛ فقط وقتی اتصالی در کار نیست
      if (phase == VpnPhase.connected ||
          phase == VpnPhase.connecting ||
          phase == VpnPhase.searching) {
        s.ping = null;
        return;
      }
      if (_aetherPingBusy) return;
      final spec = aetherFromConfig(s.config);
      if (spec == null) {
        s.ping = -1;
        return;
      }
      final ms = await AetherRunner.ping(spec);
      s.ping = ms > 0 ? ms : -1;
      if (ms > 0 && AetherRunner.lastExit.isNotEmpty) {
        await _setExit(s, AetherRunner.lastExit);
      }
      return;
    }
    try {
      final d = await _v2ray
          .getServerDelay(config: s.config, url: testUrl)
          .timeout(const Duration(seconds: 5));
      s.ping = d > 0 ? d : -1;
    } catch (_) {
      s.ping = -1;
    }
  }

  Future<void> pingAll() async {
    if (pingingAll) return;
    _cancelPing = false;
    pingingAll = true;
    pingDone = 0;
    pingTotal = servers.length;
    notifyListeners();
    await _pingPool(servers.toList());
    await _pingAetherAll();
    pingingAll = false;
    notifyListeners();
  }

  void cancelPingAll() {
    _cancelPing = true;
  }

  Future<void> _pingPool(
    List<VpnServer> list, {
    int stopAfter = 0,
    int workers = 12,
  }) async {
    var i = 0;
    var ok = 0;
    var stop = false;

    Future<void> worker() async {
      while (!stop && !_cancelPing) {
        if (i >= list.length) return;
        final s = list[i++];
        if (s.isAether) continue;
        pinging.add(s.id);
        await _measure(s);
        pinging.remove(s.id);
        pingDone++;
        if ((s.ping ?? -1) > 0) {
          ok++;
          if (stopAfter > 0 && ok >= stopAfter) stop = true;
        }
        notifyListeners();
      }
    }

    await Future.wait(List.generate(workers, (_) => worker()));
  }

  Future<void> testConnectedPing() async {
    if (phase != VpnPhase.connected || testingPing) return;
    testingPing = true;
    notifyListeners();
    try {
      final d = await _v2ray.getConnectedServerDelay(url: testUrl);
      connectedPing = d > 0 ? d : -1;
    } catch (_) {
      connectedPing = -1;
    }
    testingPing = false;
    notifyListeners();
  }

  // =====================================================================
  // سرورهای دستی
  // =====================================================================
  Future<AddResult> addLinks(String text) async {
    final links = extractLinks(text);
    final existing = servers.map((s) => s.id.substring(1)).toSet();
    final manual = _store.manual;
    var added = 0;
    var skipped = 0;
    for (final l in links) {
      if (!isSupportedLink(l)) {
        skipped++;
        continue;
      }
      final probe = makeServer(l, kManual);
      if (probe == null) continue;
      if (existing.contains(probe.id.substring(1))) continue;
      existing.add(probe.id.substring(1));
      manual.add(l);
      added++;
    }
    if (added > 0) {
      await _store.setManual(manual);
      _rebuild();
      notifyListeners();
    }
    return AddResult(added, skipped);
  }

  Future<void> removeManual(VpnServer s) async {
    final manual = _store.manual..removeWhere((l) => l.trim() == s.link);
    await _store.setManual(manual);
    favorites.remove(s.id);
    await _store.setFavorites(favorites.toList());
    _rebuild();
    notifyListeners();
  }

  Future<void> clearManual() async {
    await _store.setManual(<String>[]);
    _rebuild();
    notifyListeners();
  }

  Future<void> clearFavorites() async {
    favorites.clear();
    await _store.setFavorites(<String>[]);
    notifyListeners();
  }

  // =====================================================================
  // تنظیمات
  // =====================================================================
  Future<void> setAutoConnect(bool v) async {
    autoConnectOnLaunch = v;
    await _store.setAutoConnect(v);
    notifyListeners();
  }

  Future<void> setBypassLan(bool v) async {
    bypassLan = v;
    await _store.setBypassLan(v);
    notifyListeners();
  }

  Future<void> setProxyOnly(bool v) async {
    proxyOnly = v;
    await _store.setProxyOnly(v);
    notifyListeners();
  }

  Future<void> setAutoSwitch(bool v) async {
    autoSwitch = v;
    await _store.setAutoSwitch(v);
    if (phase == VpnPhase.connected) {
      if (v) {
        _startGuards();
      } else {
        _stopGuards();
      }
    }
    notifyListeners();
  }

  Future<void> setHotStandby(bool v) async {
    hotStandby = v;
    await _store.setHotStandby(v);
    if (phase == VpnPhase.connected && autoSwitch) {
      _sbGen++;
      if (v && current?.isAether == true) {
        unawaited(_standbyLoop(_sbGen));
      } else {
        final st = AetherRunner.standby;
        if (st != null) unawaited(AetherRunner.release(st));
      }
    }
    notifyListeners();
  }

  // =====================================================================
  // بخش DNS
  // =====================================================================
  Future<void> setAppMode(String m) async {
    if (appMode == m) return;
    appMode = m;
    await _store.setAppMode(m);
    notifyListeners();
  }

  Future<void> setDnsPurpose(String p) async {
    dnsPurpose = p;
    await _store.setDnsPurpose(p);
    notifyListeners();
  }

  String dnsKeyOf(String purpose) => purpose == 'game' ? dnsGameKey : dnsKey;
  String dnsCustomOf(String purpose) =>
      purpose == 'game' ? dnsGameCustom : dnsCustom;

  Future<void> chooseDns(String purpose, String key, [String? custom]) async {
    if (purpose == 'game') {
      dnsGameKey = key;
      await _store.setDnsGameKey(key);
      if (custom != null) {
        dnsGameCustom = custom;
        await _store.setDnsGameCustom(custom);
      }
    } else {
      dnsKey = key;
      await _store.setDnsKey(key);
      if (custom != null) {
        dnsCustom = custom;
        await _store.setDnsCustom(custom);
      }
    }
    notifyListeners();
    if (dnsOn && purpose == dnsPurpose) {
      await stopDns();
      await startDns();
    }
  }

  /// DNS نهایی برای حالت «فقط DNS» (اگر برای اتصال «پیش‌فرض» بود Cloudflare)
  List<String> _activeDns() {
    final l = dnsIps(dnsPurpose);
    if (l.isNotEmpty) return l;
    return const ['1.1.1.1', '1.0.0.1'];
  }

  String _activeDnsName() {
    final key = dnsKeyOf(dnsPurpose);
    if (key == 'custom') return i18n.tr('dns_custom');
    for (final p in (dnsPurpose == 'game' ? kDnsGame : kDnsConn)) {
      if (p.key == key) return p.name;
    }
    return 'Cloudflare';
  }

  Future<void> toggleDns() async {
    if (dnsBusy) return;
    if (dnsOn) {
      await stopDns();
    } else {
      await startDns();
    }
  }

  Future<bool> startDns() async {
    if (dnsBusy) return false;
    dnsBusy = true;
    dnsFail = '';
    notifyListeners();
    try {
      if (phase == VpnPhase.connected ||
          phase == VpnPhase.connecting ||
          phase == VpnPhase.searching) {
        await cancelConnect();
        await disconnect();
        notice = 'dns_vpn_stopped';
      }
      var allowed = false;
      try {
        allowed = await _v2ray.requestPermission();
      } catch (_) {}
      if (!allowed) {
        dnsFail = 'perm';
        return false;
      }

      _dnsRun = true;
      dnsActiveName = _activeDnsName();
      final w = Completer<bool>();
      _connectedWaiter = w;
      await _v2ray.startV2Ray(
        remark: 'DNS',
        config: dnsOnlyConfig(_activeDns()),
        proxyOnly: false,
        bypassSubnets: null,
        blockedApps: null,
        notificationDisconnectButtonName: 'X',
      );
      final ok = await w.future
          .timeout(const Duration(seconds: 8), onTimeout: () => false);
      if (!ok) {
        dnsFail = 'timeout';
        try {
          await _v2ray.stopV2Ray();
        } catch (_) {}
        _dnsRun = false;
        dnsOn = false;
      }
      return ok;
    } catch (e) {
      dnsFail = e.toString();
      _dnsRun = false;
      dnsOn = false;
      return false;
    } finally {
      dnsBusy = false;
      notifyListeners();
    }
  }

  Future<void> stopDns() async {
    try {
      await _v2ray.stopV2Ray();
    } catch (_) {}
    dnsOn = false;
    _dnsRun = false;
    duration = '00:00:00';
    notifyListeners();
  }

  Future<void> setGaming(bool v) async {
    gamingMode = v;
    await _store.setGaming(v);
    notifyListeners();
  }

  Future<void> setDns(String key, String custom) async {
    dnsKey = key;
    dnsCustom = custom;
    await _store.setDnsKey(key);
    await _store.setDnsCustom(custom);
    notifyListeners();
  }

  Future<void> setTestUrl(String key) async {
    testUrlKey = key;
    await _store.setTestUrlKey(key);
    notifyListeners();
  }

  Future<void> setTimeoutSec(int v) async {
    timeoutSec = v;
    await _store.setTimeoutSec(v);
    notifyListeners();
  }

  Future<void> setSubHours(int v) async {
    subHours = v;
    await _store.setSubHours(v);
    notifyListeners();
  }

  Future<void> setLang(String l) async {
    i18n.lang = l;
    await _store.setLang(l);
    look.value++;
    notifyListeners();
  }

  Future<void> setThemeKey(String k) async {
    themeKey = k;
    applyTheme(k);
    await _store.setTheme(k);
    look.value++;
    notifyListeners();
  }

  Future<void> finishWelcome() async {
    welcomed = true;
    await _store.setWelcomed(true);
    notifyListeners();
  }

  @override
  void dispose() {
    _beat?.cancel();
    super.dispose();
  }
}
