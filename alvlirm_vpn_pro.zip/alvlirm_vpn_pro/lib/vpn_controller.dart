import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_v2ray_client/flutter_v2ray.dart';

import 'api.dart';
import 'config.dart';
import 'crypto_box.dart';
import 'i18n.dart' as i18n;
import 'server.dart';
import 'store.dart';
import 'theme.dart';

enum VpnPhase { idle, searching, connecting, connected, failed }

const testUrls = <String, String>{
  'Google': 'https://www.google.com/generate_204',
  'Cloudflare': 'https://cp.cloudflare.com/generate_204',
  'Gstatic': 'https://www.gstatic.com/generate_204',
};

const _lanSubnets = <String>[
  '10.0.0.0/8',
  '172.16.0.0/12',
  '192.168.0.0/16',
  '127.0.0.0/8',
];

/// یک لینک اشتراک (ساب)
class SubInfo {
  SubInfo({
    required this.id,
    required this.name,
    required this.url,
    this.updated = 0,
    this.count = 0,
  });
  final String id;
  String name;
  final String url;
  int updated; // میلی‌ثانیه
  int count;

  String toJson() => jsonEncode({
        'id': id,
        'name': name,
        'url': url,
        'updated': updated,
        'count': count,
      });

  static SubInfo? fromJson(String s) {
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      return SubInfo(
        id: m['id'] as String,
        name: (m['name'] ?? '') as String,
        url: m['url'] as String,
        updated: (m['updated'] ?? 0) as int,
        count: (m['count'] ?? 0) as int,
      );
    } catch (_) {
      return null;
    }
  }
}

class AddResult {
  AddResult(this.added, this.skipped);
  final int added;
  final int skipped;
}

class VpnController extends ChangeNotifier {
  VpnController();

  late final V2ray _v2ray = V2ray(onStatusChanged: _onStatus);
  late Store _store;

  // ---------- داده‌ها ----------
  List<VpnServer> servers = [];
  List<String> _seedLinks = [];
  List<String> _officialLinks = [];
  List<SubInfo> subs = [];
  Set<String> favorites = {};
  String? selectedId;

  // ---------- تنظیمات ----------
  bool autoConnectOnLaunch = false;
  bool bypassLan = false;
  bool proxyOnly = false;
  bool gamingMode = false;
  String dnsKey = 'default';
  String dnsCustom = '';
  String testUrlKey = 'Google';
  int timeoutSec = 10;
  int subHours = 6;
  String themeKey = 'night';
  bool welcomed = false;
  String get testUrl => testUrls[testUrlKey] ?? testUrls.values.first;

  // ---------- آنلاین / اطلاعیه ----------
  int? online;
  int? totalUsers;
  String announcement = '';
  String dismissedAnn = '';
  bool get showAnnouncement =>
      announcement.isNotEmpty && announcement != dismissedAnn;
  Timer? _beat;
  String channelUrl = '';
  String latestVersion = '';
  String latestUrl = '';
  String dismissedUpd = '';

  static bool _newer(String a, String b) {
    List<int> p(String s) =>
        s.split('.').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    final x = p(a), y = p(b);
    for (var i = 0; i < 3; i++) {
      final xi = i < x.length ? x[i] : 0;
      final yi = i < y.length ? y[i] : 0;
      if (xi != yi) return xi > yi;
    }
    return false;
  }

  bool get updateAvailable =>
      latestUrl.startsWith('http') &&
      latestVersion.isNotEmpty &&
      _newer(latestVersion, kVersion) &&
      latestVersion != dismissedUpd;

  Future<void> dismissUpdate() async {
    dismissedUpd = latestVersion;
    await _store.setDismissedUpd(latestVersion);
    notifyListeners();
  }
  String _adminPass = '';

  // ---------- وضعیت اتصال ----------
  VpnPhase phase = VpnPhase.idle;
  VpnServer? current;
  String? msgKey;
  List<Object> msgArgs = const [];
  String duration = '00:00:00';
  int upload = 0;
  int download = 0;
  int uploadSpeed = 0;
  int downloadSpeed = 0;
  int? connectedPing;
  bool testingPing = false;

  // ---------- تست پینگ ----------
  final Set<String> pinging = {};
  bool pingingAll = false;
  int pingDone = 0;
  int pingTotal = 0;
  bool updatingSubs = false;

  Completer<bool>? _connectedWaiter;
  bool _cancel = false;
  bool _cancelPing = false;

  VpnServer? byId(String? id) {
    if (id == null) return null;
    for (final s in servers) {
      if (s.id == id) return s;
    }
    return null;
  }

  VpnServer? get selected => byId(selectedId);
  String get officialText => _officialLinks.join('\n');
  int get officialCount => _officialLinks.length;

  // =====================================================================
  // راه‌اندازی
  // =====================================================================
  Future<void> init() async {
    _store = await Store.open();

    i18n.lang = _store.lang ?? 'fa';
    themeKey = _store.theme;
    applyTheme(themeKey);
    welcomed = _store.welcomed;
    dismissedAnn = _store.dismissedAnn;
    dismissedUpd = _store.dismissedUpd;

    favorites = _store.favorites.toSet();
    selectedId = _store.selected;
    autoConnectOnLaunch = _store.autoConnect;
    bypassLan = _store.bypassLan;
    proxyOnly = _store.proxyOnly;
    gamingMode = _store.gaming;
    dnsKey = _store.dnsKey;
    dnsCustom = _store.dnsCustom;
    testUrlKey = _store.testUrlKey;
    if (!testUrls.containsKey(testUrlKey)) testUrlKey = 'Google';
    timeoutSec = _store.timeoutSec;
    subHours = _store.subHours;

    // سرورهای اولیه‌ی داخل برنامه (رمزشده)
    try {
      final enc = await rootBundle.loadString('assets/servers.enc');
      final clear = await CryptoBox.decrypt(enc);
      _seedLinks = clear == null ? <String>[] : extractLinks(clear);
    } catch (_) {
      _seedLinks = <String>[];
    }
    _officialLinks = _seedLinks;

    // آخرین لیست دریافت‌شده از سرور (کش)
    final cached = _store.officialBlob;
    if (cached.isNotEmpty) {
      final clear = await CryptoBox.decrypt(cached);
      if (clear != null) _officialLinks = extractLinks(clear);
    }

    _setChannel(_store.channel);
    subs = _store.subs.map(SubInfo.fromJson).whereType<SubInfo>().toList();

    _rebuild();

    try {
      await _v2ray.initialize(
        notificationIconResourceType: 'mipmap',
        notificationIconResourceName: 'ic_launcher',
      );
    } catch (e) {
      msgKey = 'err_core';
      msgArgs = [e];
    }

    unawaited(refreshRemote());
    unawaited(updateSubsIfDue());
    _beat = Timer.periodic(const Duration(seconds: 60), (_) => refreshRemote());
  }

  void _rebuild() {
    final old = <String, int?>{for (final s in servers) s.id: s.ping};
    final out = <VpnServer>[];
    final seen = <String>{};
    final counters = <String, int>{};

    void addAll(List<String> links, int src, String? subId) {
      for (final l in links) {
        final s = makeServer(l, src, subId: subId);
        if (s == null) continue;
        if (!seen.add(s.id.substring(1))) continue;
        if (src == kOfficial || s.name.isEmpty) {
          final n = (counters[s.country] ?? 0) + 1;
          counters[s.country] = n;
          s.name = n == 1 ? 'AlvlIRm-${s.country}' : 'AlvlIRm-${s.country}-$n';
        } else if (s.name.length > 30) {
          s.name = s.name.substring(0, 30);
        }
        s.ping = old[s.id];
        out.add(s);
      }
    }

    addAll(_officialLinks, kOfficial, null);
    for (final sub in subs) {
      addAll(_splitLines(_store.subLinks(sub.id)), kSub, sub.id);
    }
    addAll(_store.manual, kManual, null);

    servers = out;
    if (selectedId != null && byId(selectedId) == null) selectedId = null;
  }

  List<String> _splitLines(String s) =>
      s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

  Future<String> coreVersion() async {
    try {
      return await _v2ray.getCoreVersion();
    } catch (_) {
      return '-';
    }
  }

  // =====================================================================
  // سرورهای رسمی از راه دور + شمارنده‌ی آنلاین
  // =====================================================================
  Future<bool> refreshRemote() async {
    if (!apiEnabled) return false;
    var ok = false;
    try {
      final j = await Api.meta(_store.deviceId, _store.officialVer);
      if (j is Map) {
        online = (j['online'] as num?)?.toInt();
        totalUsers = (j['total'] as num?)?.toInt();
        announcement = (j['announcement'] ?? '').toString();
        _setChannel((j['channel'] ?? '').toString());
        latestVersion = (j['latest'] ?? '').toString().trim();
        latestUrl = (j['latest_url'] ?? '').toString().trim();
        final ver = (j['ver'] ?? '').toString();
        final blob = (j['servers'] ?? '').toString();
        if (blob.isNotEmpty) {
          if (blob != _store.officialBlob) {
            final clear = await CryptoBox.decrypt(blob);
            if (clear != null) {
              _officialLinks = extractLinks(clear);
              await _store.setOfficialBlob(blob);
              await _store.setOfficialVer(ver);
              _rebuild();
            }
          } else {
            await _store.setOfficialVer(ver);
          }
        }
        ok = true;
      }
    } catch (_) {}
    notifyListeners();
    return ok;
  }

  void _setChannel(String raw) {
    var t = raw.trim();
    if (t.startsWith('@')) {
      t = 'https://t.me/${t.substring(1)}';
    } else if (t.startsWith('t.me/')) {
      t = 'https://$t';
    }
    channelUrl = t.startsWith('http') ? t : '';
    unawaited(_store.setChannel(channelUrl));
  }

  Future<void> dismissAnnouncement() async {
    dismissedAnn = announcement;
    await _store.setDismissedAnn(announcement);
    notifyListeners();
  }

  // =====================================================================
  // پنل مدیر
  // =====================================================================
  Future<bool> adminLogin(String pass) async {
    try {
      if (await Api.adminCheck(pass)) {
        _adminPass = pass;
        return true;
      }
    } catch (_) {}
    return false;
  }

  Future<bool> adminSaveServers(String text) async {
    try {
      final links = extractLinks(text);
      final blob = await CryptoBox.encrypt(links.join('\n'));
      final ok = await Api.adminSet(_adminPass, 'servers', blob);
      if (ok) {
        _officialLinks = links;
        await _store.setOfficialBlob(blob);
        await _store.setOfficialVer('');
        _rebuild();
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  Future<bool> adminSaveAnnouncement(String text) async {
    try {
      final ok = await Api.adminSet(_adminPass, 'announcement', text.trim());
      if (ok) {
        announcement = text.trim();
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  Future<bool> adminSaveUpdate(String ver, String url) async {
    try {
      final a = await Api.adminSet(_adminPass, 'latest', ver.trim());
      final b = await Api.adminSet(_adminPass, 'latest_url', url.trim());
      if (a && b) {
        latestVersion = ver.trim();
        latestUrl = url.trim();
        notifyListeners();
      }
      return a && b;
    } catch (_) {
      return false;
    }
  }

  Future<bool> adminSaveChannel(String text) async {
    try {
      final ok = await Api.adminSet(_adminPass, 'channel', text.trim());
      if (ok) {
        _setChannel(text);
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  // =====================================================================
  // ساب‌ها
  // =====================================================================
  Future<void> _saveSubs() =>
      _store.setSubs(subs.map((e) => e.toJson()).toList());

  /// خطا را به‌صورت کلید ترجمه برمی‌گرداند ، در موفقیت null
  Future<String?> addSub(String name, String url) async {
    final u = url.trim();
    final uri = Uri.tryParse(u);
    if (uri == null ||
        !(uri.scheme == 'http' || uri.scheme == 'https') ||
        uri.host.isEmpty) {
      return 'err_url';
    }
    final id = alvHash(u);
    if (subs.any((s) => s.id == id)) return null;
    final sub = SubInfo(
      id: id,
      name: name.trim().isEmpty ? uri.host : name.trim(),
      url: u,
    );
    final n = await _fetchSub(sub);
    if (n == null || n == 0) return 'err_sub_empty';
    subs.add(sub);
    await _saveSubs();
    _rebuild();
    notifyListeners();
    return null;
  }

  Future<int?> _fetchSub(SubInfo sub) async {
    try {
      final body = await Api.fetchText(sub.url);
      final links = parseSubscription(body);
      if (links.isEmpty) return null;
      await _store.setSubLinks(sub.id, links.join('\n'));
      sub.updated = DateTime.now().millisecondsSinceEpoch;
      sub.count = links.where(isSupportedLink).length;
      return sub.count;
    } catch (_) {
      return null;
    }
  }

  /// تعداد سرور بعد از به‌روزرسانی ، یا null در صورت خطا
  Future<int?> updateSub(SubInfo sub) async {
    final n = await _fetchSub(sub);
    if (n != null) {
      await _saveSubs();
      _rebuild();
      notifyListeners();
    }
    return n;
  }

  Future<void> updateAllSubs() async {
    if (updatingSubs || subs.isEmpty) return;
    updatingSubs = true;
    notifyListeners();
    for (final s in subs.toList()) {
      await _fetchSub(s);
    }
    await _saveSubs();
    _rebuild();
    updatingSubs = false;
    notifyListeners();
  }

  Future<void> updateSubsIfDue() async {
    if (subHours <= 0 || subs.isEmpty) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final limit = subHours * 3600 * 1000;
    final due = subs.where((s) => now - s.updated > limit).toList();
    if (due.isEmpty) return;
    for (final s in due) {
      await _fetchSub(s);
    }
    await _saveSubs();
    _rebuild();
    notifyListeners();
  }

  Future<void> removeSub(SubInfo sub) async {
    subs.removeWhere((s) => s.id == sub.id);
    await _store.removeSubLinks(sub.id);
    await _saveSubs();
    _rebuild();
    notifyListeners();
  }

  // =====================================================================
  // وضعیت زنده از هسته
  // =====================================================================
  void _onStatus(V2RayStatus s) {
    duration = s.duration;
    upload = s.upload;
    download = s.download;
    uploadSpeed = s.uploadSpeed;
    downloadSpeed = s.downloadSpeed;

    if (s.state == 'CONNECTED') {
      final first = phase != VpnPhase.connected;
      phase = VpnPhase.connected;
      final w = _connectedWaiter;
      if (w != null && !w.isCompleted) w.complete(true);
      if (first) {
        connectedPing = null;
        Future.delayed(const Duration(seconds: 1), testConnectedPing);
      }
    } else if (s.state == 'DISCONNECTED') {
      if (phase == VpnPhase.connected) {
        phase = VpnPhase.idle;
        _resetStats();
      }
    }
    notifyListeners();
  }

  void _resetStats() {
    duration = '00:00:00';
    upload = download = uploadSpeed = downloadSpeed = 0;
    connectedPing = null;
  }

  // =====================================================================
  // دکمه‌ی اصلی
  // =====================================================================
  Future<void> toggle() async {
    if (phase == VpnPhase.searching || phase == VpnPhase.connecting) {
      await cancelConnect();
    } else if (phase == VpnPhase.connected) {
      await disconnect();
    } else {
      await connect();
    }
  }

  Future<void> cancelConnect() async {
    _cancel = true;
    _cancelPing = true;
    final w = _connectedWaiter;
    if (w != null && !w.isCompleted) w.complete(false);
    try {
      await _v2ray.stopV2Ray();
    } catch (_) {}
    phase = VpnPhase.idle;
    notifyListeners();
  }

  Future<void> disconnect() async {
    try {
      await _v2ray.stopV2Ray();
    } catch (_) {}
    _resetStats();
    phase = VpnPhase.idle;
    notifyListeners();
  }

  void _fail(String key, [List<Object> args = const []]) {
    phase = VpnPhase.failed;
    msgKey = key;
    msgArgs = args;
    notifyListeners();
  }

  Future<void> connect() async {
    _cancel = false;
    _cancelPing = false;
    msgKey = null;

    if (servers.isEmpty) {
      _fail('err_no_server');
      return;
    }

    var allowed = false;
    try {
      allowed = await _v2ray.requestPermission();
    } catch (_) {}
    if (!allowed) {
      _fail('err_perm');
      return;
    }

    final sel = selected;
    if (sel != null) {
      final ok = await _startOn(sel);
      if (_cancel) return;
      if (!ok) _fail('err_sel', [sel.name]);
      return;
    }
    await _connectFastest();
  }

  Future<void> _connectFastest() async {
    phase = VpnPhase.searching;
    pingDone = 0;
    notifyListeners();

    final pool = gamingMode ? _gamingPool() : servers;
    final order = [...pool]..sort((a, b) => _rank(a).compareTo(_rank(b)));
    for (final s in servers) {
      s.ping = null;
    }
    await _pingPool(order, stopAfter: gamingMode ? 20 : 8);
    if (_cancel) return;

    final ranked = pool.where((s) => (s.ping ?? -1) > 0).toList()
      ..sort((a, b) => a.ping!.compareTo(b.ping!));

    if (ranked.isEmpty) {
      _fail('err_none');
      return;
    }

    for (final s in _gamingOrder(ranked)) {
      if (_cancel) return;
      if (await _startOn(s)) return;
    }
    if (_cancel) return;
    _fail('err_failed');
  }

  List<VpnServer> _gamingPool() {
    final g = servers.where((s) => kGamingCountries.contains(s.country)).toList();
    return g.isEmpty ? servers : g;
  }

  /// حالت گیمینگ: بین ۳ سرور کم‌پینگ‌تر تصادفی انتخاب می‌کند
  List<VpnServer> _gamingOrder(List<VpnServer> ranked) {
    if (!gamingMode || ranked.length < 2) return ranked.take(5).toList();
    final top = ranked.take(3).toList()..shuffle(Random());
    return [...top, ...ranked.skip(3)].take(5).toList();
  }

  List<String> _dnsServers() {
    switch (dnsKey) {
      case 'cloudflare':
        return ['1.1.1.1', '1.0.0.1'];
      case 'google':
        return ['8.8.8.8', '8.8.4.4'];
      case 'quad9':
        return ['9.9.9.9', '149.112.112.112'];
      case 'custom':
        return dnsCustom
            .split(RegExp(r'[,\s]+'))
            .where((e) => e.isNotEmpty)
            .toList();
      default:
        return <String>[];
    }
  }

  String _applyDns(String cfg) {
    final list = _dnsServers();
    if (list.isEmpty) return cfg;
    try {
      final m = jsonDecode(cfg) as Map<String, dynamic>;
      final d = m['dns'] is Map
          ? Map<String, dynamic>.from(m['dns'] as Map)
          : <String, dynamic>{};
      d['servers'] = list;
      m['dns'] = d;
      return jsonEncode(m);
    } catch (_) {
      return cfg;
    }
  }

  int _rank(VpnServer s) {
    final p = s.ping;
    if (p == null) return 1 << 20;
    if (p > 0) return p;
    return 1 << 21;
  }

  Future<bool> _startOn(VpnServer s) async {
    current = s;
    phase = VpnPhase.connecting;
    notifyListeners();

    final w = Completer<bool>();
    _connectedWaiter = w;
    try {
      await _v2ray.startV2Ray(
        remark: s.name,
        config: _applyDns(s.config),
        proxyOnly: proxyOnly,
        bypassSubnets: bypassLan ? _lanSubnets : null,
        blockedApps: null,
        notificationDisconnectButtonName: 'X',
      );
    } catch (_) {
      return false;
    }
    final ok = await w.future
        .timeout(Duration(seconds: timeoutSec), onTimeout: () => false);
    if (!ok) {
      try {
        await _v2ray.stopV2Ray();
      } catch (_) {}
    }
    return ok && !_cancel;
  }

  // =====================================================================
  // انتخاب سرور
  // =====================================================================
  Future<void> select(String? id) async {
    selectedId = id;
    await _store.setSelected(id);
    notifyListeners();
    if (phase == VpnPhase.connected) {
      await disconnect();
      await Future.delayed(const Duration(milliseconds: 400));
      await connect();
    }
  }

  Future<void> toggleFavorite(VpnServer s) async {
    if (!favorites.add(s.id)) favorites.remove(s.id);
    await _store.setFavorites(favorites.toList());
    notifyListeners();
  }

  // =====================================================================
  // تست پینگ
  // =====================================================================
  Future<void> pingOne(VpnServer s) async {
    pinging.add(s.id);
    notifyListeners();
    await _measure(s);
    pinging.remove(s.id);
    notifyListeners();
  }

  Future<void> _measure(VpnServer s) async {
    try {
      final d = await _v2ray
          .getServerDelay(config: s.config, url: testUrl)
          .timeout(const Duration(seconds: 5));
      s.ping = d > 0 ? d : -1;
    } catch (_) {
      s.ping = -1;
    }
  }

  Future<void> pingAll() async {
    if (pingingAll) return;
    _cancelPing = false;
    pingingAll = true;
    pingDone = 0;
    pingTotal = servers.length;
    notifyListeners();
    await _pingPool(servers.toList());
    pingingAll = false;
    notifyListeners();
  }

  void cancelPingAll() {
    _cancelPing = true;
  }

  Future<void> _pingPool(
    List<VpnServer> list, {
    int stopAfter = 0,
    int workers = 12,
  }) async {
    var i = 0;
    var ok = 0;
    var stop = false;

    Future<void> worker() async {
      while (!stop && !_cancelPing) {
        if (i >= list.length) return;
        final s = list[i++];
        pinging.add(s.id);
        await _measure(s);
        pinging.remove(s.id);
        pingDone++;
        if ((s.ping ?? -1) > 0) {
          ok++;
          if (stopAfter > 0 && ok >= stopAfter) stop = true;
        }
        notifyListeners();
      }
    }

    await Future.wait(List.generate(workers, (_) => worker()));
  }

  Future<void> testConnectedPing() async {
    if (phase != VpnPhase.connected || testingPing) return;
    testingPing = true;
    notifyListeners();
    try {
      final d = await _v2ray.getConnectedServerDelay(url: testUrl);
      connectedPing = d > 0 ? d : -1;
    } catch (_) {
      connectedPing = -1;
    }
    testingPing = false;
    notifyListeners();
  }

  // =====================================================================
  // سرورهای دستی
  // =====================================================================
  Future<AddResult> addLinks(String text) async {
    final links = extractLinks(text);
    final existing = servers.map((s) => s.id.substring(1)).toSet();
    final manual = _store.manual;
    var added = 0;
    var skipped = 0;
    for (final l in links) {
      if (!isSupportedLink(l)) {
        skipped++;
        continue;
      }
      final probe = makeServer(l, kManual);
      if (probe == null) continue;
      if (existing.contains(probe.id.substring(1))) continue;
      existing.add(probe.id.substring(1));
      manual.add(l);
      added++;
    }
    if (added > 0) {
      await _store.setManual(manual);
      _rebuild();
      notifyListeners();
    }
    return AddResult(added, skipped);
  }

  Future<void> removeManual(VpnServer s) async {
    final manual = _store.manual..removeWhere((l) => l.trim() == s.link);
    await _store.setManual(manual);
    favorites.remove(s.id);
    await _store.setFavorites(favorites.toList());
    _rebuild();
    notifyListeners();
  }

  Future<void> clearManual() async {
    await _store.setManual(<String>[]);
    _rebuild();
    notifyListeners();
  }

  Future<void> clearFavorites() async {
    favorites.clear();
    await _store.setFavorites(<String>[]);
    notifyListeners();
  }

  // =====================================================================
  // تنظیمات
  // =====================================================================
  Future<void> setAutoConnect(bool v) async {
    autoConnectOnLaunch = v;
    await _store.setAutoConnect(v);
    notifyListeners();
  }

  Future<void> setBypassLan(bool v) async {
    bypassLan = v;
    await _store.setBypassLan(v);
    notifyListeners();
  }

  Future<void> setProxyOnly(bool v) async {
    proxyOnly = v;
    await _store.setProxyOnly(v);
    notifyListeners();
  }

  Future<void> setGaming(bool v) async {
    gamingMode = v;
    await _store.setGaming(v);
    notifyListeners();
  }

  Future<void> setDns(String key, String custom) async {
    dnsKey = key;
    dnsCustom = custom;
    await _store.setDnsKey(key);
    await _store.setDnsCustom(custom);
    notifyListeners();
  }

  Future<void> setTestUrl(String key) async {
    testUrlKey = key;
    await _store.setTestUrlKey(key);
    notifyListeners();
  }

  Future<void> setTimeoutSec(int v) async {
    timeoutSec = v;
    await _store.setTimeoutSec(v);
    notifyListeners();
  }

  Future<void> setSubHours(int v) async {
    subHours = v;
    await _store.setSubHours(v);
    notifyListeners();
  }

  Future<void> setLang(String l) async {
    i18n.lang = l;
    await _store.setLang(l);
    look.value++;
    notifyListeners();
  }

  Future<void> setThemeKey(String k) async {
    themeKey = k;
    applyTheme(k);
    await _store.setTheme(k);
    look.value++;
    notifyListeners();
  }

  Future<void> finishWelcome() async {
    welcomed = true;
    await _store.setWelcomed(true);
    notifyListeners();
  }

  @override
  void dispose() {
    _beat?.cancel();
    super.dispose();
  }
}
