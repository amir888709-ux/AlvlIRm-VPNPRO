import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'aether_page.dart';
import 'i18n.dart';
import 'server.dart';
import 'subs_page.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

enum _Filter { all, fav, fast, gaming, aether, official, sub, manual }

enum _Sort { ping, name, country }

class ServersPage extends StatefulWidget {
  const ServersPage({super.key, required this.controller});
  final VpnController controller;

  @override
  State<ServersPage> createState() => _ServersPageState();
}

class _ServersPageState extends State<ServersPage> {
  VpnController get c => widget.controller;

  _Filter _filter = _Filter.all;
  _Sort _sort = _Sort.ping;
  String _q = '';

  List<VpnServer> _visible() {
    final q = _q.trim().toLowerCase();
    final list = c.servers.where((s) {
      if (_filter == _Filter.fav && !c.favorites.contains(s.id)) return false;
      if (_filter == _Filter.fast && !((s.ping ?? -1) > 0 && s.ping! < 400)) {
        return false;
      }
      if (_filter == _Filter.gaming && !kGamingCountries.contains(s.country)) {
        return false;
      }
      if (_filter == _Filter.aether && !s.isAether) return false;
      if (_filter == _Filter.official && s.source != kOfficial) return false;
      if (_filter == _Filter.sub && s.source != kSub) return false;
      if (_filter == _Filter.manual && s.source != kManual) return false;
      if (q.isNotEmpty) {
        final t = '${s.name} ${countryLabel(s.country, lang)} ${s.country} ${s.protocol}'
            .toLowerCase();
        if (!t.contains(q)) return false;
      }
      return true;
    }).toList();

    int pingKey(VpnServer s) => (s.ping ?? -1) > 0 ? s.ping! : 1 << 30;

    list.sort((a, b) {
      final fa = c.favorites.contains(a.id) ? 0 : 1;
      final fb = c.favorites.contains(b.id) ? 0 : 1;
      if (fa != fb) return fa.compareTo(fb);
      switch (_sort) {
        case _Sort.ping:
          final r = pingKey(a).compareTo(pingKey(b));
          return r != 0 ? r : a.name.compareTo(b.name);
        case _Sort.name:
          return a.name.compareTo(b.name);
        case _Sort.country:
          final r = a.country.compareTo(b.country);
          return r != 0 ? r : pingKey(a).compareTo(pingKey(b));
      }
    });
    return list;
  }

  String _resultMsg(AddResult r) {
    if (r.added > 0) return tr('added_n', [r.added]);
    if (r.skipped > 0) return tr('skipped_n', [r.skipped]);
    return tr('nothing_new');
  }

  Future<void> _addFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final r = await c.addLinks(data?.text ?? '');
    if (mounted) toast(context, _resultMsg(r));
  }

  Future<void> _addManual() async {
    final ctrl = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.card,
        title: Text(tr('add_server'),
            style: TextStyle(color: AppColors.text, fontSize: 16)),
        content: TextField(
          controller: ctrl,
          minLines: 3,
          maxLines: 6,
          textDirection: TextDirection.ltr,
          style: TextStyle(color: AppColors.text),
          decoration: InputDecoration(
            hintText: tr('links_hint'),
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(tr('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text),
            child: Text(tr('add_server')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (text == null) return;
    final r = await c.addLinks(text);
    if (mounted) toast(context, _resultMsg(r));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final list = _visible();
        final filters = <_Filter, String>{
          _Filter.all: tr('f_all'),
          _Filter.fav: tr('f_fav'),
          _Filter.fast: tr('f_fast'),
          _Filter.gaming: tr('f_gaming'),
          _Filter.aether: tr('f_aether'),
          _Filter.official: tr('f_official'),
          _Filter.sub: tr('f_sub'),
          _Filter.manual: tr('f_manual'),
        };
        return Scaffold(
          appBar: AppBar(
            title: Text(tr('servers')),
            actions: [
              PopupMenuButton<_Sort>(
                icon: const Icon(Icons.sort_rounded),
                onSelected: (v) => setState(() => _sort = v),
                itemBuilder: (_) => [
                  PopupMenuItem(value: _Sort.ping, child: Text(tr('sort_ping'))),
                  PopupMenuItem(value: _Sort.name, child: Text(tr('sort_name'))),
                  PopupMenuItem(
                      value: _Sort.country, child: Text(tr('sort_country'))),
                ],
              ),
              IconButton(
                tooltip: c.pingingAll ? tr('stop_test') : tr('ping_all'),
                icon: Icon(
                  c.pingingAll ? Icons.stop_circle_outlined : Icons.speed_rounded,
                ),
                onPressed: c.pingingAll ? c.cancelPingAll : c.pingAll,
              ),
              IconButton(
                tooltip: tr('subs_title'),
                icon: const Icon(Icons.link_rounded),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => SubsPage(controller: c)),
                ),
              ),
              PopupMenuButton<String>(
                tooltip: tr('add_server'),
                icon: const Icon(Icons.add_rounded),
                onSelected: (v) {
                  if (v == 'clip') {
                    _addFromClipboard();
                  } else if (v == 'aether') {
                    openAetherBuilder(context, c);
                  } else {
                    _addManual();
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'clip', child: Text(tr('from_clipboard'))),
                  PopupMenuItem(value: 'manual', child: Text(tr('enter_link'))),
                  PopupMenuItem(value: 'aether', child: Text(tr('aether_new'))),
                ],
              ),
            ],
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(3),
              child: c.pingingAll
                  ? LinearProgressIndicator(
                      minHeight: 3,
                      value: c.pingTotal == 0 ? null : c.pingDone / c.pingTotal,
                      color: AppColors.purpleLight,
                      backgroundColor: AppColors.card,
                    )
                  : const SizedBox(height: 3),
            ),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: TextField(
                  onChanged: (v) => setState(() => _q = v),
                  style: TextStyle(color: AppColors.text),
                  decoration: InputDecoration(
                    hintText: tr('search_hint'),
                    prefixIcon: const Icon(Icons.search_rounded),
                    filled: true,
                    fillColor: AppColors.card,
                    contentPadding: EdgeInsets.zero,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: [
                    for (final e in filters.entries)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(e.value),
                          selected: _filter == e.key,
                          onSelected: (_) => setState(() => _filter = e.key),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                  itemCount: list.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) return _autoTile();
                    return _serverTile(list[i - 1]);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _autoTile() {
    final on = c.selectedId == null;
    return _card(
      selected: on,
      child: ListTile(
        leading: const Text('⚡', style: TextStyle(fontSize: 26)),
        title: Text(tr('auto_name'),
            style: TextStyle(
                fontWeight: FontWeight.w700, color: AppColors.text)),
        subtitle: Text(tr('auto_desc'),
            style: TextStyle(color: AppColors.muted, fontSize: 12)),
        trailing: on
            ? Icon(Icons.check_circle_rounded, color: AppColors.purpleLight)
            : null,
        onTap: () {
          Navigator.pop(context);
          c.select(null);
        },
      ),
    );
  }

  Widget _tagFor(VpnServer s) {
    if (s.source == kOfficial) return Tag(tr('official_tag'));
    if (s.source == kSub) return Tag(tr('sub_tag'), color: AppColors.warn);
    return Tag(tr('manual_tag'), color: AppColors.ok);
  }

  Widget _serverTile(VpnServer s) {
    final on = c.selectedId == s.id;
    final fav = c.favorites.contains(s.id);
    final free = !s.official;
    return _card(
      selected: on,
      child: ListTile(
        contentPadding: const EdgeInsetsDirectional.only(start: 12, end: 0),
        leading: FlagIcon(s.country, size: 26),
        title: Text(
          s.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.text),
        ),
        subtitle: Row(
          children: [
            _tagFor(s),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                '${countryLabel(s.country, lang)} · ${s.protocol}',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: AppColors.muted, fontSize: 12),
              ),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            PingBadge(ping: s.ping, busy: c.pinging.contains(s.id)),
            IconButton(
              visualDensity: VisualDensity.compact,
              icon: Icon(
                fav ? Icons.star_rounded : Icons.star_border_rounded,
                color: fav ? AppColors.warn : AppColors.muted,
              ),
              onPressed: () => c.toggleFavorite(s),
            ),
            PopupMenuButton<String>(
              padding: EdgeInsets.zero,
              icon: Icon(Icons.more_vert_rounded, color: AppColors.muted),
              onSelected: (v) async {
                if (v == 'ping') {
                  c.pingOne(s);
                } else if (v == 'copy') {
                  await Clipboard.setData(ClipboardData(text: s.link));
                  if (mounted) toast(context, tr('link_copied'));
                } else if (v == 'qr') {
                  await showQr(context, s.name, s.link);
                } else if (v == 'delete') {
                  await c.removeManual(s);
                  if (mounted) toast(context, tr('deleted'));
                } else if (v == 'locked') {
                  toast(context, tr('protected_note'));
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'ping', child: Text(tr('ping_test'))),
                if (free) PopupMenuItem(value: 'copy', child: Text(tr('copy_link'))),
                if (free) PopupMenuItem(value: 'qr', child: Text(tr('show_qr'))),
                if (s.source == kManual)
                  PopupMenuItem(value: 'delete', child: Text(tr('delete'))),
                if (!free)
                  PopupMenuItem(
                    value: 'locked',
                    child: Row(
                      children: [
                        const Icon(Icons.lock_rounded, size: 16),
                        const SizedBox(width: 8),
                        Text(tr('official_tag')),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
        onTap: () {
          Navigator.pop(context);
          c.select(s.id);
        },
      ),
    );
  }

  Widget _card({required bool selected, required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: selected
              ? AppColors.purpleLight
              : AppColors.purple.withValues(alpha: 0.15),
          width: selected ? 1.6 : 1,
        ),
      ),
      child: child,
    );
  }
}
