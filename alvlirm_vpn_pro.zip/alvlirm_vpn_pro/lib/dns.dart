/// DNSهای آماده ؛ آدرس‌ها از چند منبع عمومی تطبیق داده شده‌اند
class DnsPreset {
  const DnsPreset(this.key, this.name, this.ips);
  final String key;
  final String name;
  final List<String> ips;
}

/// برای اتصال و وب‌گردی (داخل VPN هم اعمال می‌شود)
const List<DnsPreset> kDnsConn = [
  DnsPreset('cloudflare', 'Cloudflare', ['1.1.1.1', '1.0.0.1']),
  DnsPreset('google', 'Google', ['8.8.8.8', '8.8.4.4']),
  DnsPreset('quad9', 'Quad9', ['9.9.9.9', '149.112.112.112']),
  DnsPreset('adguard', 'AdGuard', ['94.140.14.14', '94.140.15.15']),
];

/// ویژه‌ی بازی (فقط در حالت DNS)
const List<DnsPreset> kDnsGame = [
  DnsPreset('shecan', 'Shecan', ['178.22.122.100', '185.51.200.2']),
  DnsPreset('electro', 'Electro', ['78.157.42.100', '78.157.42.101']),
  DnsPreset('begzar', 'Begzar', ['185.55.226.26', '185.55.225.25']),
  DnsPreset('radar', 'Radar Game', ['10.202.10.10', '10.202.10.11']),
  DnsPreset('d403', '403.online', ['10.202.10.202', '10.202.10.102']),
];

final RegExp _ipv4 = RegExp(r'^(\d{1,3})(\.\d{1,3}){3}$');

/// فقط آدرس‌های IPv4 معتبر را نگه می‌دارد
List<String> parseDnsList(String text) {
  final out = <String>[];
  for (final p in text.split(RegExp(r'[,\s;]+'))) {
    if (p.isEmpty || !_ipv4.hasMatch(p)) continue;
    final ok = p.split('.').every((e) => int.parse(e) <= 255);
    if (ok && !out.contains(p)) out.add(p);
  }
  return out;
}
