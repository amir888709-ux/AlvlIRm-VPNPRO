import 'dart:convert';

import 'package:cryptography/cryptography.dart';

import 'config.dart';

/// رمزنگاری AES-256-GCM برای لیست سرورهای رسمی.
/// قالب: base64( nonce(12) + cipherText + tag(16) ) ، کلید = SHA-256(APP_KEY)
class CryptoBox {
  static final AesGcm _algo = AesGcm.with256bits();
  static SecretKey? _key;

  static Future<SecretKey> _secret() async {
    final cached = _key;
    if (cached != null) return cached;
    final h = await Sha256().hash(utf8.encode(kAppKey));
    final k = SecretKey(h.bytes);
    _key = k;
    return k;
  }

  static Future<String> encrypt(String plain) async {
    final box = await _algo.encrypt(
      utf8.encode(plain),
      secretKey: await _secret(),
    );
    return base64.encode(box.concatenation());
  }

  /// اگر کلید اشتباه یا داده خراب باشد null برمی‌گرداند.
  static Future<String?> decrypt(String blob) async {
    try {
      final bytes = base64.decode(base64.normalize(blob.trim()));
      final box = SecretBox.fromConcatenation(
        bytes,
        nonceLength: 12,
        macLength: 16,
      );
      final clear = await _algo.decrypt(box, secretKey: await _secret());
      return utf8.decode(clear);
    } catch (_) {
      return null;
    }
  }
}
