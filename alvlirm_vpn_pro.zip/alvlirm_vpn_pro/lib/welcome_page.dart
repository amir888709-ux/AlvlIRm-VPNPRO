import 'package:flutter/material.dart';

import 'config.dart';
import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

/// صفحه‌ی خوش‌آمدگویی اولین اجرا
class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key, required this.controller, required this.onDone});
  final VpnController controller;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) => Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.5),
              radius: 1.2,
              colors: [AppColors.glow, AppColors.bg],
            ),
          ),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(26),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [AppColors.purpleLight, AppColors.purpleDeep],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.purple.withValues(alpha: 0.55),
                            blurRadius: 50,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.shield_rounded,
                          color: Colors.white, size: 64),
                    ),
                    const SizedBox(height: 28),
                    Text(tr('welcome_title'),
                        style: TextStyle(
                            color: AppColors.text,
                            fontSize: 28,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    Text(tr('welcome_body'),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: AppColors.muted, fontSize: 15, height: 1.6)),
                    const SizedBox(height: 22),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      alignment: WrapAlignment.center,
                      children: [
                        for (final e in kLangNames.entries)
                          ChoiceChip(
                            label: Text(e.value),
                            selected: lang == e.key,
                            onSelected: (_) => controller.setLang(e.key),
                          ),
                      ],
                    ),
                    const SizedBox(height: 26),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                            color: AppColors.purple.withValues(alpha: 0.3)),
                      ),
                      child: Column(
                        children: [
                          Text(tr('created_by'),
                              style: TextStyle(
                                  color: AppColors.muted, fontSize: 12)),
                          const SizedBox(height: 4),
                          Text('AlvlIRm',
                              style: TextStyle(
                                  color: AppColors.text,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1)),
                          const SizedBox(height: 8),
                          TextButton.icon(
                            onPressed: () => openTelegram(context),
                            icon: const Icon(Icons.send_rounded, size: 18),
                            label: Text(
                              '${tr('telegram')}  $kTelegramUser',
                              textDirection: TextDirection.ltr,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: FilledButton(
                        onPressed: onDone,
                        child: Text(tr('continue_btn'),
                            style: const TextStyle(fontSize: 16)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
