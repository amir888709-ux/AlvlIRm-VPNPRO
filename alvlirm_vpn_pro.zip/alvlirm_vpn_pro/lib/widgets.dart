import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config.dart';
import 'i18n.dart';
import 'theme.dart';

String fmtBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  if (bytes < 1024 * 1024 * 1024) {
    return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
  }
  return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

/// باز کردن تلگرام سازنده ؛ اگر نشد آیدی کپی می‌شود
Future<void> openTelegram(BuildContext context) async {
  var ok = false;
  try {
    ok = await launchUrl(
      Uri.parse(kTelegramUrl),
      mode: LaunchMode.externalApplication,
    );
  } catch (_) {}
  if (!ok) {
    await Clipboard.setData(const ClipboardData(text: kTelegramUser));
    if (context.mounted) toast(context, tr('open_failed'));
  }
}

/// نمایش کیوآر کد (فقط برای لینک‌های آزاد: sub و سرور دستی)
Future<void> showQr(BuildContext context, String title, String data) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text(title, style: TextStyle(color: AppColors.text, fontSize: 16)),
      content: SizedBox(
        width: 270,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(8),
              child: QrImageView(
                data: data,
                size: 250,
                backgroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              tr('qr_hint'),
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, fontSize: 12),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: data));
            if (ctx.mounted) toast(ctx, tr('link_copied'));
          },
          child: Text(tr('copy')),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: Text(tr('ok')),
        ),
      ],
    ),
  );
}

Future<bool> confirmDialog(BuildContext context, String title) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text(title, style: TextStyle(color: AppColors.text, fontSize: 16)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: Text(tr('cancel')),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(tr('ok')),
        ),
      ],
    ),
  );
  return ok == true;
}

/// نشان پینگ: — تست نشده ، ✕ ناموفق ، عدد = میلی‌ثانیه
class PingBadge extends StatelessWidget {
  const PingBadge({super.key, required this.ping, this.busy = false});

  final int? ping;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    if (busy) {
      return SizedBox(
        width: 22,
        height: 22,
        child: Padding(
          padding: const EdgeInsets.all(3),
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: AppColors.purpleLight,
          ),
        ),
      );
    }
    final color = pingColor(ping);
    final text = ping == null ? '—' : (ping! <= 0 ? '✕' : '$ping ms');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        textDirection: TextDirection.ltr,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

/// برچسب کوچک نوع سرور (رسمی / ساب / دستی)
class Tag extends StatelessWidget {
  const Tag(this.label, {super.key, this.color});
  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.purpleLight;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(label, style: TextStyle(color: c, fontSize: 10)),
    );
  }
}
