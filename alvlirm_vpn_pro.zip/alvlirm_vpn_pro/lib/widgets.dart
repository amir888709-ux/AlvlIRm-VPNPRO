import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config.dart';
import 'i18n.dart';
import 'server.dart' show flagEmoji;
import 'theme.dart';

String fmtBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  if (bytes < 1024 * 1024 * 1024) {
    return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
  }
  return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

/// باز کردن تلگرام سازنده ؛ اگر نشد آیدی کپی می‌شود
Future<void> openUrl(BuildContext context, String url) async {
  var ok = false;
  try {
    ok = await launchUrl(
      Uri.parse(url),
      mode: LaunchMode.externalApplication,
    );
  } catch (_) {}
  if (!ok) {
    await Clipboard.setData(ClipboardData(text: url));
    if (context.mounted) toast(context, tr('open_failed'));
  }
}

Future<void> openTelegram(BuildContext context) =>
    openUrl(context, kTelegramUrl);

/// نمایش کیوآر کد (فقط برای لینک‌های آزاد: sub و سرور دستی)
Future<void> showQr(BuildContext context, String title, String data) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text(title, style: TextStyle(color: AppColors.text, fontSize: 16)),
      content: SizedBox(
        width: 270,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(8),
              child: QrImageView(
                data: data,
                size: 250,
                backgroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              tr('qr_hint'),
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, fontSize: 12),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: data));
            if (ctx.mounted) toast(ctx, tr('link_copied'));
          },
          child: Text(tr('copy')),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: Text(tr('ok')),
        ),
      ],
    ),
  );
}

Future<bool> confirmDialog(BuildContext context, String title) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text(title, style: TextStyle(color: AppColors.text, fontSize: 16)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: Text(tr('cancel')),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(tr('ok')),
        ),
      ],
    ),
  );
  return ok == true;
}

/// نشان پینگ: — تست نشده ، ✕ ناموفق ، عدد = میلی‌ثانیه
class PingBadge extends StatelessWidget {
  const PingBadge({super.key, required this.ping, this.busy = false});

  final int? ping;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    if (busy) {
      return SizedBox(
        width: 22,
        height: 22,
        child: Padding(
          padding: const EdgeInsets.all(3),
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: AppColors.purpleLight,
          ),
        ),
      );
    }
    final color = pingColor(ping);
    final text = ping == null ? '—' : (ping! <= 0 ? '✕' : '$ping ms');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        textDirection: TextDirection.ltr,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

/// برچسب کوچک نوع سرور (رسمی / ساب / دستی)
class Tag extends StatelessWidget {
  const Tag(this.label, {super.key, this.color});
  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.purpleLight;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(label, style: TextStyle(color: c, fontSize: 10)),
    );
  }
}


/// پرچم کشور: ایران = پرچم شیر و خورشید (پیش از انقلاب) ؛ بقیه ایموجی
class FlagIcon extends StatelessWidget {
  const FlagIcon(this.code, {super.key, this.size = 28});
  final String code;
  final double size;

  @override
  Widget build(BuildContext context) {
    if (code.toUpperCase() == 'IR') {
      return SizedBox(
        width: size * 1.5,
        height: size,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(size * 0.1),
          child: CustomPaint(painter: _LionSunPainter()),
        ),
      );
    }
    return Text(flagEmoji(code), style: TextStyle(fontSize: size));
  }
}

class _LionSunPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final band = h / 3;
    canvas.drawRect(Rect.fromLTWH(0, 0, w, band),
        Paint()..color = const Color(0xFF239F40));
    canvas.drawRect(Rect.fromLTWH(0, band, w, band),
        Paint()..color = const Color(0xFFFFFFFF));
    canvas.drawRect(Rect.fromLTWH(0, band * 2, w, band),
        Paint()..color = const Color(0xFFDA0000));

    final c = Offset(w / 2, h / 2);
    final r = h * 0.26;
    final gold = Paint()..color = const Color(0xFFE9A800);
    final dark = Paint()..color = const Color(0xFFB87800);

    // پرتوهای خورشید
    final ray = Paint()
      ..color = const Color(0xFFE9A800)
      ..style = PaintingStyle.fill;
    const rays = 16;
    for (var i = 0; i < rays; i++) {
      final a = i * 2 * math.pi / rays;
      final a1 = a - math.pi / rays * 0.55;
      final a2 = a + math.pi / rays * 0.55;
      final tip = c + Offset(math.cos(a), math.sin(a)) * (r * 1.42);
      final b1 = c + Offset(math.cos(a1), math.sin(a1)) * (r * 1.02);
      final b2 = c + Offset(math.cos(a2), math.sin(a2)) * (r * 1.02);
      canvas.drawPath(
        Path()
          ..moveTo(tip.dx, tip.dy)
          ..lineTo(b1.dx, b1.dy)
          ..lineTo(b2.dx, b2.dy)
          ..close(),
        ray,
      );
    }
    canvas.drawCircle(c, r, gold);

    // شیر (ساده‌شده): بدن ، سر ، یال ، پاها ، دم ، شمشیر
    final u = r / 10; // واحد
    final o = c + Offset(-u * 0.5, u * 1.2);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: o, width: u * 11, height: u * 5.2),
        Radius.circular(u * 2.4),
      ),
      dark,
    );
    // پاها
    for (final dx in [-4.2, -2.0, 2.2, 4.4]) {
      canvas.drawRect(
        Rect.fromLTWH(o.dx + u * dx - u * 0.6, o.dy + u * 1.8, u * 1.2, u * 3.2),
        dark,
      );
    }
    // سر و یال
    final head = o + Offset(-u * 5.4, -u * 2.6);
    canvas.drawCircle(head, u * 2.9, dark);
    canvas.drawCircle(head + Offset(-u * 0.5, u * 0.3), u * 1.9,
        Paint()..color = const Color(0xFFD99A10));
    // دم
    final tail = Path()
      ..moveTo(o.dx + u * 5.2, o.dy - u * 0.5)
      ..quadraticBezierTo(o.dx + u * 8.0, o.dy - u * 2.0, o.dx + u * 6.2,
          o.dy - u * 5.0);
    canvas.drawPath(
      tail,
      Paint()
        ..color = const Color(0xFFB87800)
        ..style = PaintingStyle.stroke
        ..strokeWidth = u * 0.9
        ..strokeCap = StrokeCap.round,
    );
    // شمشیر
    final sword = Paint()
      ..color = const Color(0xFF5A3A00)
      ..style = PaintingStyle.stroke
      ..strokeWidth = u * 0.7
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(head + Offset(u * 1.5, -u * 0.5),
        head + Offset(u * 3.6, -u * 4.6), sword);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
