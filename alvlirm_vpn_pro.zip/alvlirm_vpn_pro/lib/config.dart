/// تنظیمات ثابت برنامه. مقادیر حساس هنگام ساخت (GitHub Actions) تزریق می‌شوند.
const String _apiUrl = String.fromEnvironment('SUPABASE_URL');
const String _apiKey = String.fromEnvironment('SUPABASE_KEY');
const String _appKey = String.fromEnvironment('APP_KEY');

String get kApiUrl => _apiUrl.endsWith('/')
    ? _apiUrl.substring(0, _apiUrl.length - 1)
    : _apiUrl;
String get kApiKey => _apiKey;
String get kAppKey => _appKey.isEmpty ? 'AlvlIRm-VPN-default-key' : _appKey;

bool get apiEnabled => _apiUrl.isNotEmpty && _apiKey.isNotEmpty;

const String kTelegramUser = '@AlvlIRm';
const String kTelegramUrl = 'https://t.me/AlvlIRm';
const String kVersion = '1.2.0';
