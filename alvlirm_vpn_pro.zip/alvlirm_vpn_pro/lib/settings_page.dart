import 'package:flutter/material.dart';

import 'config.dart';
import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key, required this.controller});
  final VpnController controller;

  VpnController get c => controller;

  Future<void> _choose<T>(
    BuildContext context,
    String title,
    List<MapEntry<T, String>> items,
    T current,
    void Function(T) onPick,
  ) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.card,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(title,
                    style: TextStyle(
                        color: AppColors.text,
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
              ),
              for (final e in items)
                ListTile(
                  title: Text(e.value, style: TextStyle(color: AppColors.text)),
                  trailing: e.key == current
                      ? Icon(Icons.check_circle_rounded,
                          color: AppColors.purpleLight)
                      : null,
                  onTap: () {
                    onPick(e.key);
                    Navigator.pop(ctx);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _group(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 4),
        child: Text(t,
            style: TextStyle(
                color: AppColors.purpleLight,
                fontWeight: FontWeight.w700,
                fontSize: 13)),
      );

  Widget _sub(String t) =>
      Text(t, style: TextStyle(color: AppColors.muted, fontSize: 12));

  Widget _themeDot(String key) {
    final p = key == 'system' ? pal : kThemes[key]!;
    return Container(
      width: 22,
      height: 22,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [p.primary, p.bg]),
        border: Border.all(color: AppColors.muted.withValues(alpha: 0.5)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: Text(tr('settings'))),
        body: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            _group(tr('g_general')),
            ListTile(
              leading: Icon(Icons.language_rounded, color: AppColors.purpleLight),
              title: Text(tr('language')),
              subtitle: _sub(kLangNames[lang] ?? lang),
              onTap: () => _choose<String>(
                context,
                tr('language'),
                [for (final e in kLangNames.entries) MapEntry(e.key, e.value)],
                lang,
                c.setLang,
              ),
            ),
            ListTile(
              leading: Icon(Icons.palette_rounded, color: AppColors.purpleLight),
              title: Text(tr('theme')),
              subtitle: _sub(tr('th_${c.themeKey}')),
              trailing: _themeDot(c.themeKey),
              onTap: () => _choose<String>(
                context,
                tr('theme'),
                [for (final k in kThemeKeys) MapEntry(k, tr('th_$k'))],
                c.themeKey,
                c.setThemeKey,
              ),
            ),
            SwitchListTile(
              title: Text(tr('auto_connect')),
              subtitle: _sub(tr('auto_connect_d')),
              value: c.autoConnectOnLaunch,
              onChanged: c.setAutoConnect,
            ),
            _group(tr('g_connection')),
            SwitchListTile(
              title: Text(tr('bypass_lan')),
              subtitle: _sub(tr('bypass_lan_d')),
              value: c.bypassLan,
              onChanged: c.setBypassLan,
            ),
            SwitchListTile(
              title: Text(tr('proxy_only')),
              subtitle: _sub(tr('proxy_only_d')),
              value: c.proxyOnly,
              onChanged: c.setProxyOnly,
            ),
            ListTile(
              title: Text(tr('test_url')),
              subtitle: _sub(c.testUrlKey),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _choose<String>(
                context,
                tr('test_url'),
                [for (final k in testUrls.keys) MapEntry(k, k)],
                c.testUrlKey,
                c.setTestUrl,
              ),
            ),
            ListTile(
              title: Text(tr('timeout')),
              subtitle: _sub(tr('seconds_n', [c.timeoutSec])),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _choose<int>(
                context,
                tr('timeout'),
                [for (final n in [6, 10, 15, 20]) MapEntry(n, tr('seconds_n', [n]))],
                c.timeoutSec,
                c.setTimeoutSec,
              ),
            ),
            _group(tr('g_data')),
            ListTile(
              title: Text(tr('sub_auto')),
              subtitle: _sub(c.subHours == 0 ? tr('off') : tr('hours_n', [c.subHours])),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _choose<int>(
                context,
                tr('sub_auto'),
                [
                  MapEntry(0, tr('off')),
                  for (final n in [1, 3, 6, 12, 24]) MapEntry(n, tr('hours_n', [n])),
                ],
                c.subHours,
                c.setSubHours,
              ),
            ),
            ListTile(
              leading: Icon(Icons.cloud_sync_rounded, color: AppColors.purpleLight),
              title: Text(tr('refresh_official')),
              onTap: () async {
                final ok = await c.refreshRemote();
                if (context.mounted) {
                  toast(context, ok ? tr('refreshed') : tr('refresh_failed'));
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.star_outline_rounded),
              title: Text(tr('clear_fav')),
              onTap: () async {
                if (await confirmDialog(context, tr('confirm_q'))) {
                  await c.clearFavorites();
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded),
              title: Text(tr('clear_manual')),
              onTap: () async {
                if (await confirmDialog(context, tr('confirm_q'))) {
                  await c.clearManual();
                }
              },
            ),
            const Divider(height: 28),
            ListTile(
              leading: Icon(Icons.shield_rounded, color: AppColors.purpleLight),
              title: const Text('AlvlIRm VPN'),
              subtitle: FutureBuilder<String>(
                future: c.coreVersion(),
                builder: (context, snap) => _sub(
                  '${tr('version')} $kVersion · ${tr('core')} Xray ${snap.data ?? ''}'
                  '\n${tr('servers_n', [c.servers.length])}',
                ),
              ),
              isThreeLine: true,
            ),
            ListTile(
              leading: Icon(Icons.person_rounded, color: AppColors.purpleLight),
              title: Text('${tr('creator')}: AlvlIRm'),
              subtitle: _sub('${tr('telegram')}: $kTelegramUser'),
              trailing: const Icon(Icons.send_rounded),
              onTap: () => openTelegram(context),
            ),
          ],
        ),
      ),
    );
  }
}
