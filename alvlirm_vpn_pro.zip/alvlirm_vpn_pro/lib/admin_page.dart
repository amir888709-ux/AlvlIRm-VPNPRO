import 'package:flutter/material.dart';

import 'config.dart';
import 'i18n.dart';
import 'server.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

/// ورود به پنل مدیر (۷ بار لمس روی نام برنامه)
Future<void> openAdmin(BuildContext context, VpnController c) async {
  if (!apiEnabled) {
    toast(context, tr('admin_no_api'));
    return;
  }
  final ctrl = TextEditingController();
  final pass = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text(tr('admin_pass'),
          style: TextStyle(color: AppColors.text, fontSize: 16)),
      content: TextField(
        controller: ctrl,
        obscureText: true,
        autofocus: true,
        textDirection: TextDirection.ltr,
        style: TextStyle(color: AppColors.text),
        decoration: const InputDecoration(border: OutlineInputBorder()),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: Text(tr('cancel')),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, ctrl.text),
          child: Text(tr('ok')),
        ),
      ],
    ),
  );
  ctrl.dispose();
  if (pass == null || pass.isEmpty) return;
  final ok = await c.adminLogin(pass);
  if (!context.mounted) return;
  if (!ok) {
    toast(context, '${tr('admin_wrong')}\n${c.adminError}');
    return;
  }
  await Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => AdminPage(controller: c)),
  );
}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key, required this.controller});
  final VpnController controller;

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  VpnController get c => widget.controller;
  late final TextEditingController _servers =
      TextEditingController(text: c.officialText);
  late final TextEditingController _ann =
      TextEditingController(text: c.announcement);
  late final TextEditingController _ver =
      TextEditingController(text: c.latestAndroid);
  late final TextEditingController _verUrl =
      TextEditingController(text: c.urlAndroid);
  late final TextEditingController _verWin =
      TextEditingController(text: c.latestWin);
  late final TextEditingController _verUrlWin =
      TextEditingController(text: c.urlWin);
  late final TextEditingController _channel =
      TextEditingController(text: c.channelUrl);
  late final TextEditingController _donate =
      TextEditingController(text: c.donateUrl);
  bool _busy = false;

  @override
  void dispose() {
    _servers.dispose();
    _ann.dispose();
    _channel.dispose();
    _donate.dispose();
    _ver.dispose();
    _verUrl.dispose();
    _verWin.dispose();
    _verUrlWin.dispose();
    super.dispose();
  }

  int get _count =>
      extractLinks(_servers.text).where(isSupportedLink).length;

  Future<void> _saveServers() async {
    setState(() => _busy = true);
    final ok = await c.adminSaveServers(_servers.text);
    if (!mounted) return;
    setState(() => _busy = false);
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  Future<void> _find() async {
    setState(() => _busy = true);
    final r = await c.adminFindServers();
    if (!mounted) return;
    if (r == null) {
      setState(() => _busy = false);
      toast(context, tr('admin_find_empty'));
      return;
    }
    if (r.candidates < 0) {
      setState(() => _busy = false);
      toast(context, tr('admin_prune_abort'));
      return;
    }
    if (r.dead.isEmpty && r.add.isEmpty) {
      setState(() => _busy = false);
      toast(context, tr('admin_find_none'));
      return;
    }
    final yes = await confirmDialog(
        context, tr('admin_find_ask', [r.dead.length, r.add.length, r.tested]));
    if (!mounted) return;
    if (!yes) {
      setState(() => _busy = false);
      return;
    }
    final ok = await c.adminApplyFind(r.dead, r.add);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) _servers.text = c.officialText;
    });
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  Future<void> _prune() async {
    setState(() => _busy = true);
    final r = await c.adminTestOfficial();
    if (!mounted) return;
    if (r == null || r.tested == 0) {
      setState(() => _busy = false);
      toast(context, tr('admin_fail'));
      return;
    }
    if (r.dead.isEmpty) {
      setState(() => _busy = false);
      toast(context, tr('admin_prune_none'));
      return;
    }
    if (r.dead.length > r.tested * 0.8) {
      setState(() => _busy = false);
      toast(context, tr('admin_prune_abort'));
      return;
    }
    final yes = await confirmDialog(
        context, tr('admin_prune_ask', [r.dead.length, r.tested]));
    if (!mounted) return;
    if (!yes) {
      setState(() => _busy = false);
      return;
    }
    final ok = await c.adminRemoveOfficial(r.dead);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) _servers.text = c.officialText;
    });
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  Future<void> _saveAnn() async {
    setState(() => _busy = true);
    final ok = await c.adminSaveAnnouncement(_ann.text);
    if (!mounted) return;
    setState(() => _busy = false);
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  Future<void> _saveUpdate([String platform = 'android']) async {
    setState(() => _busy = true);
    final win = platform == 'win';
    final ok = await c.adminSaveUpdate(platform,
        win ? _verWin.text : _ver.text, win ? _verUrlWin.text : _verUrl.text);
    if (!mounted) return;
    setState(() => _busy = false);
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  Future<void> _saveChannel() async {
    setState(() => _busy = true);
    final ok = await c.adminSaveChannel(_channel.text);
    if (!mounted) return;
    setState(() => _busy = false);
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  Future<void> _saveDonate() async {
    setState(() => _busy = true);
    final ok = await c.adminSaveDonate(_donate.text);
    if (!mounted) return;
    setState(() => _busy = false);
    toast(context, ok ? tr('admin_saved') : tr('admin_fail'));
  }

  InputDecoration _dec(String hint) => InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: AppColors.card,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('admin_panel'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(tr('admin_servers'),
              style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 16)),
          const SizedBox(height: 4),
          Text(tr('admin_hint'),
              style: TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 10),
          TextField(
            controller: _servers,
            minLines: 8,
            maxLines: 14,
            onChanged: (_) => setState(() {}),
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text, fontSize: 11),
            decoration: _dec('vless://...'),
          ),
          const SizedBox(height: 6),
          Text(tr('admin_count', [_count]),
              style: TextStyle(color: AppColors.purpleLight, fontSize: 12)),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _busy ? null : _saveServers,
            icon: const Icon(Icons.cloud_upload_rounded),
            label: Text(tr('admin_save')),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _busy ? null : _find,
            icon: const Icon(Icons.travel_explore_rounded),
            label: Text(tr('admin_find')),
          ),
          const SizedBox(height: 4),
          Text(tr('admin_find_hint'),
              style: TextStyle(color: AppColors.muted, fontSize: 12)),
          ListenableBuilder(
            listenable: c,
            builder: (context, _) => c.pingingAll
                ? Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('${c.pingDone} / ${c.pingTotal}',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(color: AppColors.purpleLight)),
                  )
                : const SizedBox.shrink(),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _busy ? null : _prune,
            icon: const Icon(Icons.cleaning_services_rounded),
            label: Text(tr('admin_prune')),
          ),
          const SizedBox(height: 4),
          Text(tr('admin_prune_hint'),
              style: TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 28),
          Text(tr('admin_ann'),
              style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 16)),
          const SizedBox(height: 10),
          TextField(
            controller: _ann,
            minLines: 2,
            maxLines: 4,
            style: TextStyle(color: AppColors.text),
            decoration: _dec(tr('admin_ann_hint')),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _busy ? null : _saveAnn,
            icon: const Icon(Icons.campaign_rounded),
            label: Text(tr('admin_save')),
          ),
          const SizedBox(height: 28),
          Text(tr('admin_channel'),
              style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 16)),
          const SizedBox(height: 10),
          TextField(
            controller: _channel,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text),
            decoration: _dec(tr('admin_channel_hint')),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _busy ? null : _saveChannel,
            icon: const Icon(Icons.send_rounded),
            label: Text(tr('admin_save')),
          ),
          const SizedBox(height: 28),
          Text(tr('admin_donate'),
              style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 16)),
          const SizedBox(height: 10),
          TextField(
            controller: _donate,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text),
            decoration: _dec(tr('admin_donate_hint')),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _busy ? null : _saveDonate,
            icon: const Icon(Icons.favorite_rounded),
            label: Text(tr('admin_save')),
          ),
          const SizedBox(height: 28),
          Text('${tr('admin_update')} - ${tr('platform_android')}',
              style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 16)),
          const SizedBox(height: 4),
          Text(tr('admin_update_hint'),
              style: TextStyle(color: AppColors.muted, fontSize: 12)),
          const SizedBox(height: 10),
          TextField(
            controller: _ver,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text),
            decoration: _dec('1.2.2'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _verUrl,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text),
            decoration: _dec('https://...apk'),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _busy ? null : () => _saveUpdate('android'),
            icon: const Icon(Icons.system_update_rounded),
            label: Text(tr('admin_save')),
          ),
          const SizedBox(height: 28),
          Text('${tr('admin_update')} - ${tr('platform_win')}',
              style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 16)),
          const SizedBox(height: 10),
          TextField(
            controller: _verWin,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text),
            decoration: _dec('1.2.2'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _verUrlWin,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: AppColors.text),
            decoration: _dec('https://...exe'),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _busy ? null : () => _saveUpdate('win'),
            icon: const Icon(Icons.desktop_windows_rounded),
            label: Text(tr('admin_save')),
          ),
        ],
      ),
    );
  }
}
