import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'home_page.dart';
import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'welcome_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = VpnController();
  await controller.init();
  runApp(AlvlirmApp(controller: controller));
}

class AlvlirmApp extends StatefulWidget {
  const AlvlirmApp({super.key, required this.controller});
  final VpnController controller;

  @override
  State<AlvlirmApp> createState() => _AlvlirmAppState();
}

class _AlvlirmAppState extends State<AlvlirmApp> {
  late bool _showWelcome = !widget.controller.welcomed;

  Future<void> _done() async {
    await widget.controller.finishWelcome();
    if (mounted) setState(() => _showWelcome = false);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: look,
      builder: (context, _, __) {
        final dark = pal.b == Brightness.dark;
        SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
          systemNavigationBarColor: pal.bg,
          systemNavigationBarIconBrightness:
              dark ? Brightness.light : Brightness.dark,
        ));
        return MaterialApp(
          title: 'AlvlIRm VPN',
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          locale: Locale(lang),
          supportedLocales: [for (final k in kLangNames.keys) Locale(k)],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: _showWelcome
              ? WelcomePage(controller: widget.controller, onDone: _done)
              : HomePage(controller: widget.controller),
        );
      },
    );
  }
}
