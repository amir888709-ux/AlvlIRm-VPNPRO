import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'config.dart';

/// ارتباط با Supabase (فقط توابع RPC امن) و دانلود لینک‌های اشتراک (sub)
class Api {
  static Future<dynamic> _rpc(String fn, Map<String, dynamic> body) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await client.postUrl(Uri.parse('$kApiUrl/rest/v1/rpc/$fn'));
      req.headers.set('apikey', kApiKey);
      if (kApiKey.startsWith('eyJ')) {
        req.headers.set('Authorization', 'Bearer $kApiKey');
      }
      req.headers.contentType = ContentType.json;
      req.add(utf8.encode(jsonEncode(body)));
      final res = await req.close().timeout(const Duration(seconds: 15));
      final text = await res.transform(utf8.decoder).join();
      if (res.statusCode >= 300) {
        throw HttpException('HTTP ${res.statusCode}');
      }
      return text.isEmpty ? null : jsonDecode(text);
    } finally {
      client.close(force: true);
    }
  }

  /// سرورهای رمزشده ، اعلان ، تعداد آنلاین و کل کاربران (و ثبت حضور این دستگاه)
  static Future<dynamic> meta(String deviceId) =>
      _rpc('get_meta', {'p_device': deviceId});

  static Future<bool> adminCheck(String pass) async =>
      (await _rpc('admin_check', {'p_pass': pass})) == true;

  static Future<bool> adminSet(String pass, String key, String value) async =>
      (await _rpc('admin_set', {'p_pass': pass, 'p_key': key, 'p_value': value})) ==
      true;

  /// دانلود متن یک لینک اشتراک
  static Future<String> fetchText(String url) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15)
      ..userAgent = 'AlvlIRm-VPN/1.2';
    try {
      final req = await client.getUrl(Uri.parse(url));
      final res = await req.close().timeout(const Duration(seconds: 25));
      if (res.statusCode >= 300) throw HttpException('HTTP ${res.statusCode}');
      final bytes = await res
          .fold<List<int>>(<int>[], (a, b) => a..addAll(b))
          .timeout(const Duration(seconds: 40));
      if (bytes.length > 8 * 1024 * 1024) throw const FormatException('big');
      return utf8.decode(bytes, allowMalformed: true);
    } finally {
      client.close(force: true);
    }
  }
}
