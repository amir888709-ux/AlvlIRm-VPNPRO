import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// پورت SOCKS5 محلی Aether (یک پورت غیرمعمول تا با چیز دیگری تداخل نکند)
const int kAetherPort = 18190;

const _kScanModes = {'turbo', 'balanced', 'thorough', 'stealth', 'ironclad'};

/// مشخصات یک لینک aether://
class AetherSpec {
  AetherSpec({
    required this.protocol,
    required this.scan,
    required this.ip,
    required this.transport,
    required this.outer,
    required this.inner,
    required this.name,
    this.peer = '',
    this.psiphon = '',
    this.psiphonMode = '',
    this.region = '',
  });

  final String protocol; // mim / masque / wg / gool
  final String scan;
  final String ip; // 4 / 6 / dual
  final String transport; // h2 / h3 / ''
  final String outer;
  final String inner;
  final String name;
  final String peer; // نقطه‌ی پایانی ثابت  IP:PORT  (اختیاری)
  final String psiphon; // '' / chain / reverse / only
  final String psiphonMode; // '' / auto / cdn / direct
  final String region; // کد کشور خروجی Psiphon مثل DE

  Map<String, String> toJson() => {
        'protocol': protocol,
        'scan': scan,
        'ip': ip,
        'transport': transport,
        'outer': outer,
        'inner': inner,
        'name': name,
        'peer': peer,
        'psiphon': psiphon,
        'psiphonMode': psiphonMode,
        'region': region,
      };

  static AetherSpec fromJson(Map<dynamic, dynamic> j) => AetherSpec(
        protocol: '${j['protocol'] ?? 'masque'}',
        scan: '${j['scan'] ?? 'balanced'}',
        ip: '${j['ip'] ?? 'dual'}',
        transport: '${j['transport'] ?? ''}',
        outer: '${j['outer'] ?? ''}',
        inner: '${j['inner'] ?? ''}',
        name: '${j['name'] ?? ''}',
        peer: '${j['peer'] ?? ''}',
        psiphon: '${j['psiphon'] ?? ''}',
        psiphonMode: '${j['psiphonMode'] ?? ''}',
        region: '${j['region'] ?? ''}',
      );
}

bool _validPeer(String s) =>
    s.isEmpty || RegExp(r'^[0-9A-Fa-f.:\[\]]+:\d{1,5}$').hasMatch(s);

/// aether://?protocol=mim&scan=balanced&ip=v4&transport=h2&outer=IP:443&inner=IP:443#نام
AetherSpec? parseAetherLink(String link) {
  try {
    final hash = link.indexOf('#');
    final name = hash < 0 ? '' : Uri.decodeComponent(link.substring(hash + 1));
    final body = hash < 0 ? link : link.substring(0, hash);
    final q = body.indexOf('?');
    // aether://IP:PORT?...  ← بخش آدرس، نقطه‌ی پایانی ثابت است
    var auth = (q < 0 ? body : body.substring(0, q)).trim();
    final sch = auth.indexOf('://');
    if (sch >= 0) auth = auth.substring(sch + 3);
    auth = auth.replaceAll('/', '');
    final params = q < 0
        ? <String, String>{}
        : Uri.splitQueryString(body.substring(q + 1));
    var protocol = (params['protocol'] ?? 'masque').toLowerCase();
    if (protocol == 'mim' || protocol == 'masque-in-masque') protocol = 'mim';
    if (!{'mim', 'masque', 'wg', 'gool'}.contains(protocol)) return null;
    var scan = (params['scan'] ?? 'balanced').toLowerCase();
    if (!_kScanModes.contains(scan)) scan = 'balanced';
    var ip = (params['ip'] ?? 'dual').toLowerCase();
    ip = ip == 'v4' || ip == '4'
        ? '4'
        : (ip == 'v6' || ip == '6' ? '6' : 'dual');
    var tr = (params['transport'] ?? '').toLowerCase();
    if (tr != 'h2' && tr != 'h3') tr = '';
    final outer = params['outer'] ?? '';
    final inner = params['inner'] ?? '';
    if (!_validPeer(outer) || !_validPeer(inner) || !_validPeer(auth)) {
      return null;
    }
    var psi = (params['psiphon'] ?? '').toLowerCase().trim();
    if (psi == '1' || psi == 'true' || psi == 'on' || psi == 'yes') {
      psi = 'chain';
    }
    if (!{'chain', 'reverse', 'only'}.contains(psi)) psi = '';
    var pmode = (params['psiphon_mode'] ?? params['psiphonMode'] ?? '')
        .toLowerCase()
        .trim();
    if (!{'auto', 'cdn', 'direct'}.contains(pmode)) pmode = '';
    var region = (params['region'] ?? params['psiphon_region'] ?? '').trim();
    region = RegExp(r'^[A-Za-z]{2}$').hasMatch(region)
        ? region.toUpperCase()
        : '';
    return AetherSpec(
      peer: auth,
      psiphon: psi,
      psiphonMode: pmode,
      region: region,
      protocol: protocol,
      scan: scan,
      ip: ip,
      transport: tr,
      outer: outer,
      inner: inner,
      name: name,
    );
  } catch (_) {
    return null;
  }
}

const String kAetherKey = 'alvAether';

/// مشخصات Aether را از تنظیمات یک سرور (JSON) بیرون می‌کشد
AetherSpec? aetherFromConfig(String cfg) {
  if (!cfg.contains(kAetherKey)) return null;
  try {
    final m = jsonDecode(cfg);
    if (m is Map && m[kAetherKey] is Map) {
      return AetherSpec.fromJson(m[kAetherKey] as Map);
    }
  } catch (_) {}
  return null;
}

/// کلید داخلی را پیش از دادن تنظیمات به هسته برمی‌دارد
String stripAether(String cfg) {
  if (!cfg.contains(kAetherKey)) return cfg;
  try {
    final m = jsonDecode(cfg);
    if (m is Map) {
      m.remove(kAetherKey);
      return jsonEncode(m);
    }
  } catch (_) {}
  return cfg;
}

/// نام پکیج برنامه روی اندروید (برای خارج‌کردن خود برنامه از تونل VPN)
String? androidPackageName() {
  try {
    if (!Platform.isAndroid) return null;
    final b = File('/proc/self/cmdline').readAsBytesSync();
    final end = b.indexOf(0);
    final s = utf8.decode(end < 0 ? b : b.sublist(0, end), allowMalformed: true);
    return s.isEmpty ? null : s;
  } catch (_) {
    return null;
  }
}

/// اجرای برنامه‌ی aether به‌صورت پروسه‌ی جدا (فقط پروکسی SOCKS5 محلی می‌سازد)
class AetherRunner {
  static Process? _proc;
  static String lastLog = '';
  static String lastError = '';

  static bool get running => _proc != null;

  static String triedDirs = '';
  static String? _cachedBin;

  /// خطوط /proc/<pid>/maps (چند راه، چون بعد از فعالیت سنگین هسته یکی‌شان ممکن است خطا بدهد)
  static List<String> _mapsLines() {
    final paths = ['/proc/self/maps', '/proc/$pid/maps'];
    for (final p in paths) {
      try {
        final l = File(p).readAsLinesSync();
        if (l.isNotEmpty) return l;
      } catch (_) {
        try {
          final b = File(p).readAsBytesSync();
          final l = utf8.decode(b, allowMalformed: true).split('\n');
          if (l.isNotEmpty) return l;
        } catch (_) {}
      }
    }
    try {
      final r = Process.runSync('cat', ['/proc/self/maps']);
      final l = r.stdout.toString().split('\n');
      if (l.isNotEmpty) return l;
    } catch (_) {}
    return <String>[];
  }

  static String? _scanAndroid() {
    final lines = _mapsLines();
    final dirs = <String>{};
    for (final l in lines) {
      final i = l.indexOf('/');
      if (i < 0) continue;
      final p = l.substring(i).trim();
      if (!p.endsWith('.so') || !p.contains('/lib/')) continue;
      dirs.add(p.substring(0, p.lastIndexOf('/')));
    }
    for (final d in dirs) {
      final f = '$d/libaether.so';
      if (File(f).existsSync()) return f;
    }
    triedDirs = 'maps=${lines.length} so=${dirs.length} ${dirs.take(2).join(', ')}';
    return null;
  }

  /// مسیر فایل اجرایی کنار برنامه (اندروید: پوشه‌ی کتابخانه‌های native)
  static String? binaryPath() {
    try {
      if (Platform.isAndroid) {
        final c = _cachedBin;
        if (c != null && File(c).existsSync()) return c;
        final f = _scanAndroid();
        if (f != null) _cachedBin = f;
        return f;
      }
      if (Platform.isWindows) {
        final dir = File(Platform.resolvedExecutable).parent.path;
        final f = '$dir\\core\\aether.exe';
        return File(f).existsSync() ? f : null;
      }
    } catch (e) {
      triedDirs = e.toString();
    }
    return null;
  }

  /// فایل اجرایی Psiphon (کنار فایل aether)
  static String? psiphonPath() {
    try {
      final bin = binaryPath();
      if (bin == null) return null;
      final sep = Platform.isWindows ? '\\' : '/';
      final dir = bin.substring(0, bin.lastIndexOf(sep));
      final names = Platform.isWindows
          ? ['psiphon-tunnel-core.exe', 'pt\\psiphon-tunnel-core.exe']
          : ['libpsiphon.so'];
      for (final n in names) {
        final f = '$dir$sep$n';
        if (File(f).existsSync()) return f;
      }
    } catch (_) {}
    return null;
  }

  /// هنگام شروع برنامه (پیش از هر پینگ سنگین) مسیر فایل را پیدا و نگه می‌دارد
  static void warmUp() {
    try {
      binaryPath();
    } catch (_) {}
  }

  static bool get available => binaryPath() != null;

  static String _dataDir() {
    final String base;
    if (Platform.isAndroid) {
      base = '${Directory.systemTemp.parent.path}/files/aether';
    } else {
      final local = Platform.environment['LOCALAPPDATA'] ??
          Platform.environment['APPDATA'] ??
          Directory.systemTemp.path;
      base = '$local\\AlvlIRm\\aether';
    }
    final d = Directory(base);
    if (!d.existsSync()) d.createSync(recursive: true);
    return d.path;
  }

  static List<String> _args(AetherSpec s) {
    final a = <String>[];
    switch (s.protocol) {
      case 'mim':
        a.add('--mim');
        break;
      case 'wg':
        a.add('--wg');
        break;
      case 'gool':
        a.add('--gool');
        break;
      default:
        a.add('--masque');
    }
    if (s.transport == 'h2') a.add('--h2');
    if (s.transport == 'h3') a.add('--h3');
    a.addAll(['--scan', s.scan]);
    if (s.protocol == 'mim') {
      if (s.outer.isNotEmpty) a.addAll(['--mim-outer', s.outer]);
      if (s.inner.isNotEmpty) a.addAll(['--mim-inner', s.inner]);
    } else if (s.peer.isNotEmpty &&
        (s.protocol == 'masque' || s.protocol == 'wg')) {
      a.addAll(['--peer', s.peer]);
    }
    final mainAddr = '127.0.0.1:$kAetherPort';
    final aux = '127.0.0.1:${kAetherPort + 1}';
    switch (s.psiphon) {
      case 'chain':
        // aether → warp → psiphon → اینترنت ؛ پروکسی نهایی روی پورت psiphon است
        a.addAll(['--bind', aux, '--psiphon', '--psiphon-bind', mainAddr]);
        break;
      case 'reverse':
        a.addAll(['--bind', mainAddr, '--psiphon-reverse', '--psiphon-bind', aux]);
        break;
      case 'only':
        a.addAll(['--bind', mainAddr, '--psiphon-only']);
        break;
      default:
        a.addAll(['--bind', mainAddr]);
    }
    if (s.psiphon.isNotEmpty) {
      if (s.psiphonMode.isNotEmpty) a.addAll(['--psiphon-mode', s.psiphonMode]);
      if (s.region.isNotEmpty) a.addAll(['--psiphon-region', s.region]);
      final pb = psiphonPath();
      if (pb != null) a.addAll(['--psiphon-bin', pb]);
      a.addAll([
        '--psiphon-dir',
        '${_dataDir()}${Platform.pathSeparator}psiphon',
      ]);
    }
    return a;
  }

  /// آیا سرور واقعاً از تونل عبور می‌دهد؟ (یک اتصال SOCKS5 آزمایشی)
  static Future<bool> _socksWorks(Duration wait) async {
    Socket? sk;
    try {
      sk = await Socket.connect('127.0.0.1', kAetherPort,
          timeout: const Duration(seconds: 3));
      final buf = <int>[];
      final done = Completer<void>();
      sk.listen((d) {
        buf.addAll(d);
        if (buf.length >= 4 && !done.isCompleted) done.complete();
      }, onDone: () {
        if (!done.isCompleted) done.complete();
      }, onError: (_) {
        if (!done.isCompleted) done.complete();
      }, cancelOnError: true);
      const host = 'www.gstatic.com';
      sk.add([
        5, 1, 0, // سلام
        5, 1, 0, 3, host.length, ...host.codeUnits, 0, 80, // CONNECT
      ]);
      await done.future.timeout(wait, onTimeout: () {});
      // پاسخ سلام: 05 00 ؛ پاسخ CONNECT: 05 00 ... (دومین بایت 0 یعنی موفق)
      return buf.length >= 4 &&
          buf[0] == 5 &&
          buf[1] == 0 &&
          buf[2] == 5 &&
          buf[3] == 0;
    } catch (_) {
      return false;
    } finally {
      try {
        sk?.destroy();
      } catch (_) {}
    }
  }

  /// پروسه را اجرا می‌کند و تا آماده‌شدن پورت SOCKS5 صبر می‌کند
  static Future<bool> start(AetherSpec spec, {Duration? timeout}) async {
    var ok = await _start(spec, timeout);
    // Psiphon گاهی به‌خاطر نمونه‌ی نیمه‌جان قبلی (قفل پایگاه‌داده) بالا نمی‌آید: یک بار دوباره
    if (!ok &&
        spec.psiphon.isNotEmpty &&
        lastError.startsWith('aether exited') &&
        lastLog.contains('timeout')) {
      final firstLog = lastLog;
      await _killStray();
      await Future.delayed(const Duration(seconds: 2));
      ok = await _start(spec, timeout);
      if (!ok) lastLog = '$firstLog\n$lastLog';
    }
    return ok;
  }

  static Future<bool> _start(AetherSpec spec, Duration? timeout) async {
    final psi = spec.psiphon.isNotEmpty;
    _psi = psi;
    timeout ??= Duration(seconds: psi ? 200 : 60);
    await stop();
    await _killStray();
    lastLog = '';
    lastError = '';
    var bin = binaryPath();
    for (var i = 0; i < 4 && bin == null; i++) {
      await Future.delayed(const Duration(milliseconds: 400));
      bin = binaryPath();
    }
    if (bin == null) {
      lastError = 'aether binary not found (dirs: ${triedDirs.isEmpty ? '-' : triedDirs})';
      return false;
    }
    try {
      final p = await Process.start(
        bin,
        _args(spec),
        workingDirectory: _dataDir(),
        environment: {
          'AETHER_IP': spec.ip,
          'AETHER_LOG_LEVEL': 'info',
          if (psi) 'AETHER_PSIPHON_READY_SECS': '150',
        },
      );
      _proc = p;
      var exited = false;
      void grab(List<int> d) {
        lastLog += utf8.decode(d, allowMalformed: true);
        if (lastLog.length > 4000) {
          lastLog = lastLog.substring(lastLog.length - 4000);
        }
      }

      p.stdout.listen(grab, onError: (_) {});
      p.stderr.listen(grab, onError: (_) {});
      p.exitCode.then((_) {
        exited = true;
        if (identical(_proc, p)) _proc = null;
      });

      final end = DateTime.now().add(timeout);
      while (DateTime.now().isBefore(end)) {
        if (exited) {
          lastError = 'aether exited';
          return false;
        }
        if (!identical(_proc, p)) {
          lastError = 'cancelled';
          return false;
        }
        try {
          final s = await Socket.connect('127.0.0.1', kAetherPort,
              timeout: const Duration(milliseconds: 600));
          s.destroy();
          // Psiphon دیرتر از پورت آماده می‌شود؛ تا عبور واقعی ترافیک صبر می‌کنیم
          if (!psi) return true;
          if (await _socksWorks(const Duration(seconds: 20))) return true;
        } catch (_) {}
        await Future.delayed(const Duration(milliseconds: 500));
      }
      lastError = 'timeout waiting for aether';
      await stop();
      return false;
    } catch (e) {
      lastError = e.toString();
      _proc = null;
      return false;
    }
  }

  static Future<void> stop() async {
    final p = _proc;
    _proc = null;
    if (p == null) return;
    try {
      p.kill();
      await p.exitCode.timeout(const Duration(seconds: 3));
    } catch (_) {}
    if (Platform.isWindows && _psi) {
      try {
        await Process.run('taskkill', ['/F', '/T', '/PID', '${p.pid}']);
      } catch (_) {}
    }
    await _killStray();
  }

  static bool _psi = false;

  /// پروسه‌های رهاشده‌ی aether / psiphon (از اجرای قبلی) را می‌بندد
  static Future<void> _killStray() async {
    try {
      if (Platform.isAndroid) {
        for (final e in Directory('/proc').listSync(followLinks: false)) {
          final id = int.tryParse(e.path.split('/').last);
          if (id == null || id == pid) continue;
          try {
            final t = utf8.decode(File('/proc/$id/cmdline').readAsBytesSync(),
                allowMalformed: true);
            if (t.contains('libpsiphon.so') || t.contains('libaether.so')) {
              Process.killPid(id, ProcessSignal.sigkill);
            }
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  /// خلاصه‌ی خطا همراه با چند خط آخر گزارش (برای نمایش به کاربر)
  static String summary() {
    final ts = RegExp(r'^\d{4}-\d\d-\d\dT[0-9:.]+Z\s*');
    final lines = lastLog
        .split('\n')
        .map((l) => l.replaceFirst(ts, '').trim())
        .where((l) => l.isNotEmpty)
        .toList();
    final tail = lines.length > 7 ? lines.sublist(lines.length - 7) : lines;
    var t = tail.join('\n');
    if (t.length > 520) t = t.substring(t.length - 520);
    return t.isEmpty ? lastError : '$lastError\n$t';
  }
}
