import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// پورت SOCKS5 محلی Aether (یک پورت غیرمعمول تا با چیز دیگری تداخل نکند)
const int kAetherPort = 18190;

const _kScanModes = {'turbo', 'balanced', 'thorough', 'stealth', 'ironclad'};

/// مشخصات یک لینک aether://
class AetherSpec {
  AetherSpec({
    required this.protocol,
    required this.scan,
    required this.ip,
    required this.transport,
    required this.outer,
    required this.inner,
    required this.name,
  });

  final String protocol; // mim / masque / wg / gool
  final String scan;
  final String ip; // 4 / 6 / dual
  final String transport; // h2 / h3 / ''
  final String outer;
  final String inner;
  final String name;

  Map<String, String> toJson() => {
        'protocol': protocol,
        'scan': scan,
        'ip': ip,
        'transport': transport,
        'outer': outer,
        'inner': inner,
        'name': name,
      };

  static AetherSpec fromJson(Map<dynamic, dynamic> j) => AetherSpec(
        protocol: '${j['protocol'] ?? 'masque'}',
        scan: '${j['scan'] ?? 'balanced'}',
        ip: '${j['ip'] ?? 'dual'}',
        transport: '${j['transport'] ?? ''}',
        outer: '${j['outer'] ?? ''}',
        inner: '${j['inner'] ?? ''}',
        name: '${j['name'] ?? ''}',
      );
}

bool _validPeer(String s) =>
    s.isEmpty || RegExp(r'^[0-9A-Fa-f.:\[\]]+:\d{1,5}$').hasMatch(s);

/// aether://?protocol=mim&scan=balanced&ip=v4&transport=h2&outer=IP:443&inner=IP:443#نام
AetherSpec? parseAetherLink(String link) {
  try {
    final hash = link.indexOf('#');
    final name = hash < 0 ? '' : Uri.decodeComponent(link.substring(hash + 1));
    final body = hash < 0 ? link : link.substring(0, hash);
    final q = body.indexOf('?');
    final params = q < 0
        ? <String, String>{}
        : Uri.splitQueryString(body.substring(q + 1));
    var protocol = (params['protocol'] ?? 'masque').toLowerCase();
    if (protocol == 'mim' || protocol == 'masque-in-masque') protocol = 'mim';
    if (!{'mim', 'masque', 'wg', 'gool'}.contains(protocol)) return null;
    var scan = (params['scan'] ?? 'balanced').toLowerCase();
    if (!_kScanModes.contains(scan)) scan = 'balanced';
    var ip = (params['ip'] ?? 'dual').toLowerCase();
    ip = ip == 'v4' || ip == '4'
        ? '4'
        : (ip == 'v6' || ip == '6' ? '6' : 'dual');
    var tr = (params['transport'] ?? '').toLowerCase();
    if (tr != 'h2' && tr != 'h3') tr = '';
    final outer = params['outer'] ?? '';
    final inner = params['inner'] ?? '';
    if (!_validPeer(outer) || !_validPeer(inner)) return null;
    return AetherSpec(
      protocol: protocol,
      scan: scan,
      ip: ip,
      transport: tr,
      outer: outer,
      inner: inner,
      name: name,
    );
  } catch (_) {
    return null;
  }
}

const String kAetherKey = 'alvAether';

/// مشخصات Aether را از تنظیمات یک سرور (JSON) بیرون می‌کشد
AetherSpec? aetherFromConfig(String cfg) {
  if (!cfg.contains(kAetherKey)) return null;
  try {
    final m = jsonDecode(cfg);
    if (m is Map && m[kAetherKey] is Map) {
      return AetherSpec.fromJson(m[kAetherKey] as Map);
    }
  } catch (_) {}
  return null;
}

/// کلید داخلی را پیش از دادن تنظیمات به هسته برمی‌دارد
String stripAether(String cfg) {
  if (!cfg.contains(kAetherKey)) return cfg;
  try {
    final m = jsonDecode(cfg);
    if (m is Map) {
      m.remove(kAetherKey);
      return jsonEncode(m);
    }
  } catch (_) {}
  return cfg;
}

/// نام پکیج برنامه روی اندروید (برای خارج‌کردن خود برنامه از تونل VPN)
String? androidPackageName() {
  try {
    if (!Platform.isAndroid) return null;
    final b = File('/proc/self/cmdline').readAsBytesSync();
    final end = b.indexOf(0);
    final s = utf8.decode(end < 0 ? b : b.sublist(0, end), allowMalformed: true);
    return s.isEmpty ? null : s;
  } catch (_) {
    return null;
  }
}

/// اجرای برنامه‌ی aether به‌صورت پروسه‌ی جدا (فقط پروکسی SOCKS5 محلی می‌سازد)
class AetherRunner {
  static Process? _proc;
  static String lastLog = '';
  static String lastError = '';

  static bool get running => _proc != null;

  /// مسیر فایل اجرایی کنار برنامه (اندروید: پوشه‌ی کتابخانه‌های native)
  static String? binaryPath() {
    try {
      if (Platform.isAndroid) {
        for (final l in File('/proc/self/maps').readAsLinesSync()) {
          final i = l.indexOf('/');
          if (i < 0 || !l.contains('/lib/')) continue;
          final p = l.substring(i);
          if (p.endsWith('/libflutter.so') || p.endsWith('/libapp.so')) {
            final dir = p.substring(0, p.lastIndexOf('/'));
            final f = '$dir/libaether.so';
            if (File(f).existsSync()) return f;
          }
        }
        return null;
      }
      if (Platform.isWindows) {
        final dir = File(Platform.resolvedExecutable).parent.path;
        final f = '$dir\\core\\aether.exe';
        return File(f).existsSync() ? f : null;
      }
    } catch (_) {}
    return null;
  }

  static bool get available => binaryPath() != null;

  static String _dataDir() {
    final String base;
    if (Platform.isAndroid) {
      base = '${Directory.systemTemp.parent.path}/files/aether';
    } else {
      final local = Platform.environment['LOCALAPPDATA'] ??
          Platform.environment['APPDATA'] ??
          Directory.systemTemp.path;
      base = '$local\\AlvlIRm\\aether';
    }
    final d = Directory(base);
    if (!d.existsSync()) d.createSync(recursive: true);
    return d.path;
  }

  static List<String> _args(AetherSpec s) {
    final a = <String>[];
    switch (s.protocol) {
      case 'mim':
        a.add('--mim');
        break;
      case 'wg':
        a.add('--wg');
        break;
      case 'gool':
        a.add('--gool');
        break;
      default:
        a.add('--masque');
    }
    if (s.transport == 'h2') a.add('--h2');
    if (s.transport == 'h3') a.add('--h3');
    a.addAll(['--scan', s.scan]);
    if (s.protocol == 'mim') {
      if (s.outer.isNotEmpty) a.addAll(['--mim-outer', s.outer]);
      if (s.inner.isNotEmpty) a.addAll(['--mim-inner', s.inner]);
    }
    a.addAll(['--bind', '127.0.0.1:$kAetherPort']);
    return a;
  }

  /// پروسه را اجرا می‌کند و تا آماده‌شدن پورت SOCKS5 صبر می‌کند
  static Future<bool> start(AetherSpec spec,
      {Duration timeout = const Duration(seconds: 60)}) async {
    await stop();
    lastLog = '';
    lastError = '';
    final bin = binaryPath();
    if (bin == null) {
      lastError = 'aether binary not found';
      return false;
    }
    try {
      final p = await Process.start(
        bin,
        _args(spec),
        workingDirectory: _dataDir(),
        environment: {
          'AETHER_IP': spec.ip,
          'AETHER_LOG_LEVEL': 'info',
        },
      );
      _proc = p;
      var exited = false;
      void grab(List<int> d) {
        lastLog += utf8.decode(d, allowMalformed: true);
        if (lastLog.length > 1500) {
          lastLog = lastLog.substring(lastLog.length - 1500);
        }
      }

      p.stdout.listen(grab, onError: (_) {});
      p.stderr.listen(grab, onError: (_) {});
      p.exitCode.then((_) {
        exited = true;
        if (identical(_proc, p)) _proc = null;
      });

      final end = DateTime.now().add(timeout);
      while (DateTime.now().isBefore(end)) {
        if (exited) {
          lastError = 'aether exited';
          return false;
        }
        try {
          final s = await Socket.connect('127.0.0.1', kAetherPort,
              timeout: const Duration(milliseconds: 600));
          s.destroy();
          return true;
        } catch (_) {}
        await Future.delayed(const Duration(milliseconds: 500));
      }
      lastError = 'timeout waiting for aether';
      await stop();
      return false;
    } catch (e) {
      lastError = e.toString();
      _proc = null;
      return false;
    }
  }

  static Future<void> stop() async {
    final p = _proc;
    _proc = null;
    if (p == null) return;
    try {
      p.kill();
      await p.exitCode.timeout(const Duration(seconds: 3));
    } catch (_) {}
  }
}
