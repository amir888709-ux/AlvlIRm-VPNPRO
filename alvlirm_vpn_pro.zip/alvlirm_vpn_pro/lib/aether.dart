import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;

/// پورت SOCKS5 محلی Aether (یک پورت غیرمعمول تا با چیز دیگری تداخل نکند)
const int kAetherPort = 18190;

const _kScanModes = {'turbo', 'balanced', 'thorough', 'verified', 'ironclad'};
const _kNoize = {'off', 'light', 'firewall', 'balanced', 'gfw', 'aggressive'};

Map<String, String> _optsFrom(dynamic v) {
  final r = <String, String>{};
  if (v is Map) {
    v.forEach((k, val) {
      final t = '$val';
      if (t.isNotEmpty) r['$k'] = t;
    });
  }
  return r;
}

/// مشخصات یک لینک aether://
class AetherSpec {
  AetherSpec({
    required this.protocol,
    required this.scan,
    required this.ip,
    required this.transport,
    required this.outer,
    required this.inner,
    required this.name,
    this.peer = '',
    this.psiphon = '',
    this.psiphonMode = '',
    this.region = '',
    this.opts = const <String, String>{},
  });

  final String protocol; // mim / masque / wg / gool
  final String scan;
  final String ip; // 4 / 6 / dual
  final String transport; // h2 / h3 / ''
  final String outer;
  final String inner;
  final String name;
  final String peer; // نقطه‌ی پایانی ثابت  IP:PORT  (اختیاری)
  final String psiphon; // '' / chain / reverse / only
  final String psiphonMode; // '' / auto / cdn / direct
  final String region; // کد کشور خروجی Psiphon مثل DE

  /// گزینه‌های اضافه: noize ، dns ، sni ، fragment ، ech ، exit_loc ، api_* ،
  /// cdn_ips ، cdn_sni ، cdn_sets ، bundled ، cmd ، ...
  final Map<String, String> opts;

  Map<String, dynamic> toJson() => {
        'protocol': protocol,
        'scan': scan,
        'ip': ip,
        'transport': transport,
        'outer': outer,
        'inner': inner,
        'name': name,
        'peer': peer,
        'psiphon': psiphon,
        'psiphonMode': psiphonMode,
        'region': region,
        'opts': opts,
      };

  static AetherSpec fromJson(Map<dynamic, dynamic> j) => AetherSpec(
        protocol: '${j['protocol'] ?? 'masque'}',
        scan: '${j['scan'] ?? 'balanced'}',
        ip: '${j['ip'] ?? 'dual'}',
        transport: '${j['transport'] ?? ''}',
        outer: '${j['outer'] ?? ''}',
        inner: '${j['inner'] ?? ''}',
        name: '${j['name'] ?? ''}',
        peer: '${j['peer'] ?? ''}',
        psiphon: '${j['psiphon'] ?? ''}',
        psiphonMode: '${j['psiphonMode'] ?? ''}',
        region: '${j['region'] ?? ''}',
        opts: _optsFrom(j['opts']),
      );
}

bool _validPeer(String s) =>
    s.isEmpty || RegExp(r'^[0-9A-Fa-f.:\[\]]+:\d{1,5}$').hasMatch(s);

final RegExp _reHost = RegExp(r'^[A-Za-z0-9._-]{1,253}$');
final RegExp _reToken = RegExp(r'^[A-Za-z0-9._:/\[\]@=%&?-]{1,200}$');
final RegExp _reRange = RegExp(r'^\d{1,4}(-\d{1,4})?$');

/// فهرست جداشده با ویرگول/فاصله/نقطه‌ویرگول → «a,b,c» (یا '' اگر نامعتبر)
String _cleanList(String raw) {
  final parts = raw
      .split(RegExp(r'[,;\s]+'))
      .where((e) => e.isNotEmpty)
      .toList();
  if (parts.isEmpty || parts.length > 30) return '';
  for (final x in parts) {
    if (x.startsWith('-') || !_reToken.hasMatch(x)) return '';
  }
  return parts.join(',');
}

bool _truthy(String v) {
  final t = v.toLowerCase().trim();
  return t == '1' || t == 'true' || t == 'on' || t == 'yes';
}

/// aether://IP:PORT?protocol=masque&scan=balanced&ip=both&transport=h2&psiphon=chain&region=DE#نام
/// (بدون آدرس هم کار می‌کند:  aether://?protocol=mim&outer=IP:443&inner=IP:443#نام)
AetherSpec? parseAetherLink(String link) {
  try {
    final hash = link.indexOf('#');
    final name = hash < 0 ? '' : Uri.decodeComponent(link.substring(hash + 1));
    final body = hash < 0 ? link : link.substring(0, hash);
    final q = body.indexOf('?');
    // آدرس پیش از «؟» ، نقطه‌ی پایانی ثابت است
    var auth = (q < 0 ? body : body.substring(0, q)).trim();
    final sch = auth.indexOf('://');
    if (sch >= 0) auth = auth.substring(sch + 3);
    auth = auth.replaceAll('/', '');
    final raw = q < 0
        ? <String, String>{}
        : Uri.splitQueryString(body.substring(q + 1));
    // کلیدها: حروف کوچک و «-» → «_»
    final P = <String, String>{};
    raw.forEach((k, v) {
      P[k.toLowerCase().trim().replaceAll('-', '_')] = v.trim();
    });
    String pick(List<String> keys) {
      for (final k in keys) {
        final v = P[k];
        if (v != null && v.isNotEmpty) return v;
      }
      return '';
    }

    var protocol = pick(['protocol']).toLowerCase();
    if (protocol.isEmpty) protocol = 'masque';
    if (protocol == 'mim' || protocol == 'masque_in_masque' || protocol == 'masque-in-masque') {
      protocol = 'mim';
    }
    if (protocol == 'wireguard' || protocol == 'warp') protocol = 'wg';
    if (!{'mim', 'masque', 'wg', 'gool'}.contains(protocol)) return null;
    var scan = pick(['scan', 'scan_mode']).toLowerCase();
    if (scan == 'stealth') scan = 'verified';
    if (!_kScanModes.contains(scan)) scan = 'balanced';
    var ip = pick(['ip', 'ip_version']).toLowerCase();
    ip = ip == 'v4' || ip == '4'
        ? '4'
        : (ip == 'v6' || ip == '6' ? '6' : 'dual');
    var tr = pick(['transport']).toLowerCase();
    if (tr != 'h2' && tr != 'h3') tr = '';
    final outer = pick(['outer']);
    final inner = pick(['inner']);
    if (!_validPeer(outer) || !_validPeer(inner) || !_validPeer(auth)) {
      return null;
    }
    var psi = pick(['psiphon']).toLowerCase();
    if (_truthy(psi)) psi = 'chain';
    if (!{'chain', 'reverse', 'only'}.contains(psi)) psi = '';
    var pmode = pick(['psiphon_mode']).toLowerCase();
    if (!{'auto', 'cdn', 'direct'}.contains(pmode)) pmode = '';
    var region = pick(['region', 'psiphon_region']);
    region = RegExp(r'^[A-Za-z]{2}$').hasMatch(region)
        ? region.toUpperCase()
        : '';

    // ---- گزینه‌های اضافه ----
    final o = <String, String>{};
    final nz = pick(['noize', 'noise', 'obfuscation', 'obfs']).toLowerCase();
    if (_kNoize.contains(nz)) o['noize'] = nz;
    final dns = _cleanList(pick(['dns', 'resolvers', 'resolver']));
    if (dns.isNotEmpty) o['dns'] = dns;
    final sni = pick(['sni', 'masque_sni']);
    if (_reHost.hasMatch(sni)) o['sni'] = sni;
    if (_truthy(pick(['fragment', 'frag']))) o['fragment'] = '1';
    final fs = pick(['fragment_size']);
    if (_reRange.hasMatch(fs)) o['fragment_size'] = fs;
    final fd = pick(['fragment_delay']);
    if (_reRange.hasMatch(fd)) o['fragment_delay'] = fd;
    final ech = pick(['ech']);
    if (ech == 'auto' || RegExp(r'^[A-Za-z0-9+/=]{8,2000}$').hasMatch(ech)) {
      o['ech'] = ech;
    }
    final echDns = pick(['ech_dns']);
    if (echDns.isNotEmpty && !echDns.startsWith('-') && _reToken.hasMatch(echDns)) {
      o['ech_dns'] = echDns;
    }
    final echDomain = pick(['ech_domain']);
    if (_reHost.hasMatch(echDomain)) o['ech_domain'] = echDomain;
    final exitLoc = pick(['exit_loc', 'exit_location']).toUpperCase();
    if (RegExp(r'^!?[A-Z]{2}(,[A-Z]{2}){0,30}$').hasMatch(exitLoc)) {
      o['exit_loc'] = exitLoc;
    }
    final apiAddr = pick(['api_address']);
    if (RegExp(r'^[A-Za-z0-9.:\[\]_-]{1,100}$').hasMatch(apiAddr) &&
        !apiAddr.startsWith('-')) {
      o['api_address'] = apiAddr;
    }
    final apiSni = pick(['api_sni']);
    if (_reHost.hasMatch(apiSni)) o['api_sni'] = apiSni;
    final apiHost = pick(['api_host']);
    if (_reHost.hasMatch(apiHost)) o['api_host'] = apiHost;
    final ka = pick(['keepalive']);
    if (RegExp(r'^\d{1,3}$').hasMatch(ka)) o['keepalive'] = ka;
    final cdnIps = _cleanList(pick(['psiphon_cdn_ips', 'cdn_ips']));
    if (cdnIps.isNotEmpty) o['cdn_ips'] = cdnIps;
    final cdnSni = _cleanList(pick(['psiphon_cdn_sni', 'cdn_sni']));
    if (cdnSni.isNotEmpty) o['cdn_sni'] = cdnSni;
    final cdnSets = _cleanList(pick(['psiphon_cdn_sets', 'cdn_sets']));
    if (cdnSets.isNotEmpty) o['cdn_sets'] = cdnSets;
    final bundled = pick(['bundled', 'psiphon_bundled', 'use_bundled_list', 'bundled_list']);
    if (bundled.isNotEmpty) o['bundled'] = _truthy(bundled) ? '1' : '0';
    final cmd = pick(['cmd', 'command']);
    if (cmd.isNotEmpty && cmd.length <= 600) o['cmd'] = cmd;

    return AetherSpec(
      peer: auth,
      psiphon: psi,
      psiphonMode: pmode,
      region: region,
      opts: o,
      protocol: protocol,
      scan: scan,
      ip: ip,
      transport: tr,
      outer: outer,
      inner: inner,
      name: name,
    );
  } catch (_) {
    return null;
  }
}

const String kAetherKey = 'alvAether';

/// مشخصات Aether را از تنظیمات یک سرور (JSON) بیرون می‌کشد
AetherSpec? aetherFromConfig(String cfg) {
  if (!cfg.contains(kAetherKey)) return null;
  try {
    final m = jsonDecode(cfg);
    if (m is Map && m[kAetherKey] is Map) {
      return AetherSpec.fromJson(m[kAetherKey] as Map);
    }
  } catch (_) {}
  return null;
}

/// کلید داخلی را پیش از دادن تنظیمات به هسته برمی‌دارد
String stripAether(String cfg) {
  if (!cfg.contains(kAetherKey)) return cfg;
  try {
    final m = jsonDecode(cfg);
    if (m is Map) {
      m.remove(kAetherKey);
      return jsonEncode(m);
    }
  } catch (_) {}
  return cfg;
}

/// نام پکیج برنامه روی اندروید (برای خارج‌کردن خود برنامه از تونل VPN)
String? androidPackageName() {
  try {
    if (!Platform.isAndroid) return null;
    final b = File('/proc/self/cmdline').readAsBytesSync();
    final end = b.indexOf(0);
    final s = utf8.decode(end < 0 ? b : b.sublist(0, end), allowMalformed: true);
    return s.isEmpty ? null : s;
  } catch (_) {
    return null;
  }
}

/// اجرای برنامه‌ی aether به‌صورت پروسه‌ی جدا (فقط پروکسی SOCKS5 محلی می‌سازد)
class AetherRunner {
  static Process? _proc;
  static String lastLog = '';
  static String lastError = '';

  /// گزارش کامل آخرین اجرا (برای صفحه‌ی «گزارش Aether»)
  static String fullLog = '';
  static String _partial = '';
  static final RegExp _noisy = RegExp(r'^\[\S+\s+(DEBUG|TRACE)\b');
  static final RegExp _tsRe =
      RegExp(r'^\[?\d{4}-\d\d-\d\dT[0-9:.]+Z\s*(?:[A-Z]+\s+[\w:]+\])?\s*');

  static void note(String s) => _note(s);

  /// نسخه‌ی فشرده‌ی گزارش برای کپی/نمایش: بدون خط‌های پرحجم و بدون آدرس‌های محرمانه
  static String reportText() {
    final skip = RegExp(
        r'Memory metrics|Datastore metrics|DNS metrics|Homepage|ConnectingServer|CandidateServers|keepalive|ServerEntryIterator|SessionId|NetworkID|BuildInfo|ClientUpgrade|ActiveAuthorization|TrafficRateLimits|ServerTimestamp|socks client .* ended');
    final out = <String>[];
    for (final l in fullLog.split('\n')) {
      if (l.trim().isEmpty || skip.hasMatch(l)) continue;
      out.add(l.length > 300 ? '${l.substring(0, 300)}...' : l);
    }
    var t = out.join('\n');
    if (t.length > 15000) {
      t = '${t.substring(0, 2500)}\n...\n${t.substring(t.length - 12000)}';
    }
    return t;
  }

  static void _note(String s) {
    fullLog += '$s\n';
    if (fullLog.length > 60000) {
      fullLog = fullLog.substring(fullLog.length - 60000);
    }
  }

  /// خروجی aether: همه‌چیز به گزارش کامل ، فقط خط‌های مهم (نه DEBUG) به lastLog و وضعیت زنده
  static void _ingest(String chunk) {
    fullLog += chunk;
    if (fullLog.length > 60000) {
      fullLog = fullLog.substring(fullLog.length - 60000);
    }
    final parts = (_partial + chunk).split('\n');
    _partial = parts.removeLast();
    final keep = StringBuffer();
    for (final l in parts) {
      if (_noisy.hasMatch(l)) continue;
      keep.writeln(l);
    }
    final k = keep.toString();
    if (k.isEmpty) return;
    lastLog += k;
    _trimLog();
    _live(k);
  }

  static bool get running => _proc != null;

  static String triedDirs = '';
  static String? _cachedBin;

  /// خطوط /proc/<pid>/maps (چند راه، چون بعد از فعالیت سنگین هسته یکی‌شان ممکن است خطا بدهد)
  static List<String> _mapsLines() {
    final paths = ['/proc/self/maps', '/proc/$pid/maps'];
    for (final p in paths) {
      try {
        final l = File(p).readAsLinesSync();
        if (l.isNotEmpty) return l;
      } catch (_) {
        try {
          final b = File(p).readAsBytesSync();
          final l = utf8.decode(b, allowMalformed: true).split('\n');
          if (l.isNotEmpty) return l;
        } catch (_) {}
      }
    }
    try {
      final r = Process.runSync('cat', ['/proc/self/maps']);
      final l = r.stdout.toString().split('\n');
      if (l.isNotEmpty) return l;
    } catch (_) {}
    return <String>[];
  }

  static String? _scanAndroid() {
    final lines = _mapsLines();
    final dirs = <String>{};
    for (final l in lines) {
      final i = l.indexOf('/');
      if (i < 0) continue;
      final p = l.substring(i).trim();
      if (!p.endsWith('.so') || !p.contains('/lib/')) continue;
      dirs.add(p.substring(0, p.lastIndexOf('/')));
    }
    for (final d in dirs) {
      final f = '$d/libaether.so';
      if (File(f).existsSync()) return f;
    }
    triedDirs = 'maps=${lines.length} so=${dirs.length} ${dirs.take(2).join(', ')}';
    return null;
  }

  /// مسیر فایل اجرایی کنار برنامه (اندروید: پوشه‌ی کتابخانه‌های native)
  static String? binaryPath() {
    try {
      if (Platform.isAndroid) {
        final c = _cachedBin;
        if (c != null && File(c).existsSync()) return c;
        final f = _scanAndroid();
        if (f != null) _cachedBin = f;
        return f;
      }
      if (Platform.isWindows) {
        final dir = File(Platform.resolvedExecutable).parent.path;
        final f = '$dir\\core\\aether.exe';
        return File(f).existsSync() ? f : null;
      }
    } catch (e) {
      triedDirs = e.toString();
    }
    return null;
  }

  /// فایل اجرایی Psiphon (کنار فایل aether)
  static String? psiphonPath() {
    try {
      final bin = binaryPath();
      if (bin == null) return null;
      final sep = Platform.isWindows ? '\\' : '/';
      final dir = bin.substring(0, bin.lastIndexOf(sep));
      final names = Platform.isWindows
          ? ['psiphon-tunnel-core.exe', 'pt\\psiphon-tunnel-core.exe']
          : ['libpsiphon.so'];
      for (final n in names) {
        final f = '$dir$sep$n';
        if (File(f).existsSync()) return f;
      }
    } catch (_) {}
    return null;
  }

  /// هنگام شروع برنامه (پیش از هر پینگ سنگین) مسیر فایل را پیدا و نگه می‌دارد
  static void warmUp() {
    try {
      binaryPath();
    } catch (_) {}
  }

  static bool get available => binaryPath() != null;

  static String _dataDir() {
    final String base;
    if (Platform.isAndroid) {
      base = '${Directory.systemTemp.parent.path}/files/aether';
    } else {
      final local = Platform.environment['LOCALAPPDATA'] ??
          Platform.environment['APPDATA'] ??
          Directory.systemTemp.path;
      base = '$local\\AlvlIRm\\aether';
    }
    final d = Directory(base);
    if (!d.existsSync()) d.createSync(recursive: true);
    return d.path;
  }

  // پرچم‌هایی که در «دستور دلخواه» اجازه ندارند (امنیت: مسیر فایل/اجرای برنامه/پورت)
  static const Set<String> _denied = {
    '--bind', '--psiphon-bind', '--http-proxy', '--psiphon-http',
    '--tor-bind', '--tor-http', '--psiphon-bin', '--psiphon-dir',
    '--psiphon-config', '--psiphon-server-entries', '--config',
    '--wg-config', '--masque-config', '--routes', '--tor-pt', '--tor-pt-dir',
    '--tor-bridge-file', '--tor-dir', '--mark', '--upstream', '--register',
    '-h', '--help', 'help', '-v', '--version',
  };

  static List<String> _tokenize(String s) {
    final out = <String>[];
    final cur = StringBuffer();
    String? quote;
    var has = false;
    for (final r in s.runes) {
      final c = String.fromCharCode(r);
      if (quote != null) {
        if (c == quote) {
          quote = null;
        } else {
          cur.write(c);
        }
      } else if (c == '"' || c == "'") {
        quote = c;
        has = true;
      } else if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
        if (has || cur.isNotEmpty) {
          out.add(cur.toString());
          cur.clear();
          has = false;
        }
      } else {
        cur.write(c);
      }
    }
    if (has || cur.isNotEmpty) out.add(cur.toString());
    return out;
  }

  static List<String> _customArgs(String cmd) {
    final toks = _tokenize(cmd);
    if (toks.isNotEmpty) {
      final f = toks.first.toLowerCase();
      if (f == 'aether' || f.endsWith('/aether') || f.endsWith('\\aether.exe')) {
        toks.removeAt(0);
      }
    }
    final out = <String>[];
    for (var i = 0; i < toks.length; i++) {
      final t = toks[i];
      final name = t.contains('=') ? t.substring(0, t.indexOf('=')) : t;
      if (_denied.contains(name)) {
        if (!t.contains('=') && i + 1 < toks.length && !toks[i + 1].startsWith('-')) {
          i++;
        }
        continue;
      }
      out.add(t);
    }
    return out;
  }

  /// حالت Psiphon مؤثر ('' / chain / reverse / only)
  static String _effPsi(AetherSpec s) {
    final cmd = s.opts['cmd'] ?? '';
    if (cmd.isEmpty) return s.psiphon;
    final t = _customArgs(cmd);
    if (t.contains('--psiphon-only')) return 'only';
    if (t.contains('--psiphon-reverse')) return 'reverse';
    if (t.contains('--psiphon')) return 'chain';
    return '';
  }

  static String? _entriesPath;

  /// لیست سرور داخلی Psiphon را (اگر موقع بیلد گذاشته شده) آماده می‌کند
  static Future<void> _prepareEntries() async {
    _entriesPath = null;
    try {
      if (Platform.isWindows) {
        final dir = File(Platform.resolvedExecutable).parent.path;
        final f = File('$dir\\core\\psiphon-servers.txt');
        if (f.existsSync() && f.lengthSync() > 100) _entriesPath = f.path;
        return;
      }
      if (Platform.isAndroid) {
        final data = await rootBundle.load('assets/psiphon/servers.txt');
        if (data.lengthInBytes < 100) return;
        final f = File('${_dataDir()}/psiphon-servers.txt');
        f.writeAsBytesSync(
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
          flush: true,
        );
        _entriesPath = f.path;
      }
    } catch (_) {
      _entriesPath = null;
    }
  }

  static List<String> _args(AetherSpec s) {
    final o = s.opts;
    final a = <String>[];
    final custom = o['cmd'] ?? '';
    if (custom.isNotEmpty) {
      a.addAll(_customArgs(custom));
    } else {
      switch (s.protocol) {
        case 'mim':
          a.add('--mim');
          break;
        case 'wg':
          a.add('--wg');
          break;
        case 'gool':
          a.add('--gool');
          break;
        default:
          a.add('--masque');
      }
      if (s.transport == 'h2') a.add('--h2');
      if (s.transport == 'h3') a.add('--h3');
      a.addAll(['--scan', s.scan]);
      if (s.protocol == 'mim') {
        if (s.outer.isNotEmpty) a.addAll(['--mim-outer', s.outer]);
        if (s.inner.isNotEmpty) a.addAll(['--mim-inner', s.inner]);
      } else if (s.peer.isNotEmpty &&
          (s.protocol == 'masque' || s.protocol == 'wg')) {
        a.addAll(['--peer', s.peer]);
      }
      void opt(String key, String flag) {
        final v = o[key] ?? '';
        if (v.isNotEmpty) a.addAll([flag, v]);
      }

      a.addAll(['--ip', s.ip == '4' ? 'v4' : (s.ip == '6' ? 'v6' : 'both')]);
      opt('noize', '--noize');
      opt('dns', '--dns');
      opt('sni', '--masque-sni');
      if (o['fragment'] == '1') a.add('--fragment');
      opt('fragment_size', '--fragment-size');
      opt('fragment_delay', '--fragment-delay');
      opt('ech', '--ech');
      opt('ech_dns', '--ech-dns');
      opt('ech_domain', '--ech-domain');
      opt('exit_loc', '--exit-loc');
      opt('api_address', '--api-address');
      opt('api_sni', '--api-sni');
      opt('api_host', '--api-host');
      opt('keepalive', '--keepalive');
      if (s.psiphon == 'chain') {
        a.add('--psiphon');
      } else if (s.psiphon == 'reverse') {
        a.add('--psiphon-reverse');
      } else if (s.psiphon == 'only') {
        a.add('--psiphon-only');
      }
      if (s.psiphon.isNotEmpty) {
        if (s.psiphonMode.isNotEmpty) {
          a.addAll(['--psiphon-mode', s.psiphonMode]);
        }
        if (s.region.isNotEmpty) a.addAll(['--psiphon-region', s.region]);
        opt('cdn_ips', '--psiphon-cdn-ips');
        opt('cdn_sni', '--psiphon-cdn-sni');
        opt('cdn_sets', '--psiphon-cdn-sets');
      }
    }

    // پورت‌ها (همیشه ما تعیین می‌کنیم)
    final psi = _effPsi(s);
    final mainAddr = '127.0.0.1:$kAetherPort';
    final aux = '127.0.0.1:${kAetherPort + 1}';
    switch (psi) {
      case 'chain':
        // aether → warp → psiphon → اینترنت ؛ پروکسی نهایی روی پورت psiphon است
        a.addAll(['--bind', aux, '--psiphon-bind', mainAddr]);
        break;
      case 'reverse':
        a.addAll(['--bind', mainAddr, '--psiphon-bind', aux]);
        break;
      default:
        a.addAll(['--bind', mainAddr]);
    }
    if (psi.isNotEmpty) {
      final pb = psiphonPath();
      if (pb != null) a.addAll(['--psiphon-bin', pb]);
      a.addAll([
        '--psiphon-dir',
        '${_dataDir()}${Platform.pathSeparator}psiphon',
      ]);
      final ep = _entriesPath;
      if (ep != null && o['bundled'] != '0') {
        a.addAll(['--psiphon-server-entries', ep]);
      }
    }
    return a;
  }

  /// آیا سرور واقعاً از تونل عبور می‌دهد؟ (یک اتصال SOCKS5 آزمایشی)
  static Future<bool> _socksWorks(Duration wait) async {
    final c =
        await _socksConnect('www.gstatic.com', 80, DateTime.now().add(wait));
    if (c == null) return false;
    c.sk.destroy();
    return true;
  }

  /// پروسه را اجرا می‌کند و تا آماده‌شدن پورت SOCKS5 صبر می‌کند
  static Future<bool> start(AetherSpec spec, {Duration? timeout}) async {
    var ok = await _start(spec, timeout);
    // Psiphon گاهی به‌خاطر نمونه‌ی نیمه‌جان قبلی (قفل پایگاه‌داده) بالا نمی‌آید: یک بار دوباره
    if (!ok &&
        _effPsi(spec).isNotEmpty &&
        lastError.startsWith('aether exited') &&
        lastLog.contains('timeout')) {
      final firstLog = lastLog;
      final firstFull = fullLog;
      await _killStray();
      await Future.delayed(const Duration(seconds: 2));
      ok = await _start(spec, timeout);
      if (!ok) lastLog = '$firstLog\n$lastLog';
      fullLog = '$firstFull\n--- retry ---\n$fullLog';
    }
    if (!ok) _note('== failed: $lastError ==');
    return ok;
  }

  static Future<bool> _start(AetherSpec spec, Duration? timeout) async {
    final psi = _effPsi(spec).isNotEmpty;
    _psi = psi;
    timeout ??= Duration(seconds: psi ? 200 : 60);
    await stop();
    await _killStray();
    lastLog = '';
    lastError = '';
    liveLine = '';
    fullLog = '';
    _partial = '';
    final tag = psi ? '+psiphon' : '';
    _note('== ${DateTime.now().toIso8601String()} | ${spec.protocol} $tag | ip=${spec.ip} ==');
    if (psi) await _prepareEntries();
    var bin = binaryPath();
    for (var i = 0; i < 4 && bin == null; i++) {
      await Future.delayed(const Duration(milliseconds: 400));
      bin = binaryPath();
    }
    if (bin == null) {
      lastError = 'aether binary not found (dirs: ${triedDirs.isEmpty ? '-' : triedDirs})';
      return false;
    }
    // کلید WARP هنوز ساخته نشده؟ خودکار می‌سازیم (اگر نشد، با fragment هم امتحان می‌شود)
    if ((spec.opts['cmd'] ?? '').isEmpty && keyInfo(spec.protocol) == null) {
      final err = await registerKey(spec.protocol, spec.opts, fresh: false);
      if (err.isNotEmpty) {
        lastError = 'WARP key could not be created';
        return false;
      }
      lastLog = '';
      liveLine = '';
    }
    try {
      final args = _args(spec);
      _note('bin: $bin');
      if (psi) {
        _note('psiphon: ${psiphonPath()}');
        _note('entries: ${_entriesPath ?? '-'}');
      }
      _note('args: ${args.join(' ')}');
      _partial = '';
      final p = await Process.start(
        bin,
        args,
        workingDirectory: _dataDir(),
        environment: {
          'AETHER_IP': spec.ip,
          'AETHER_LOG_LEVEL': 'info',
          if (psi) 'AETHER_PSIPHON_READY_SECS': '150',
        },
      );
      _proc = p;
      var exited = false;
      void grab(List<int> d) => _ingest(utf8.decode(d, allowMalformed: true));

      p.stdout.listen(grab, onError: (_) {});
      p.stderr.listen(grab, onError: (_) {});
      p.exitCode.then((code) {
        exited = true;
        _note('== aether exited, code $code ==');
        if (identical(_proc, p)) _proc = null;
      });

      final end = DateTime.now().add(timeout);
      var probe = 0;
      while (DateTime.now().isBefore(end)) {
        if (exited) {
          lastError = 'aether exited';
          return false;
        }
        if (!identical(_proc, p)) {
          lastError = 'cancelled';
          return false;
        }
        try {
          final s = await Socket.connect('127.0.0.1', kAetherPort,
              timeout: const Duration(milliseconds: 600));
          s.destroy();
          // Psiphon دیرتر از پورت آماده می‌شود؛ تا عبور واقعی ترافیک صبر می‌کنیم
          if (!psi) return true;
          final sw = Stopwatch()..start();
          final okp = await _socksWorks(const Duration(seconds: 20));
          probe++;
          _note(
              'probe #$probe through the tunnel: ${okp ? 'ok' : 'failed'} (${sw.elapsedMilliseconds} ms)');
          if (okp) return true;
        } catch (_) {}
        await Future.delayed(const Duration(milliseconds: 500));
      }
      lastError = 'timeout waiting for aether';
      await stop();
      return false;
    } catch (e) {
      lastError = e.toString();
      _proc = null;
      return false;
    }
  }

  static Future<void> stop() async {
    final p = _proc;
    _proc = null;
    liveLine = '';
    if (p == null) return;
    try {
      p.kill();
      await p.exitCode.timeout(const Duration(seconds: 3));
    } catch (_) {}
    if (Platform.isWindows && _psi) {
      try {
        await Process.run('taskkill', ['/F', '/T', '/PID', '${p.pid}']);
      } catch (_) {}
    }
    await _killStray();
  }

  static bool _psi = false;

  /// آخرین خط گزارش (برای نمایش زنده‌ی وضعیت اتصال)
  static String liveLine = '';
  static void Function()? onLog;
  static DateTime _lastLive = DateTime.fromMillisecondsSinceEpoch(0);

  static void _live(String chunk) {
    try {
      final ts = _tsRe;
      String? last;
      for (final l in chunk.split('\n')) {
        final t = l.replaceFirst(ts, '').trim();
        if (t.isNotEmpty) last = t;
      }
      if (last == null) return;
      liveLine = last.length > 110 ? last.substring(0, 110) : last;
      final now = DateTime.now();
      if (now.difference(_lastLive).inMilliseconds > 700) {
        _lastLive = now;
        final f = onLog;
        if (f != null) f();
      }
    } catch (_) {}
  }

  // ---------------------------------------------------------------------
  // کلید WARP ، اسکن نقطه‌ی پایانی ، پینگ
  // ---------------------------------------------------------------------
  static String _identityFile(String protocol) {
    switch (protocol) {
      case 'wg':
        return 'aether.toml';
      case 'gool':
        return 'aether-masque-gool.toml';
      default:
        return 'aether-masque.toml';
    }
  }

  static String _tomlValue(String text, String key) {
    final m = RegExp('^\\s*' + key + r'\s*=\s*"([^"]*)"', multiLine: true)
        .firstMatch(text);
    return m == null ? '' : (m.group(1) ?? '');
  }

  /// [شناسه‌ی دستگاه ، IPv4 ، IPv6] یا null اگر کلید هنوز ساخته نشده
  static List<String>? keyInfo(String protocol) {
    try {
      final f = File(
          '${_dataDir()}${Platform.pathSeparator}${_identityFile(protocol)}');
      if (!f.existsSync()) return null;
      final t = f.readAsStringSync();
      final id = _tomlValue(t, 'device_id');
      if (id.isEmpty) return null;
      return [id, _tomlValue(t, 'ipv4'), _tomlValue(t, 'ipv6')];
    } catch (_) {
      return null;
    }
  }

  static void _trimLog() {
    if (lastLog.length > 4000) {
      lastLog = lastLog.substring(lastLog.length - 4000);
    }
  }

  /// aether را یک‌بار اجرا می‌کند تا تمام شود (برای --register)
  static Future<int> _runOnce(
      String bin, List<String> args, Duration limit) async {
    try {
      final p = await Process.start(
        bin,
        args,
        workingDirectory: _dataDir(),
        environment: {'AETHER_LOG_LEVEL': 'info'},
      );
      _proc = p;
      _partial = '';
      void grab(List<int> d) => _ingest(utf8.decode(d, allowMalformed: true));

      p.stdout.listen(grab, onError: (_) {});
      p.stderr.listen(grab, onError: (_) {});
      final code = await p.exitCode.timeout(limit, onTimeout: () {
        p.kill();
        return -1;
      });
      if (identical(_proc, p)) _proc = null;
      return code;
    } catch (e) {
      lastError = e.toString();
      _proc = null;
      return -2;
    }
  }

  /// کلید تازه‌ی WARP می‌سازد (کلید قبلی پاک می‌شود). نتیجه: '' = موفق ، وگرنه متن خطا
  static Future<String> registerKey(
      String protocol, Map<String, String> opts,
      {bool fresh = true}) async {
    await stop();
    await _killStray();
    lastLog = '';
    lastError = '';
    liveLine = '';
    if (fresh) {
      fullLog = '';
      _partial = '';
    }
    _note('== register key (${fresh ? 'new' : 'auto'}) $protocol ==');
    final bin = binaryPath();
    if (bin == null) {
      return 'aether binary not found (dirs: ${triedDirs.isEmpty ? '-' : triedDirs})';
    }
    final dir = _dataDir();
    final names = <String>{_identityFile(protocol)};
    if (protocol == 'gool') names.add('aether-masque.toml');
    if (protocol == 'mim') names.add('aether-masque-secondary.toml');
    if (fresh) {
      for (final n in names) {
        try {
          final f = File('$dir${Platform.pathSeparator}$n');
          if (f.existsSync()) f.deleteSync();
        } catch (_) {}
      }
    }
    final fragmentFirst = opts['fragment'] == '1';
    for (var attempt = 0; attempt < 2; attempt++) {
      if (attempt == 1 && fragmentFirst) break;
      final args = <String>['--register', protocol];
      void opt(String key, String flag) {
        final v = (opts[key] ?? '').trim();
        if (v.isNotEmpty && !v.startsWith('-') && _reToken.hasMatch(v)) {
          args.addAll([flag, v]);
        }
      }

      opt('api_address', '--api-address');
      opt('api_sni', '--api-sni');
      opt('api_host', '--api-host');
      if (fragmentFirst || attempt == 1) args.add('--fragment');
      lastLog = '';
      final code = await _runOnce(bin, args, const Duration(seconds: 120));
      if (code == 0 && keyInfo(protocol) != null) return '';
    }
    final t = summary();
    return t.isEmpty ? 'register failed' : t;
  }

  /// با اسکن، نقطه‌ی پایانی کارا را پیدا می‌کند.
  /// نتیجه: 'IP:PORT' (برای mim: 'outer|inner') یا null
  static Future<String?> scan(AetherSpec spec) async {
    await stop();
    await _killStray();
    lastLog = '';
    lastError = '';
    liveLine = '';
    fullLog = '';
    _partial = '';
    _note('== scan ${spec.protocol} ==');
    final bin = binaryPath();
    if (bin == null) {
      lastError = 'aether binary not found';
      return null;
    }
    final opts = Map<String, String>.from(spec.opts)..remove('cmd');
    final sc = AetherSpec(
      protocol: spec.protocol,
      scan: spec.scan,
      ip: spec.ip,
      transport: spec.transport,
      outer: '',
      inner: '',
      name: spec.name,
      opts: opts,
    );
    Process p;
    try {
      p = await Process.start(
        bin,
        _args(sc),
        workingDirectory: _dataDir(),
        environment: {
          'AETHER_IP': sc.ip,
          'AETHER_LOG_LEVEL': 'info',
          'AETHER_QUICK_RECONNECT': '0',
        },
      );
    } catch (e) {
      lastError = e.toString();
      return null;
    }
    _proc = p;
    String? found;
    var exited = false;
    final reMim = RegExp(r'ready: (\S+) \(outer\) and (\S+) \(inner\)');
    final reMim2 = RegExp(r'using cloudflare edge (\S+) \(outer\) and (\S+) \(inner\)');
    final reGool = RegExp(r'gool ready: masque (\S+) carries');
    final reWg = RegExp(r'selected WireGuard endpoint (\S+)');
    final reEdge = RegExp(r'using cloudflare edge (\S+)');
    void grab(List<int> d) {
      _ingest(utf8.decode(d, allowMalformed: true));
      if (found != null) return;
      final all = lastLog;
      if (sc.protocol == 'mim') {
        final m = reMim.firstMatch(all) ?? reMim2.firstMatch(all);
        if (m != null) found = '${m.group(1)}|${m.group(2)}';
      } else if (sc.protocol == 'gool') {
        final m = reGool.firstMatch(all);
        if (m != null) found = m.group(1);
      } else {
        final m = reWg.firstMatch(all) ?? reEdge.firstMatch(all);
        if (m != null) found = m.group(1);
      }
    }

    p.stdout.listen(grab, onError: (_) {});
    p.stderr.listen(grab, onError: (_) {});
    p.exitCode.then((_) {
      exited = true;
    });
    final end = DateTime.now().add(const Duration(seconds: 150));
    while (DateTime.now().isBefore(end) &&
        found == null &&
        !exited &&
        identical(_proc, p)) {
      await Future.delayed(const Duration(milliseconds: 300));
    }
    final r = found;
    await stop();
    if (r == null) {
      lastError = exited ? 'aether exited' : 'scan timeout';
    }
    return r;
  }

  /// یک درخواست HTTP از راه پروکسی SOCKS5 محلی ؛ زمان پاسخ به میلی‌ثانیه (یا -1)
  static Future<int> _socksGet(Duration wait) async {
    const host = 'connectivitycheck.gstatic.com';
    final end = DateTime.now().add(wait);
    final c = await _socksConnect(host, 80, end);
    if (c == null) return -1;
    try {
      final sw = Stopwatch()..start();
      c.sk.add(utf8.encode(
          'GET /generate_204 HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n'));
      final ok = await c.until(
          () => String.fromCharCodes(c.buf).contains('HTTP/'), end);
      sw.stop();
      return ok ? sw.elapsedMilliseconds : -1;
    } catch (_) {
      return -1;
    } finally {
      try {
        c.sk.destroy();
      } catch (_) {}
    }
  }

  /// بدنه‌ی پاسخ HTTP (پس از سرآیندها) از بایت‌های دریافتی ؛ '' اگر هنوز کامل نیست
  static String _bodyOf(List<int> buf) {
    final t = String.fromCharCodes(buf);
    final h = t.indexOf('HTTP/');
    if (h < 0) return '';
    final e = t.indexOf('\r\n\r\n', h);
    return e < 0 ? '' : t.substring(e + 4);
  }

  /// یک درخواست HTTP ساده (پورت 80) از راه پروکسی SOCKS5 محلی ؛ بدنه‌ی پاسخ یا ''
  static Future<String> _socksFetch(
      String host, String path, Duration wait) async {
    final end = DateTime.now().add(wait);
    final c = await _socksConnect(host, 80, end);
    if (c == null) return '';
    try {
      c.sk.add(utf8.encode(
          'GET $path HTTP/1.0\r\nHost: $host\r\nUser-Agent: curl/8.5.0\r\nAccept: */*\r\n\r\n'));
      while (DateTime.now().isBefore(end)) {
        final b = _bodyOf(c.buf);
        if (b.isNotEmpty && (c.closed || b.contains('\n'))) return b;
        if (c.closed) return b;
        await Future.delayed(const Duration(milliseconds: 50));
      }
      return _bodyOf(c.buf);
    } catch (_) {
      return '';
    } finally {
      try {
        c.sk.destroy();
      } catch (_) {}
    }
  }

  /// دست‌دادن درست SOCKS5 با پروکسی محلی: اول سلام ، منتظر پاسخ ، بعد CONNECT.
  /// (ارسال هم‌زمان هر دو پیام را Psiphon رد می‌کند: «bytes left after SOCKS message»)
  /// موفق: اتصال آماده‌ی ارسال داده ؛ ناموفق: null
  static Future<_SocksConn?> _socksConnect(
      String host, int port, DateTime end) async {
    Socket sk;
    try {
      sk = await Socket.connect('127.0.0.1', kAetherPort,
          timeout: const Duration(seconds: 3));
    } catch (_) {
      return null;
    }
    final c = _SocksConn(sk);
    try {
      sk.add([5, 1, 0]);
      if (!await c.until(() => c.buf.length >= 2, end) ||
          c.buf[0] != 5 ||
          c.buf[1] != 0) {
        sk.destroy();
        return null;
      }
      c.buf.removeRange(0, 2);
      final hb = utf8.encode(host);
      sk.add([5, 1, 0, 3, hb.length, ...hb, (port >> 8) & 255, port & 255]);
      if (!await c.until(() => c.buf.length >= 4, end)) {
        sk.destroy();
        return null;
      }
      if (c.buf[0] != 5 || c.buf[1] != 0) {
        _note('socks connect refused: ${c.buf.take(10).toList()}');
        sk.destroy();
        return null;
      }
      final atyp = c.buf[3];
      var need = 10;
      if (atyp == 4) {
        need = 22;
      } else if (atyp == 3) {
        if (!await c.until(() => c.buf.length >= 5, end)) {
          sk.destroy();
          return null;
        }
        need = 7 + c.buf[4];
      }
      if (!await c.until(() => c.buf.length >= need, end)) {
        sk.destroy();
        return null;
      }
      c.buf.removeRange(0, need);
      return c;
    } catch (e) {
      _note('socks error: $e');
      try {
        sk.destroy();
      } catch (_) {}
      return null;
    }
  }

  /// کد کشور خروجی سرور (برای نمایش پرچم) ؛ باید همین حالا تونل بالا باشد. '' = نامعلوم
  static Future<String> exitCountry() async {
    const tries = [
      ['ip-api.com', '/line/?fields=countryCode'],
      ['ipinfo.io', '/country'],
    ];
    for (final t in tries) {
      final b = await _socksFetch(t[0], t[1], const Duration(seconds: 8));
      final line = b.trim().split('\n').first.trim().toUpperCase();
      if (RegExp(r'^[A-Z]{2}$').hasMatch(line)) return line;
    }
    return '';
  }

  /// کشور خروجی که آخرین پینگ پیدا کرد
  static String lastExit = '';

  /// پینگ واقعی یک سرور Aether: اجرا ، اتصال ، یک درخواست آزمایشی ، توقف
  static Future<int> ping(AetherSpec spec) async {
    lastExit = '';
    if (!await start(spec)) {
      await stop();
      return -1;
    }
    var best = -1;
    for (var i = 0; i < 2; i++) {
      final ms = await _socksGet(const Duration(seconds: 15));
      if (ms > 0 && (best < 0 || ms < best)) best = ms;
    }
    if (best > 0) lastExit = await exitCountry();
    await stop();
    if (best < 0) lastError = 'no response through the tunnel';
    return best;
  }

  /// کلید WARP و داده‌های Aether/Psiphon را پاک می‌کند (در اتصال بعدی تازه ساخته می‌شود)
  static Future<bool> resetData() async {
    await stop();
    try {
      final d = Directory(_dataDir());
      if (d.existsSync()) d.deleteSync(recursive: true);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// پروسه‌های رهاشده‌ی aether / psiphon (از اجرای قبلی) را می‌بندد
  static Future<void> _killStray() async {
    try {
      if (Platform.isAndroid) {
        for (final e in Directory('/proc').listSync(followLinks: false)) {
          final id = int.tryParse(e.path.split('/').last);
          if (id == null || id == pid) continue;
          try {
            final t = utf8.decode(File('/proc/$id/cmdline').readAsBytesSync(),
                allowMalformed: true);
            if (t.contains('libpsiphon.so') || t.contains('libaether.so')) {
              Process.killPid(id, ProcessSignal.sigkill);
            }
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  /// خلاصه‌ی خطا همراه با چند خط آخر گزارش (برای نمایش به کاربر)
  static String summary() {
    final ts = _tsRe;
    final lines = lastLog
        .split('\n')
        .map((l) => l.replaceFirst(ts, '').trim())
        .where((l) => l.isNotEmpty)
        .toList();
    final tail = lines.length > 7 ? lines.sublist(lines.length - 7) : lines;
    var t = tail.join('\n');
    if (t.length > 520) t = t.substring(t.length - 520);
    return t.isEmpty ? lastError : '$lastError\n$t';
  }
}

/// اتصال SOCKS5 با بافر دریافتی (برای تست و پینگ و تشخیص کشور)
class _SocksConn {
  _SocksConn(this.sk) {
    sk.listen((d) {
      buf.addAll(d);
    }, onDone: () {
      closed = true;
    }, onError: (_) {
      closed = true;
    }, cancelOnError: true);
  }

  final Socket sk;
  final List<int> buf = [];
  bool closed = false;

  /// تا برقرار شدن شرط یا رسیدن زمان `end` صبر می‌کند
  Future<bool> until(bool Function() cond, DateTime end) async {
    while (DateTime.now().isBefore(end)) {
      if (cond()) return true;
      if (closed) return cond();
      await Future.delayed(const Duration(milliseconds: 25));
    }
    return cond();
  }
}
