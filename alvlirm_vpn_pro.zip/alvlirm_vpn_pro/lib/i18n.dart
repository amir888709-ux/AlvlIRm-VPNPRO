/// چندزبانه: فارسی ، انگلیسی ، عربی ، روسی ، ترکی
/// هر خط:  کلید|متن   (جای‌گذاری‌ها: {0} {1})
String lang = 'fa';

const Map<String, String> kLangNames = {
  'fa': 'فارسی',
  'en': 'English',
  'ar': 'العربية',
  'ru': 'Русский',
  'tr': 'Türkçe',
};

bool get isRtl => lang == 'fa' || lang == 'ar';

final Map<String, Map<String, String>> _tables = {
  'fa': _parse(_fa),
  'en': _parse(_en),
  'ar': _parse(_ar),
  'ru': _parse(_ru),
  'tr': _parse(_tr),
};

Map<String, String> _parse(String raw) {
  final m = <String, String>{};
  for (final line in raw.split('\n')) {
    final i = line.indexOf('|');
    if (i <= 0) continue;
    m[line.substring(0, i).trim()] = line.substring(i + 1).trim();
  }
  return m;
}

String tr(String key, [List<Object> args = const []]) {
  var s = _tables[lang]?[key] ?? _tables['en']?[key] ?? key;
  for (var i = 0; i < args.length; i++) {
    s = s.replaceAll('{$i}', '${args[i]}');
  }
  return s;
}

const _fa = r'''
disconnected|متصل نیستی
searching|در حال پیدا کردن سریع‌ترین سرور...
connecting|در حال اتصال...
connected|متصل شدی
one_tap|یک لمس تا اتصال
tap_cancel|برای لغو دوباره بزن
tested_n|{0} سرور تست شد · برای لغو دوباره بزن
auto_name|خودکار
auto_desc|هر بار بهترین سرور را خودش پیدا می‌کند
auto_conn_tag|انتخاب خودکار
total|مجموع
download|دانلود
upload|آپلود
ping_test|تست پینگ
testing|در حال تست...
ping_ms|پینگ: {0} ms
ping_failed_retry|پینگ ناموفق · تست دوباره
settings|تنظیمات
servers|سرورها
search_hint|جستجوی کشور یا نام سرور
f_all|همه
f_fav|علاقه‌مندی‌ها
f_fast|سریع
f_official|رسمی
f_sub|ساب
f_manual|دستی
sort_ping|بر اساس پینگ
sort_name|بر اساس نام
sort_country|بر اساس کشور
ping_all|تست پینگ همه‌ی سرورها
stop_test|توقف تست
add_server|افزودن سرور
from_clipboard|افزودن از کلیپ‌بورد
enter_link|وارد کردن لینک
links_hint|vless ، vmess ، trojan ، ss ، wireguard (هر لینک در یک خط)
added_n|{0} سرور اضافه شد
nothing_new|لینک معتبر جدیدی پیدا نشد
skipped_n|{0} لینک رد شد (پروتکل پشتیبانی نمی‌شود)
copy_link|کپی لینک
link_copied|کپی شد
show_qr|نمایش QR کد
delete|حذف
deleted|حذف شد
qr_hint|این QR را می‌توان با برنامه‌های دیگر اسکن کرد
copy|کپی
official_tag|رسمی
sub_tag|ساب
manual_tag|دستی
protected_note|سرورهای رسمی محافظت‌شده‌اند و فقط داخل همین برنامه قابل استفاده‌اند
subs_title|لینک‌های اشتراک (ساب)
add_sub|افزودن ساب
sub_url|آدرس لینک ساب
sub_name|نام (اختیاری)
sub_added|ساب اضافه شد · {0} سرور
update_all|به‌روزرسانی همه
update|به‌روزرسانی
updated_at|آخرین به‌روزرسانی: {0}
never|هرگز
servers_n|{0} سرور
no_subs|هنوز ساب‌ای اضافه نکردی
sub_hint|ساب‌ها خودکار به‌روز می‌شوند و سرورهای جدید خودشان اضافه می‌شوند
sub_updated_n|به‌روز شد · {0} سرور
sub_removed|ساب حذف شد
language|زبان
theme|تم
auto_connect|اتصال خودکار هنگام باز شدن برنامه
auto_connect_d|با باز کردن اپ، خودش وصل می‌شود
bypass_lan|عبور شبکه‌ی محلی از VPN
bypass_lan_d|دسترسی به روتر و دستگاه‌های خانه (از اتصال بعدی)
proxy_only|حالت پروکسی (بدون VPN سراسری)
proxy_only_d|فقط پروکسی محلی؛ برای کاربران خاص
test_url|آدرس تست پینگ
timeout|مهلت اتصال
seconds_n|{0} ثانیه
sub_auto|به‌روزرسانی خودکار ساب‌ها
hours_n|هر {0} ساعت
off|خاموش
refresh_official|به‌روزرسانی سرورهای رسمی
refreshed|به‌روز شد
refresh_failed|ارتباط با سرور به‌روزرسانی برقرار نشد
clear_fav|پاک کردن علاقه‌مندی‌ها
clear_manual|حذف همه‌ی سرورهای دستی
confirm_q|مطمئنی؟
ok|تایید
cancel|لغو
about|درباره‌ی برنامه
version|نسخه
core|هسته
creator|سازنده
telegram|تلگرام
open_failed|باز نشد؛ آیدی کپی شد
g_general|عمومی
g_connection|اتصال
g_data|داده‌ها
welcome_title|خوش آمدی 👋
welcome_body|AlvlIRm VPN؛ یک لمس، سریع‌ترین سرور. بدون تنظیمات پیچیده.
continue_btn|شروع
choose_lang|زبان را انتخاب کن
created_by|ساخته‌شده توسط
online_hint|آنلاین / کل کاربران
announce|اطلاعیه
admin_panel|پنل مدیریت
admin_pass|رمز مدیر
admin_wrong|رمز اشتباه است یا اتصال برقرار نیست
admin_servers|سرورهای رسمی
admin_hint|هر لینک در یک خط. با ذخیره، فورا برای همه‌ی کاربران اعمال می‌شود. حذف یک خط = حذف سرور برای همه.
admin_save|ذخیره و انتشار
admin_saved|منتشر شد
admin_ann|اطلاعیه برای کاربران
admin_ann_hint|متن اطلاعیه (خالی = بدون اطلاعیه)
admin_no_api|Supabase تنظیم نشده است
admin_count|{0} سرور
admin_fail|ذخیره نشد
err_no_server|هیچ سروری پیدا نشد
err_perm|اجازه‌ی VPN داده نشد
f_aether|Aether
aether_new|ساخت سرور Aether
aether_hint|همه‌ی گزینه‌های Aether را انتخاب کن؛ لینک ساخته می‌شود و به سرورهای دستی اضافه می‌شود.
aether_create|افزودن سرور
aether_copy|کپی لینک
aether_copied|لینک کپی شد
aether_bad|تنظیمات نامعتبر است
aether_reset|پاک‌کردن کلید WARP و داده‌های Aether
aether_reset_ask|کلید WARP و داده‌های Psiphon پاک شود؟ در اتصال بعدی دوباره ساخته می‌شوند.
aether_reset_done|پاک شد
err_aether|اتصال Aether ناموفق بود: {0}
admin_find|پیدا کردن و اضافه کردن سرور (تست از ایران)
admin_find_hint|سرورهای کاندید ربات را با اینترنت همین گوشی تست واقعی می‌کند، مرده‌ها را حذف و بهترین‌ها را اضافه می‌کند. قبلش VPN را خاموش کن.
admin_find_ask|{0} سرور مرده حذف و {1} سرور سالم تازه اضافه شود؟ (از {2} کاندید تست‌شده)
admin_find_none|تغییری لازم نیست
admin_find_empty|مخزن کاندید خالی است. اول ربات را در گیت‌هاب اجرا کن
admin_prune|تست از اینجا و حذف سرورهای مرده
admin_prune_hint|همه‌ی سرورهای رسمی را از اینترنت همین گوشی تست می‌کند. قبلش هر VPN دیگری را خاموش کن.
admin_prune_ask|{0} سرور از {1} پاسخ نداد. از لیست همه حذف شوند؟
admin_prune_none|همه‌ی سرورها پاسخ دادند
admin_prune_abort|بیش از ۸۰٪ پاسخ ندادند؛ اینترنت یا VPN دیگر را چک کن. چیزی حذف نشد
platform_android|اندروید
platform_win|ویندوز (کامپیوتر)
dns_start_failed|راه‌اندازی DNS ناموفق بود
err_none|هیچ سروری پاسخ نداد. اینترنت را بررسی کن
err_failed|اتصال برقرار نشد، دوباره امتحان کن
err_sel|اتصال به {0} برقرار نشد. سرور دیگری انتخاب کن یا حالت خودکار را بزن
err_core|خطا در راه‌اندازی هسته: {0}
err_sub_empty|در این لینک سرور معتبری پیدا نشد
err_url|آدرس معتبر نیست
th_system|مطابق سیستم
th_night|شب بنفش
th_amoled|آمولد
th_light|روز
th_ocean|اقیانوس
th_emerald|زمرد
th_sunset|غروب
th_rose|رز
channel|کانال تلگرام
admin_channel|لینک کانال تلگرام
admin_channel_hint|مثلا https://t.me/name یا @name (خالی = بدون دکمه)
update_available|نسخه‌ی جدید {0} آمده است
download_btn|دانلود
admin_update|آپدیت برنامه
admin_update_hint|شماره‌ی آخرین نسخه و لینک مستقیم دانلود APK. اگر نسخه‌ی کاربر قدیمی‌تر باشد، پیام آپدیت می‌بیند. خالی = بدون پیام.
f_gaming|گیمینگ
gaming_mode|حالت گیمینگ
gaming_mode_d|فقط سرورهای کشورهای نزدیک (ترکیه، امارات، ...) و انتخاب تصادفی بین کم‌پینگ‌ترین‌ها
dns|DNS
dns_default|پیش‌فرض (خود سرور)
dns_custom|آدرس دلخواه
dns_custom_hint|مثلا 1.1.1.1 8.8.8.8
dns_next|از اتصال بعدی اعمال می‌شود
donate|حمایت مالی
donate_d|اگه از برنامه راضی بودی، از پروژه حمایت کن
admin_donate|لینک حمایت مالی (دونیت)
admin_donate_hint|https://... (خالی = دکمه مخفی می‌شود)
mode_vpn|VPN
mode_dns|DNS
dns_purpose_conn|اتصال
dns_purpose_game|بازی
dns_conn_d|برای اتصال و باز شدن سایت‌ها (داخل VPN هم اعمال می‌شود)
dns_game_d|ویژه بازی‌ها (فقط در حالت DNS اعمال می‌شود)
dns_start|فعال‌سازی DNS
dns_stop|توقف DNS
dns_on|DNS فعال است
dns_off|DNS غیرفعال
dns_using|در حال استفاده: {0}
dns_how|در این حالت فقط DNS گوشی عوض می‌شود و بقیه‌ی ترافیک مستقیم می‌رود. VPN و DNS همزمان فعال نمی‌شوند.
dns_game_note|این DNSها سرویس شخص ثالث هستند و ممکن است عوض شوند یا فقط روی اینترنت ایران کار کنند.
dns_test|تست DNS
dns_test_ok|{0} ← {1} ({2} ms)
dns_test_fail|پاسخی نیامد
dns_vpn_stopped|VPN قطع شد
dns_stopped_for_vpn|DNS خاموش شد
dns_pick|یک DNS انتخاب کن
share_app|اشتراک‌گذاری برنامه
share_app_d|متن دعوت و لینک کانال کپی می‌شود
share_text|AlvlIRm VPN — اتصال با یک لمس به سریع‌ترین سرور
''';

const _en = r'''
disconnected|Not connected
searching|Finding the fastest server...
connecting|Connecting...
connected|Connected
one_tap|One tap to connect
tap_cancel|Tap again to cancel
tested_n|{0} servers tested · tap again to cancel
auto_name|Auto
auto_desc|Always picks the best server for you
auto_conn_tag|auto-selected
total|Total
download|Download
upload|Upload
ping_test|Test ping
testing|Testing...
ping_ms|Ping: {0} ms
ping_failed_retry|Ping failed · retry
settings|Settings
servers|Servers
search_hint|Search country or server name
f_all|All
f_fav|Favorites
f_fast|Fast
f_official|Official
f_sub|Sub
f_manual|Manual
sort_ping|By ping
sort_name|By name
sort_country|By country
ping_all|Test ping for all servers
stop_test|Stop test
add_server|Add server
from_clipboard|Add from clipboard
enter_link|Enter a link
links_hint|vless, vmess, trojan, ss, wireguard (one link per line)
added_n|{0} servers added
nothing_new|No new valid link found
skipped_n|{0} links skipped (protocol not supported)
copy_link|Copy link
link_copied|Copied
show_qr|Show QR code
delete|Delete
deleted|Deleted
qr_hint|You can scan this QR with other apps
copy|Copy
official_tag|Official
sub_tag|Sub
manual_tag|Manual
protected_note|Official servers are protected and can only be used inside this app
subs_title|Subscription links
add_sub|Add subscription
sub_url|Subscription URL
sub_name|Name (optional)
sub_added|Subscription added · {0} servers
update_all|Update all
update|Update
updated_at|Last update: {0}
never|never
servers_n|{0} servers
no_subs|No subscriptions yet
sub_hint|Subscriptions update automatically and new servers appear by themselves
sub_updated_n|Updated · {0} servers
sub_removed|Subscription removed
language|Language
theme|Theme
auto_connect|Auto-connect on launch
auto_connect_d|Connects as soon as the app opens
bypass_lan|Bypass local network
bypass_lan_d|Reach router and home devices (next connection)
proxy_only|Proxy mode (no system-wide VPN)
proxy_only_d|Local proxy only; for advanced users
test_url|Ping test URL
timeout|Connection timeout
seconds_n|{0} seconds
sub_auto|Auto-update subscriptions
hours_n|Every {0} hours
off|Off
refresh_official|Update official servers
refreshed|Updated
refresh_failed|Could not reach the update service
clear_fav|Clear favorites
clear_manual|Delete all manual servers
confirm_q|Are you sure?
ok|OK
cancel|Cancel
about|About
version|Version
core|Core
creator|Creator
telegram|Telegram
open_failed|Could not open; ID copied
g_general|General
g_connection|Connection
g_data|Data
welcome_title|Welcome 👋
welcome_body|AlvlIRm VPN: one tap, fastest server. No complicated settings.
continue_btn|Start
choose_lang|Choose your language
created_by|Created by
online_hint|Online / total users
announce|Announcement
admin_panel|Admin panel
admin_pass|Admin password
admin_wrong|Wrong password or no connection
admin_servers|Official servers
admin_hint|One link per line. Saving applies instantly for all users. Removing a line removes that server for everyone.
admin_save|Save and publish
admin_saved|Published
admin_ann|Announcement for users
admin_ann_hint|Announcement text (empty = none)
admin_no_api|Supabase is not configured
admin_count|{0} servers
admin_fail|Could not save
err_no_server|No server found
err_perm|VPN permission was not granted
f_aether|Aether
aether_new|Build Aether server
aether_hint|Pick the Aether options; the link is built and added to your manual servers.
aether_create|Add server
aether_copy|Copy link
aether_copied|Link copied
aether_bad|Invalid settings
aether_reset|Reset WARP key and Aether data
aether_reset_ask|Delete the WARP key and Psiphon data? They are recreated on the next connection.
aether_reset_done|Done
err_aether|Aether connection failed: {0}
admin_find|Find and add servers (test from Iran)
admin_find_hint|Really tests the bot candidates over this device internet, removes dead servers and adds the best ones. Turn off VPN first.
admin_find_ask|Remove {0} dead and add {1} working servers? ({2} candidates tested)
admin_find_none|No change needed
admin_find_empty|Candidate pool is empty. Run the bot on GitHub first
admin_prune|Test from here and remove dead servers
admin_prune_hint|Tests every official server over this device internet. Turn off any other VPN first.
admin_prune_ask|{0} of {1} servers did not respond. Remove them for everyone?
admin_prune_none|All servers responded
admin_prune_abort|Over 80% did not respond; check your internet or other VPN. Nothing removed
platform_android|Android
platform_win|Windows (PC)
dns_start_failed|DNS could not start
err_none|No server responded. Check your internet
err_failed|Could not connect, try again
err_sel|Could not connect to {0}. Pick another server or use Auto
err_core|Core start-up error: {0}
err_sub_empty|No valid server found in this link
err_url|Invalid URL
th_system|System
th_night|Purple night
th_amoled|AMOLED
th_light|Day
th_ocean|Ocean
th_emerald|Emerald
th_sunset|Sunset
th_rose|Rose
channel|Telegram channel
admin_channel|Telegram channel link
admin_channel_hint|e.g. https://t.me/name or @name (empty = no button)
update_available|New version {0} is available
download_btn|Download
admin_update|App update
admin_update_hint|Latest version number and a direct APK download link. Users with an older version see an update message. Empty = no message.
f_gaming|Gaming
gaming_mode|Gaming mode
gaming_mode_d|Nearby countries only (Turkey, UAE, ...) with a random pick among the lowest-ping servers
dns|DNS
dns_default|Default (server's own)
dns_custom|Custom address
dns_custom_hint|e.g. 1.1.1.1 8.8.8.8
dns_next|Applies from the next connection
donate|Support us
donate_d|If you like the app, support the project
admin_donate|Donate / support link
admin_donate_hint|https://... (empty = button hidden)
mode_vpn|VPN
mode_dns|DNS
dns_purpose_conn|Connection
dns_purpose_game|Gaming
dns_conn_d|For browsing and connection (also applied inside the VPN)
dns_game_d|For games (applied only in DNS mode)
dns_start|Activate DNS
dns_stop|Stop DNS
dns_on|DNS is active
dns_off|DNS is off
dns_using|Using: {0}
dns_how|This mode only changes the phone's DNS; all other traffic goes direct. VPN and DNS cannot run at the same time.
dns_game_note|These DNS servers are third-party services; they may change or work only on Iranian internet.
dns_test|Test DNS
dns_test_ok|{0} -> {1} ({2} ms)
dns_test_fail|No answer
dns_vpn_stopped|VPN was disconnected
dns_stopped_for_vpn|DNS was turned off
dns_pick|Pick a DNS
share_app|Share the app
share_app_d|Copies an invite text and the channel link
share_text|AlvlIRm VPN - one tap to the fastest server
''';

const _ar = r'''
disconnected|غير متصل
searching|جارٍ البحث عن أسرع خادم...
connecting|جارٍ الاتصال...
connected|تم الاتصال
one_tap|لمسة واحدة للاتصال
tap_cancel|اضغط مرة أخرى للإلغاء
tested_n|تم اختبار {0} خادم · اضغط للإلغاء
auto_name|تلقائي
auto_desc|يختار أفضل خادم دائماً
auto_conn_tag|اختيار تلقائي
total|الإجمالي
download|تنزيل
upload|رفع
ping_test|اختبار الاستجابة
testing|جارٍ الاختبار...
ping_ms|الاستجابة: {0} ms
ping_failed_retry|فشل الاختبار · أعد المحاولة
settings|الإعدادات
servers|الخوادم
search_hint|ابحث عن دولة أو خادم
f_all|الكل
f_fav|المفضلة
f_fast|سريع
f_official|رسمي
f_sub|اشتراك
f_manual|يدوي
sort_ping|حسب الاستجابة
sort_name|حسب الاسم
sort_country|حسب الدولة
ping_all|اختبار كل الخوادم
stop_test|إيقاف الاختبار
add_server|إضافة خادم
from_clipboard|إضافة من الحافظة
enter_link|إدخال رابط
links_hint|vless, vmess, trojan, ss, wireguard (رابط في كل سطر)
added_n|تمت إضافة {0} خادم
nothing_new|لا يوجد رابط صالح جديد
skipped_n|تم تخطي {0} رابط (بروتوكول غير مدعوم)
copy_link|نسخ الرابط
link_copied|تم النسخ
show_qr|عرض رمز QR
delete|حذف
deleted|تم الحذف
qr_hint|يمكن مسح هذا الرمز بتطبيقات أخرى
copy|نسخ
official_tag|رسمي
sub_tag|اشتراك
manual_tag|يدوي
protected_note|الخوادم الرسمية محمية ويمكن استخدامها داخل هذا التطبيق فقط
subs_title|روابط الاشتراك
add_sub|إضافة اشتراك
sub_url|رابط الاشتراك
sub_name|الاسم (اختياري)
sub_added|تمت إضافة الاشتراك · {0} خادم
update_all|تحديث الكل
update|تحديث
updated_at|آخر تحديث: {0}
never|أبداً
servers_n|{0} خادم
no_subs|لا توجد اشتراكات بعد
sub_hint|تتحدث الاشتراكات تلقائياً وتظهر الخوادم الجديدة وحدها
sub_updated_n|تم التحديث · {0} خادم
sub_removed|تم حذف الاشتراك
language|اللغة
theme|السمة
auto_connect|اتصال تلقائي عند الفتح
auto_connect_d|يتصل بمجرد فتح التطبيق
bypass_lan|تجاوز الشبكة المحلية
bypass_lan_d|الوصول إلى الراوتر وأجهزة المنزل (من الاتصال التالي)
proxy_only|وضع الوكيل (بدون VPN شامل)
proxy_only_d|وكيل محلي فقط؛ للمستخدمين المتقدمين
test_url|رابط اختبار الاستجابة
timeout|مهلة الاتصال
seconds_n|{0} ثانية
sub_auto|تحديث الاشتراكات تلقائياً
hours_n|كل {0} ساعة
off|إيقاف
refresh_official|تحديث الخوادم الرسمية
refreshed|تم التحديث
refresh_failed|تعذر الوصول إلى خدمة التحديث
clear_fav|مسح المفضلة
clear_manual|حذف كل الخوادم اليدوية
confirm_q|هل أنت متأكد؟
ok|موافق
cancel|إلغاء
about|حول التطبيق
version|الإصدار
core|النواة
creator|المطوّر
telegram|تيليجرام
open_failed|تعذر الفتح؛ تم نسخ المعرّف
g_general|عام
g_connection|الاتصال
g_data|البيانات
welcome_title|أهلاً بك 👋
welcome_body|AlvlIRm VPN: لمسة واحدة وأسرع خادم. بلا إعدادات معقدة.
continue_btn|ابدأ
choose_lang|اختر اللغة
created_by|تطوير
online_hint|المتصلون / إجمالي المستخدمين
announce|إعلان
admin_panel|لوحة الإدارة
admin_pass|كلمة مرور المدير
admin_wrong|كلمة المرور خاطئة أو لا يوجد اتصال
admin_servers|الخوادم الرسمية
admin_hint|رابط في كل سطر. الحفظ يُطبّق فوراً على كل المستخدمين. حذف سطر = حذف الخادم للجميع.
admin_save|حفظ ونشر
admin_saved|تم النشر
admin_ann|إعلان للمستخدمين
admin_ann_hint|نص الإعلان (فارغ = بلا إعلان)
admin_no_api|لم يتم إعداد Supabase
admin_count|{0} خادم
admin_fail|تعذر الحفظ
err_no_server|لم يتم العثور على خادم
err_perm|لم يتم منح إذن VPN
f_aether|Aether
aether_new|إنشاء خادم Aether
aether_hint|اختر خيارات Aether؛ يتم إنشاء الرابط وإضافته إلى الخوادم اليدوية.
aether_create|إضافة الخادم
aether_copy|نسخ الرابط
aether_copied|تم نسخ الرابط
aether_bad|إعدادات غير صالحة
aether_reset|مسح مفتاح WARP وبيانات Aether
aether_reset_ask|حذف مفتاح WARP وبيانات Psiphon؟ سيتم إنشاؤها من جديد عند الاتصال التالي.
aether_reset_done|تم
err_aether|فشل اتصال Aether: {0}
admin_find|ابحث وأضف خوادم (اختبار من إيران)
admin_find_hint|يختبر خوادم البوت المرشحة فعلياً عبر إنترنت هذا الجهاز ويحذف الميتة ويضيف الأفضل. أوقف VPN أولاً.
admin_find_ask|حذف {0} ميتة وإضافة {1} تعمل؟ (اختُبر {2} مرشحاً)
admin_find_none|لا حاجة لتغيير
admin_find_empty|مخزن المرشحين فارغ. شغّل البوت على GitHub أولاً
admin_prune|اختبر من هنا واحذف الخوادم الميتة
admin_prune_hint|يختبر كل الخوادم الرسمية من إنترنت هذا الجهاز. أوقف أي VPN آخر أولاً.
admin_prune_ask|{0} من {1} خادم لم يستجب. حذفها للجميع؟
admin_prune_none|استجابت كل الخوادم
admin_prune_abort|أكثر من 80٪ لم تستجب؛ تحقق من الإنترنت أو VPN آخر. لم يُحذف شيء
platform_android|أندرويد
platform_win|ويندوز (كمبيوتر)
dns_start_failed|تعذر تشغيل DNS
err_none|لا يوجد خادم يستجيب. تحقق من الإنترنت
err_failed|فشل الاتصال، حاول مجدداً
err_sel|تعذر الاتصال بـ {0}. اختر خادماً آخر أو الوضع التلقائي
err_core|خطأ في تشغيل النواة: {0}
err_sub_empty|لم يتم العثور على خادم صالح في هذا الرابط
err_url|رابط غير صالح
th_system|حسب النظام
th_night|ليل بنفسجي
th_amoled|أموليد
th_light|نهاري
th_ocean|محيط
th_emerald|زمردي
th_sunset|غروب
th_rose|وردي
channel|قناة تيليجرام
admin_channel|رابط قناة تيليجرام
admin_channel_hint|مثال: https://t.me/name أو @name (فارغ = بلا زر)
update_available|يتوفر إصدار جديد {0}
download_btn|تنزيل
admin_update|تحديث التطبيق
admin_update_hint|رقم آخر إصدار ورابط تنزيل APK مباشر. المستخدم صاحب الإصدار الأقدم يرى رسالة التحديث. فارغ = بلا رسالة.
f_gaming|ألعاب
gaming_mode|وضع الألعاب
gaming_mode_d|خوادم الدول القريبة فقط (تركيا، الإمارات، ...) واختيار عشوائي بين الأقل استجابة
dns|DNS
dns_default|افتراضي (خاص بالخادم)
dns_custom|عنوان مخصص
dns_custom_hint|مثال: 1.1.1.1 8.8.8.8
dns_next|يُطبّق من الاتصال التالي
donate|ادعمنا
donate_d|إذا أعجبك التطبيق، ادعم المشروع
admin_donate|رابط الدعم / التبرع
admin_donate_hint|https://... (فارغ = يُخفى الزر)
mode_vpn|VPN
mode_dns|DNS
dns_purpose_conn|الاتصال
dns_purpose_game|الألعاب
dns_conn_d|للتصفح والاتصال (يُطبق داخل VPN أيضًا)
dns_game_d|للألعاب (يُطبق في وضع DNS فقط)
dns_start|تفعيل DNS
dns_stop|إيقاف DNS
dns_on|DNS مفعّل
dns_off|DNS متوقف
dns_using|قيد الاستخدام: {0}
dns_how|هذا الوضع يغيّر DNS الهاتف فقط وباقي الحركة تذهب مباشرة. لا يعمل VPN وDNS معًا.
dns_game_note|هذه الخوادم خدمات طرف ثالث وقد تتغير أو تعمل فقط على إنترنت إيران.
dns_test|اختبار DNS
dns_test_ok|{0} ← {1} ({2} ms)
dns_test_fail|لا توجد استجابة
dns_vpn_stopped|تم قطع VPN
dns_stopped_for_vpn|تم إيقاف DNS
dns_pick|اختر DNS
share_app|مشاركة التطبيق
share_app_d|ينسخ نص الدعوة ورابط القناة
share_text|AlvlIRm VPN — اتصال بلمسة واحدة بأسرع خادم
''';

const _ru = r'''
disconnected|Не подключено
searching|Ищем самый быстрый сервер...
connecting|Подключение...
connected|Подключено
one_tap|Одно касание для подключения
tap_cancel|Нажмите ещё раз для отмены
tested_n|Проверено серверов: {0} · нажмите для отмены
auto_name|Авто
auto_desc|Всегда выбирает лучший сервер
auto_conn_tag|автовыбор
total|Всего
download|Загрузка
upload|Отдача
ping_test|Проверить пинг
testing|Проверка...
ping_ms|Пинг: {0} мс
ping_failed_retry|Пинг не удался · повторить
settings|Настройки
servers|Серверы
search_hint|Поиск страны или сервера
f_all|Все
f_fav|Избранное
f_fast|Быстрые
f_official|Официальные
f_sub|Подписка
f_manual|Ручные
sort_ping|По пингу
sort_name|По имени
sort_country|По стране
ping_all|Проверить пинг всех серверов
stop_test|Остановить
add_server|Добавить сервер
from_clipboard|Добавить из буфера
enter_link|Ввести ссылку
links_hint|vless, vmess, trojan, ss, wireguard (по одной ссылке в строке)
added_n|Добавлено серверов: {0}
nothing_new|Новых корректных ссылок нет
skipped_n|Пропущено ссылок: {0} (протокол не поддерживается)
copy_link|Копировать ссылку
link_copied|Скопировано
show_qr|Показать QR-код
delete|Удалить
deleted|Удалено
qr_hint|Этот QR можно отсканировать в других приложениях
copy|Копировать
official_tag|Офиц.
sub_tag|Подписка
manual_tag|Ручной
protected_note|Официальные серверы защищены и работают только внутри этого приложения
subs_title|Ссылки подписки
add_sub|Добавить подписку
sub_url|URL подписки
sub_name|Название (необязательно)
sub_added|Подписка добавлена · серверов: {0}
update_all|Обновить все
update|Обновить
updated_at|Обновлено: {0}
never|никогда
servers_n|Серверов: {0}
no_subs|Подписок пока нет
sub_hint|Подписки обновляются автоматически, новые серверы появляются сами
sub_updated_n|Обновлено · серверов: {0}
sub_removed|Подписка удалена
language|Язык
theme|Тема
auto_connect|Автоподключение при запуске
auto_connect_d|Подключается сразу после открытия
bypass_lan|Локальная сеть мимо VPN
bypass_lan_d|Доступ к роутеру и домашним устройствам (со следующего подключения)
proxy_only|Режим прокси (без общего VPN)
proxy_only_d|Только локальный прокси; для опытных
test_url|Адрес проверки пинга
timeout|Таймаут подключения
seconds_n|{0} сек.
sub_auto|Автообновление подписок
hours_n|Каждые {0} ч.
off|Выкл.
refresh_official|Обновить официальные серверы
refreshed|Обновлено
refresh_failed|Нет связи со службой обновления
clear_fav|Очистить избранное
clear_manual|Удалить все ручные серверы
confirm_q|Вы уверены?
ok|ОК
cancel|Отмена
about|О приложении
version|Версия
core|Ядро
creator|Автор
telegram|Telegram
open_failed|Не удалось открыть; ID скопирован
g_general|Общие
g_connection|Подключение
g_data|Данные
welcome_title|Добро пожаловать 👋
welcome_body|AlvlIRm VPN: одно касание и самый быстрый сервер. Без сложных настроек.
continue_btn|Начать
choose_lang|Выберите язык
created_by|Создатель
online_hint|Онлайн / всего пользователей
announce|Объявление
admin_panel|Панель администратора
admin_pass|Пароль администратора
admin_wrong|Неверный пароль или нет связи
admin_servers|Официальные серверы
admin_hint|Одна ссылка в строке. Сохранение сразу применяется для всех. Удалили строку — сервер удалён у всех.
admin_save|Сохранить и опубликовать
admin_saved|Опубликовано
admin_ann|Объявление для пользователей
admin_ann_hint|Текст объявления (пусто = нет)
admin_no_api|Supabase не настроен
admin_count|Серверов: {0}
admin_fail|Не удалось сохранить
err_no_server|Серверы не найдены
err_perm|Разрешение VPN не выдано
f_aether|Aether
aether_new|Создать сервер Aether
aether_hint|Выберите параметры Aether: ссылка создаётся и добавляется в ваши серверы.
aether_create|Добавить сервер
aether_copy|Копировать ссылку
aether_copied|Ссылка скопирована
aether_bad|Недопустимые настройки
aether_reset|Сбросить ключ WARP и данные Aether
aether_reset_ask|Удалить ключ WARP и данные Psiphon? При следующем подключении они создадутся заново.
aether_reset_done|Готово
err_aether|Не удалось подключиться через Aether: {0}
admin_find|Найти и добавить серверы (тест из Ирана)
admin_find_hint|Реально проверяет кандидатов бота через интернет этого устройства, удаляет мёртвые и добавляет лучшие. Сначала отключите VPN.
admin_find_ask|Удалить {0} мёртвых и добавить {1} рабочих? (проверено {2} кандидатов)
admin_find_none|Изменений не требуется
admin_find_empty|Пул кандидатов пуст. Сначала запустите бота на GitHub
admin_prune|Проверить отсюда и удалить мёртвые
admin_prune_hint|Проверяет все официальные серверы через интернет этого устройства. Сначала отключите другой VPN.
admin_prune_ask|{0} из {1} серверов не ответили. Удалить у всех?
admin_prune_none|Все серверы ответили
admin_prune_abort|Более 80% не ответили; проверьте интернет или другой VPN. Ничего не удалено
platform_android|Android
platform_win|Windows (ПК)
dns_start_failed|Не удалось запустить DNS
err_none|Ни один сервер не ответил. Проверьте интернет
err_failed|Не удалось подключиться, попробуйте снова
err_sel|Не удалось подключиться к {0}. Выберите другой сервер или Авто
err_core|Ошибка запуска ядра: {0}
err_sub_empty|В этой ссылке нет подходящих серверов
err_url|Неверный адрес
th_system|Системная
th_night|Фиолетовая ночь
th_amoled|AMOLED
th_light|День
th_ocean|Океан
th_emerald|Изумруд
th_sunset|Закат
th_rose|Роза
channel|Telegram-канал
admin_channel|Ссылка на Telegram-канал
admin_channel_hint|Например: https://t.me/name или @name (пусто = без кнопки)
update_available|Доступна новая версия {0}
download_btn|Скачать
admin_update|Обновление приложения
admin_update_hint|Номер последней версии и прямая ссылка на APK. Пользователи старой версии увидят сообщение. Пусто = без сообщения.
f_gaming|Игры
gaming_mode|Игровой режим
gaming_mode_d|Только ближние страны (Турция, ОАЭ, ...) и случайный выбор среди серверов с минимальным пингом
dns|DNS
dns_default|По умолчанию (сервера)
dns_custom|Свой адрес
dns_custom_hint|напр. 1.1.1.1 8.8.8.8
dns_next|Применится при следующем подключении
donate|Поддержать
donate_d|Если приложение нравится, поддержите проект
admin_donate|Ссылка для поддержки / доната
admin_donate_hint|https://... (пусто = кнопка скрыта)
mode_vpn|VPN
mode_dns|DNS
dns_purpose_conn|Соединение
dns_purpose_game|Игры
dns_conn_d|Для сайтов и соединения (применяется и внутри VPN)
dns_game_d|Для игр (только в режиме DNS)
dns_start|Включить DNS
dns_stop|Остановить DNS
dns_on|DNS включён
dns_off|DNS выключен
dns_using|Используется: {0}
dns_how|Этот режим меняет только DNS телефона, остальной трафик идёт напрямую. VPN и DNS одновременно не работают.
dns_game_note|Эти DNS — сторонние сервисы; они могут измениться или работать только в иранском интернете.
dns_test|Проверить DNS
dns_test_ok|{0} → {1} ({2} ms)
dns_test_fail|Нет ответа
dns_vpn_stopped|VPN отключён
dns_stopped_for_vpn|DNS выключен
dns_pick|Выберите DNS
share_app|Поделиться приложением
share_app_d|Копирует текст приглашения и ссылку на канал
share_text|AlvlIRm VPN — одно касание до быстрейшего сервера
''';

const _tr = r'''
disconnected|Bağlı değil
searching|En hızlı sunucu aranıyor...
connecting|Bağlanıyor...
connected|Bağlandı
one_tap|Bağlanmak için tek dokunuş
tap_cancel|İptal için tekrar dokun
tested_n|{0} sunucu test edildi · iptal için dokun
auto_name|Otomatik
auto_desc|Her zaman en iyi sunucuyu seçer
auto_conn_tag|otomatik seçim
total|Toplam
download|İndirme
upload|Yükleme
ping_test|Ping testi
testing|Test ediliyor...
ping_ms|Ping: {0} ms
ping_failed_retry|Ping başarısız · tekrar dene
settings|Ayarlar
servers|Sunucular
search_hint|Ülke veya sunucu ara
f_all|Tümü
f_fav|Favoriler
f_fast|Hızlı
f_official|Resmi
f_sub|Abonelik
f_manual|Manuel
sort_ping|Pinge göre
sort_name|Ada göre
sort_country|Ülkeye göre
ping_all|Tüm sunucuların pingini test et
stop_test|Testi durdur
add_server|Sunucu ekle
from_clipboard|Panodan ekle
enter_link|Bağlantı gir
links_hint|vless, vmess, trojan, ss, wireguard (satır başına bir bağlantı)
added_n|{0} sunucu eklendi
nothing_new|Yeni geçerli bağlantı bulunamadı
skipped_n|{0} bağlantı atlandı (protokol desteklenmiyor)
copy_link|Bağlantıyı kopyala
link_copied|Kopyalandı
show_qr|QR kodu göster
delete|Sil
deleted|Silindi
qr_hint|Bu QR başka uygulamalarla taranabilir
copy|Kopyala
official_tag|Resmi
sub_tag|Abonelik
manual_tag|Manuel
protected_note|Resmi sunucular korumalıdır ve yalnızca bu uygulamada kullanılabilir
subs_title|Abonelik bağlantıları
add_sub|Abonelik ekle
sub_url|Abonelik adresi
sub_name|Ad (isteğe bağlı)
sub_added|Abonelik eklendi · {0} sunucu
update_all|Hepsini güncelle
update|Güncelle
updated_at|Son güncelleme: {0}
never|hiç
servers_n|{0} sunucu
no_subs|Henüz abonelik yok
sub_hint|Abonelikler otomatik güncellenir, yeni sunucular kendiliğinden eklenir
sub_updated_n|Güncellendi · {0} sunucu
sub_removed|Abonelik silindi
language|Dil
theme|Tema
auto_connect|Açılışta otomatik bağlan
auto_connect_d|Uygulama açılır açılmaz bağlanır
bypass_lan|Yerel ağı VPN dışında tut
bypass_lan_d|Router ve ev cihazlarına erişim (sonraki bağlantıda)
proxy_only|Proxy modu (sistem geneli VPN yok)
proxy_only_d|Yalnızca yerel proxy; ileri düzey
test_url|Ping test adresi
timeout|Bağlantı zaman aşımı
seconds_n|{0} saniye
sub_auto|Abonelikleri otomatik güncelle
hours_n|Her {0} saatte
off|Kapalı
refresh_official|Resmi sunucuları güncelle
refreshed|Güncellendi
refresh_failed|Güncelleme servisine ulaşılamadı
clear_fav|Favorileri temizle
clear_manual|Tüm manuel sunucuları sil
confirm_q|Emin misin?
ok|Tamam
cancel|İptal
about|Hakkında
version|Sürüm
core|Çekirdek
creator|Geliştirici
telegram|Telegram
open_failed|Açılamadı; kimlik kopyalandı
g_general|Genel
g_connection|Bağlantı
g_data|Veri
welcome_title|Hoş geldin 👋
welcome_body|AlvlIRm VPN: tek dokunuş, en hızlı sunucu. Karmaşık ayar yok.
continue_btn|Başla
choose_lang|Dilini seç
created_by|Geliştiren
online_hint|Çevrimiçi / toplam kullanıcı
announce|Duyuru
admin_panel|Yönetici paneli
admin_pass|Yönetici şifresi
admin_wrong|Şifre yanlış veya bağlantı yok
admin_servers|Resmi sunucular
admin_hint|Satır başına bir bağlantı. Kaydedince herkese anında uygulanır. Bir satırı silmek sunucuyu herkesten siler.
admin_save|Kaydet ve yayınla
admin_saved|Yayınlandı
admin_ann|Kullanıcılara duyuru
admin_ann_hint|Duyuru metni (boş = yok)
admin_no_api|Supabase ayarlanmamış
admin_count|{0} sunucu
admin_fail|Kaydedilemedi
err_no_server|Sunucu bulunamadı
err_perm|VPN izni verilmedi
f_aether|Aether
aether_new|Aether sunucusu oluştur
aether_hint|Aether seçeneklerini seç; bağlantı oluşturulur ve elle eklenen sunuculara eklenir.
aether_create|Sunucu ekle
aether_copy|Bağlantıyı kopyala
aether_copied|Bağlantı kopyalandı
aether_bad|Geçersiz ayarlar
aether_reset|WARP anahtarını ve Aether verilerini sıfırla
aether_reset_ask|WARP anahtarı ve Psiphon verileri silinsin mi? Sonraki bağlantıda yeniden oluşturulur.
aether_reset_done|Tamam
err_aether|Aether baglantisi basarisiz: {0}
admin_find|Sunucu bul ve ekle (Iran tan test)
admin_find_hint|Bot adaylarini bu cihazin internetiyle gercekten test eder, olenleri siler en iyileri ekler. Once VPN kapat.
admin_find_ask|{0} olu sunucu silinip {1} calisan eklensin mi? ({2} aday test edildi)
admin_find_none|Degisiklik gerekmiyor
admin_find_empty|Aday havuzu bos. Once GitHub da botu calistir
admin_prune|Buradan test et ve olu sunuculari sil
admin_prune_hint|Tum resmi sunuculari bu cihazin internetinden test eder. Once diger VPN kapat.
admin_prune_ask|{1} sunucudan {0} tanesi yanit vermedi. Herkesten silinsin mi?
admin_prune_none|Tum sunucular yanit verdi
admin_prune_abort|Yuzde 80 ustu yanit vermedi; interneti veya diger VPN kontrol et. Hicbir sey silinmedi
platform_android|Android
platform_win|Windows (PC)
dns_start_failed|DNS başlatılamadı
err_none|Hiçbir sunucu yanıt vermedi. İnterneti kontrol et
err_failed|Bağlanılamadı, tekrar dene
err_sel|{0} sunucusuna bağlanılamadı. Başka sunucu seç veya Otomatik kullan
err_core|Çekirdek başlatma hatası: {0}
err_sub_empty|Bu bağlantıda geçerli sunucu bulunamadı
err_url|Geçersiz adres
th_system|Sistem
th_night|Mor gece
th_amoled|AMOLED
th_light|Gündüz
th_ocean|Okyanus
th_emerald|Zümrüt
th_sunset|Gün batımı
th_rose|Gül
channel|Telegram kanalı
admin_channel|Telegram kanal bağlantısı
admin_channel_hint|Örn: https://t.me/name veya @name (boş = düğme yok)
update_available|Yeni sürüm {0} mevcut
download_btn|İndir
admin_update|Uygulama güncellemesi
admin_update_hint|Son sürüm numarası ve doğrudan APK indirme bağlantısı. Eski sürüm kullananlar güncelleme mesajı görür. Boş = mesaj yok.
f_gaming|Oyun
gaming_mode|Oyun modu
gaming_mode_d|Yalnızca yakın ülkeler (Türkiye, BAE, ...) ve en düşük ping'liler arasından rastgele seçim
dns|DNS
dns_default|Varsayılan (sunucunun)
dns_custom|Özel adres
dns_custom_hint|örn. 1.1.1.1 8.8.8.8
dns_next|Sonraki bağlantıda uygulanır
donate|Destek ol
donate_d|Uygulamayı beğendiysen projeye destek ol
admin_donate|Bağış / destek bağlantısı
admin_donate_hint|https://... (boş = düğme gizlenir)
mode_vpn|VPN
mode_dns|DNS
dns_purpose_conn|Bağlantı
dns_purpose_game|Oyun
dns_conn_d|Gezinme ve bağlantı için (VPN içinde de uygulanır)
dns_game_d|Oyunlar için (yalnızca DNS modunda)
dns_start|DNS'i etkinleştir
dns_stop|DNS'i durdur
dns_on|DNS etkin
dns_off|DNS kapalı
dns_using|Kullanılan: {0}
dns_how|Bu mod yalnızca telefonun DNS'ini değiştirir; diğer trafik doğrudan gider. VPN ve DNS aynı anda çalışmaz.
dns_game_note|Bu DNS'ler üçüncü taraf hizmetlerdir; değişebilir veya yalnızca İran internetinde çalışabilir.
dns_test|DNS testi
dns_test_ok|{0} → {1} ({2} ms)
dns_test_fail|Yanıt yok
dns_vpn_stopped|VPN bağlantısı kesildi
dns_stopped_for_vpn|DNS kapatıldı
dns_pick|Bir DNS seç
share_app|Uygulamayı paylaş
share_app_d|Davet metnini ve kanal bağlantısını kopyalar
share_text|AlvlIRm VPN — tek dokunuşla en hızlı sunucu
''';
