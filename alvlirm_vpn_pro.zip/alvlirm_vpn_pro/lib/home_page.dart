import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'admin_page.dart';
import 'i18n.dart';
import 'server.dart';
import 'servers_page.dart';
import 'settings_page.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.controller});
  final VpnController controller;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat();

  int _taps = 0;
  DateTime _lastTap = DateTime.fromMillisecondsSinceEpoch(0);

  VpnController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (c.autoConnectOnLaunch && c.phase == VpnPhase.idle) c.toggle();
    });
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  void _brandTap() {
    final now = DateTime.now();
    if (now.difference(_lastTap).inMilliseconds > 1500) _taps = 0;
    _lastTap = now;
    _taps++;
    if (_taps >= 7) {
      _taps = 0;
      openAdmin(context, c);
    }
  }

  String get _title {
    switch (c.phase) {
      case VpnPhase.idle:
        return tr('disconnected');
      case VpnPhase.searching:
        return tr('searching');
      case VpnPhase.connecting:
        return tr('connecting');
      case VpnPhase.connected:
        return tr('connected');
      case VpnPhase.failed:
        return c.msgKey == null ? '!' : tr(c.msgKey!, c.msgArgs);
    }
  }

  String get _subtitle {
    switch (c.phase) {
      case VpnPhase.connected:
        return c.duration;
      case VpnPhase.searching:
        return tr('tested_n', [c.pingDone]);
      case VpnPhase.connecting:
        return tr('tap_cancel');
      default:
        return tr('one_tap');
    }
  }

  Color get _accent {
    switch (c.phase) {
      case VpnPhase.connected:
        return AppColors.ok;
      case VpnPhase.failed:
        return AppColors.bad;
      default:
        return AppColors.purple;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -0.35),
              radius: 1.1,
              colors: [AppColors.glow, AppColors.bg],
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, box) => SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: box.maxHeight),
                  child: IntrinsicHeight(
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _header(),
                        if (c.showAnnouncement) _announcement(),
                        const Spacer(flex: 2),
                        _connectButton(),
                        const SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Text(
                            _title,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: AppColors.text,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _subtitle,
                          style: TextStyle(
                            color: AppColors.muted,
                            fontSize: c.phase == VpnPhase.connected ? 26 : 13,
                            fontWeight: FontWeight.w300,
                            letterSpacing: 1.2,
                          ),
                        ),
                        if (c.phase == VpnPhase.connected) ...[
                          const SizedBox(height: 8),
                          _pingButton(),
                        ],
                        const Spacer(flex: 2),
                        _serverCard(),
                        const SizedBox(height: 12),
                        _statsRow(),
                        const SizedBox(height: 8),
                        if (c.phase == VpnPhase.connected)
                          Text(
                            '${tr('total')}  ↓ ${fmtBytes(c.download)}   ↑ ${fmtBytes(c.upload)}',
                            textDirection: TextDirection.ltr,
                            style: TextStyle(
                              color: AppColors.muted,
                              fontSize: 12,
                            ),
                          ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          SizedBox(width: 92, child: Align(alignment: AlignmentDirectional.centerStart, child: _onlineChip())),
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _brandTap,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: LinearGradient(
                        colors: [AppColors.purple, AppColors.purpleDeep],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.purple.withValues(alpha: 0.5),
                          blurRadius: 16,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.shield_rounded,
                        color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'AlvlIRm VPN',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            width: 92,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  tooltip: tr('settings'),
                  icon: Icon(Icons.tune_rounded, color: AppColors.purpleLight),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SettingsPage(controller: c),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// گوشه‌ی صفحه: تعداد آنلاین / کل کاربران
  Widget _onlineChip() {
    if (c.online == null || c.totalUsers == null) return const SizedBox.shrink();
    return Tooltip(
      message: tr('online_hint'),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.purple.withValues(alpha: 0.25)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.circle, size: 8, color: AppColors.ok),
            const SizedBox(width: 5),
            Text(
              '${c.online} / ${c.totalUsers}',
              textDirection: TextDirection.ltr,
              style: TextStyle(
                color: AppColors.text,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _announcement() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.fromLTRB(14, 10, 4, 10),
      decoration: BoxDecoration(
        color: AppColors.purple.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.purple.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          Icon(Icons.campaign_rounded, color: AppColors.purpleLight),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              c.announcement,
              style: TextStyle(color: AppColors.text, fontSize: 13),
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: Icon(Icons.close_rounded, color: AppColors.muted, size: 18),
            onPressed: c.dismissAnnouncement,
          ),
        ],
      ),
    );
  }

  Widget _connectButton() {
    final busy =
        c.phase == VpnPhase.searching || c.phase == VpnPhase.connecting;
    return GestureDetector(
      onTap: c.toggle,
      child: SizedBox(
        width: 260,
        height: 260,
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (context, _) {
            return CustomPaint(
              painter: _RingsPainter(
                t: _pulse.value,
                color: _accent,
                light: AppColors.purpleLight,
                active: c.phase != VpnPhase.idle,
                busy: busy,
              ),
              child: Center(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 400),
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: c.phase == VpnPhase.connected
                          ? [const Color(0xFF2BE29A), const Color(0xFF0E7D5A)]
                          : [AppColors.purpleLight, AppColors.purpleDeep],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _accent.withValues(alpha: 0.55),
                        blurRadius: 40,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: busy
                      ? const Padding(
                          padding: EdgeInsets.all(46),
                          child: CircularProgressIndicator(
                            strokeWidth: 3,
                            color: Colors.white,
                          ),
                        )
                      : Icon(
                          Icons.power_settings_new_rounded,
                          size: 66,
                          color: Colors.white.withValues(alpha: 0.95),
                        ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _pingButton() {
    final p = c.connectedPing;
    final label = c.testingPing
        ? tr('testing')
        : (p == null
            ? tr('ping_test')
            : (p > 0 ? tr('ping_ms', [p]) : tr('ping_failed_retry')));
    return OutlinedButton.icon(
      onPressed: c.testingPing ? null : c.testConnectedPing,
      icon: Icon(Icons.speed_rounded, size: 18, color: pingColor(p)),
      label: Text(label, style: TextStyle(color: AppColors.text)),
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: AppColors.purple.withValues(alpha: 0.5)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget _serverCard() {
    final live = c.phase == VpnPhase.connected ||
        c.phase == VpnPhase.connecting ||
        c.phase == VpnPhase.searching && c.selected != null;
    final VpnServer? s = live && c.current != null ? c.current : c.selected;
    final auto = c.selectedId == null;

    String title;
    String sub;
    String flag;
    if (s == null) {
      title = tr('auto_name');
      sub = tr('auto_desc');
      flag = '⚡';
    } else {
      title = s.name;
      flag = flagEmoji(s.country);
      final base = '${countryLabel(s.country, lang)} · ${s.protocol}';
      sub = (c.phase == VpnPhase.connected && auto)
          ? '$base · ${tr('auto_conn_tag')}'
          : base;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Material(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ServersPage(controller: c)),
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.purple.withValues(alpha: 0.3)),
            ),
            child: Row(
              children: [
                Text(flag, style: const TextStyle(fontSize: 30)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: AppColors.text,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        sub,
                        style: TextStyle(color: AppColors.muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                if (s != null && s.ping != null) PingBadge(ping: s.ping),
                const SizedBox(width: 6),
                Icon(Icons.chevron_right_rounded, color: AppColors.purpleLight),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _statsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          Expanded(
            child: _stat(Icons.arrow_downward_rounded, tr('download'),
                '${fmtBytes(c.downloadSpeed)}/s'),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _stat(Icons.arrow_upward_rounded, tr('upload'),
                '${fmtBytes(c.uploadSpeed)}/s'),
          ),
        ],
      ),
    );
  }

  Widget _stat(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.purple.withValues(alpha: 0.18)),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.purpleLight, size: 20),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(color: AppColors.muted, fontSize: 11)),
              Text(
                value,
                textDirection: TextDirection.ltr,
                style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RingsPainter extends CustomPainter {
  _RingsPainter({
    required this.t,
    required this.color,
    required this.light,
    required this.active,
    required this.busy,
  });

  final double t;
  final Color color;
  final Color light;
  final bool active;
  final bool busy;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);

    for (var i = 0; i < 2; i++) {
      canvas.drawCircle(
        center,
        96.0 + i * 18,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = color.withValues(alpha: active ? 0.28 - i * 0.1 : 0.14 - i * 0.05),
      );
    }

    final waves = busy ? 3 : (active ? 2 : 1);
    for (var i = 0; i < waves; i++) {
      final p = (t + i / waves) % 1.0;
      canvas.drawCircle(
        center,
        76 + p * 52,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = color.withValues(alpha: (1 - p) * (active ? 0.45 : 0.18)),
      );
    }

    if (busy) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: 108),
        t * 2 * math.pi,
        math.pi / 2,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 4
          ..color = light,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RingsPainter old) => true;
}
