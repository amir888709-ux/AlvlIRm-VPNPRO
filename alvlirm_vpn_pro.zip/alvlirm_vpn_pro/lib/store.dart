import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

/// ذخیره‌ی تنظیمات و داده‌ها روی گوشی
class Store {
  Store(this._p);
  final SharedPreferences _p;

  static Future<Store> open() async => Store(await SharedPreferences.getInstance());

  List<String> _list(String k) =>
      List<String>.from(_p.getStringList(k) ?? const <String>[]);

  // --- سرورها
  List<String> get manual => _list('custom');
  Future<void> setManual(List<String> v) => _p.setStringList('custom', v);

  String get officialVer => _p.getString('official_ver') ?? '';
  Future<void> setOfficialVer(String v) => _p.setString('official_ver', v);

  String get dnsKey => _p.getString('dnsKey') ?? 'default';
  Future<void> setDnsKey(String v) => _p.setString('dnsKey', v);

  String get dnsCustom => _p.getString('dnsCustom') ?? '';
  Future<void> setDnsCustom(String v) => _p.setString('dnsCustom', v);

  bool get gaming => _p.getBool('gaming') ?? false;
  Future<void> setGaming(bool v) => _p.setBool('gaming', v);

  String get dismissedUpd => _p.getString('dismissedUpd') ?? '';
  Future<void> setDismissedUpd(String v) => _p.setString('dismissedUpd', v);

  String get donate => _p.getString('donate') ?? '';
  Future<void> setDonate(String v) => _p.setString('donate', v);

  /// زمان بعدی که پیام حمایت مالی اجازه‌ی نمایش دارد (میلی‌ثانیه)
  int get donateNext => _p.getInt('donateNext') ?? 0;
  Future<void> setDonateNext(int v) => _p.setInt('donateNext', v);

  String get appMode => _p.getString('appMode') ?? 'vpn';
  Future<void> setAppMode(String v) => _p.setString('appMode', v);

  String get dnsPurpose => _p.getString('dnsPurpose') ?? 'conn';
  Future<void> setDnsPurpose(String v) => _p.setString('dnsPurpose', v);

  String get dnsGameKey => _p.getString('dnsGameKey') ?? 'shecan';
  Future<void> setDnsGameKey(String v) => _p.setString('dnsGameKey', v);

  String get dnsGameCustom => _p.getString('dnsGameCustom') ?? '';
  Future<void> setDnsGameCustom(String v) => _p.setString('dnsGameCustom', v);

  String get channel => _p.getString('channel') ?? '';
  Future<void> setChannel(String v) => _p.setString('channel', v);

  String get officialBlob => _p.getString('official_blob') ?? '';
  Future<void> setOfficialBlob(String v) => _p.setString('official_blob', v);

  // --- ساب‌ها (هر مورد یک JSON)
  List<String> get subs => _list('subs');
  Future<void> setSubs(List<String> v) => _p.setStringList('subs', v);
  String subLinks(String id) => _p.getString('sub_$id') ?? '';
  Future<void> setSubLinks(String id, String v) => _p.setString('sub_$id', v);
  Future<void> removeSubLinks(String id) => _p.remove('sub_$id');

  // --- علاقه‌مندی و انتخاب
  List<String> get favorites => _list('fav');
  Future<void> setFavorites(List<String> v) => _p.setStringList('fav', v);

  String? get selected => _p.getString('selected');
  Future<void> setSelected(String? v) =>
      v == null ? _p.remove('selected') : _p.setString('selected', v);

  /// کشور خروجی تشخیص‌داده‌شده‌ی سرورهای Aether (هر مورد «شناسه=کد»)
  List<String> get exitList => _list('exitc');
  Future<void> setExitList(List<String> v) => _p.setStringList('exitc', v);

  /// زمان آماده‌شدن آخرین اتصال موفق هر سرور Aether (هر مورد «شناسه=میلی‌ثانیه»)
  List<String> get okList => _list('okms');
  Future<void> setOkList(List<String> v) => _p.setStringList('okms', v);

  bool get autoSwitch => _p.getBool('autoSwitch') ?? true;
  Future<void> setAutoSwitch(bool v) => _p.setBool('autoSwitch', v);

  bool get hotStandby => _p.getBool('hotStandby') ?? true;
  Future<void> setHotStandby(bool v) => _p.setBool('hotStandby', v);

  // --- تنظیمات
  bool get autoConnect => _p.getBool('autoConnect') ?? false;
  Future<void> setAutoConnect(bool v) => _p.setBool('autoConnect', v);

  bool get bypassLan => _p.getBool('bypassLan') ?? false;
  Future<void> setBypassLan(bool v) => _p.setBool('bypassLan', v);

  bool get proxyOnly => _p.getBool('proxyOnly') ?? false;
  Future<void> setProxyOnly(bool v) => _p.setBool('proxyOnly', v);

  String get testUrlKey => _p.getString('testUrlKey') ?? 'Google';
  Future<void> setTestUrlKey(String v) => _p.setString('testUrlKey', v);

  int get timeoutSec => _p.getInt('timeoutSec') ?? 10;
  Future<void> setTimeoutSec(int v) => _p.setInt('timeoutSec', v);

  /// 0 = خاموش
  int get subHours => _p.getInt('subHours') ?? 6;
  Future<void> setSubHours(int v) => _p.setInt('subHours', v);

  String? get lang => _p.getString('lang');
  Future<void> setLang(String v) => _p.setString('lang', v);

  String get theme => _p.getString('theme') ?? 'night';
  Future<void> setTheme(String v) => _p.setString('theme', v);

  bool get welcomed => _p.getBool('welcomed') ?? false;
  Future<void> setWelcomed(bool v) => _p.setBool('welcomed', v);

  String get dismissedAnn => _p.getString('dismissedAnn') ?? '';
  Future<void> setDismissedAnn(String v) => _p.setString('dismissedAnn', v);

  /// شناسه‌ی ناشناس دستگاه (فقط برای شمارش کاربران)
  String get deviceId {
    var id = _p.getString('deviceId');
    if (id == null || id.length < 8) {
      final r = Random.secure();
      id = List.generate(16, (_) => r.nextInt(16).toRadixString(16)).join();
      _p.setString('deviceId', id);
    }
    return id;
  }
}
