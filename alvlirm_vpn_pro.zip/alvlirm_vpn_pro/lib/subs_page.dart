import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

class SubsPage extends StatelessWidget {
  const SubsPage({super.key, required this.controller});
  final VpnController controller;

  VpnController get c => controller;

  String _when(int ms) {
    if (ms <= 0) return tr('never');
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  Future<void> _add(BuildContext context) async {
    final name = TextEditingController();
    final url = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.card,
        title: Text(tr('add_sub'),
            style: TextStyle(color: AppColors.text, fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: url,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: AppColors.text),
              decoration: InputDecoration(
                hintText: tr('sub_url'),
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: name,
              style: TextStyle(color: AppColors.text),
              decoration: InputDecoration(
                hintText: tr('sub_name'),
                border: const OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('add_sub')),
          ),
        ],
      ),
    );
    final n = name.text;
    final u = url.text;
    name.dispose();
    url.dispose();
    if (go != true) return;
    if (context.mounted) toast(context, tr('testing'));
    final err = await c.addSub(n, u);
    if (!context.mounted) return;
    toast(context, err == null ? tr('refreshed') : tr(err));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: Text(tr('subs_title')),
          actions: [
            c.updatingSubs
                ? const Padding(
                    padding: EdgeInsets.all(14),
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  )
                : IconButton(
                    tooltip: tr('update_all'),
                    icon: const Icon(Icons.sync_rounded),
                    onPressed: c.updateAllSubs,
                  ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _add(context),
          icon: const Icon(Icons.add_link_rounded),
          label: Text(tr('add_sub')),
        ),
        body: c.subs.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Text(
                    '${tr('no_subs')}\n\n${tr('sub_hint')}',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.muted),
                  ),
                ),
              )
            : ListView(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
                children: [
                  for (final s in c.subs)
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: AppColors.purple.withValues(alpha: 0.18),
                        ),
                      ),
                      child: ListTile(
                        leading: Icon(Icons.link_rounded,
                            color: AppColors.purpleLight),
                        title: Text(s.name,
                            style: TextStyle(
                                color: AppColors.text,
                                fontWeight: FontWeight.w700)),
                        subtitle: Text(
                          '${tr('servers_n', [s.count])}\n${tr('updated_at', [_when(s.updated)])}',
                          style: TextStyle(color: AppColors.muted, fontSize: 12),
                        ),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                          icon: Icon(Icons.more_vert_rounded,
                              color: AppColors.muted),
                          onSelected: (v) async {
                            if (v == 'update') {
                              final n = await c.updateSub(s);
                              if (!context.mounted) return;
                              toast(context,
                                  n == null ? tr('refresh_failed') : tr('sub_updated_n', [n]));
                            } else if (v == 'copy') {
                              await Clipboard.setData(ClipboardData(text: s.url));
                              if (context.mounted) toast(context, tr('link_copied'));
                            } else if (v == 'qr') {
                              await showQr(context, s.name, s.url);
                            } else if (v == 'delete') {
                              await c.removeSub(s);
                              if (context.mounted) toast(context, tr('sub_removed'));
                            }
                          },
                          itemBuilder: (_) => [
                            PopupMenuItem(value: 'update', child: Text(tr('update'))),
                            PopupMenuItem(value: 'copy', child: Text(tr('copy_link'))),
                            PopupMenuItem(value: 'qr', child: Text(tr('show_qr'))),
                            PopupMenuItem(value: 'delete', child: Text(tr('delete'))),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}
