import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'aether.dart';
import 'i18n.dart';
import 'theme.dart';
import 'vpn_controller.dart';
import 'widgets.dart';

/// صفحه‌ی ساخت سرور Aether با همه‌ی گزینه‌ها (خروجی: یک لینک aether://)
Future<void> openAetherBuilder(BuildContext context, VpnController c) {
  return Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => AetherBuilderPage(controller: c)),
  );
}

class AetherBuilderPage extends StatefulWidget {
  const AetherBuilderPage({super.key, required this.controller});
  final VpnController controller;

  @override
  State<AetherBuilderPage> createState() => _AetherBuilderPageState();
}

class _AetherBuilderPageState extends State<AetherBuilderPage> {
  VpnController get c => widget.controller;

  static const List<String> _textKeys = [
    'name',
    'peer',
    'outer',
    'inner',
    'sni',
    'dns',
    'exit_loc',
    'region',
    'cdn_ips',
    'cdn_sni',
    'cdn_sets',
    'api_address',
    'api_sni',
    'api_host',
    'cmd',
  ];

  final Map<String, TextEditingController> _t = {};

  String _protocol = 'masque';
  String _scanMode = 'balanced';
  String _noize = 'auto';
  String _ip = 'both';
  String _transport = 'auto';
  String _psiphon = 'off';
  String _pmode = 'auto';
  bool _fragment = false;
  bool _bundled = true;
  bool _busyKey = false;
  bool _busyScan = false;
  String _keyMsg = '';

  @override
  void initState() {
    super.initState();
    for (final k in _textKeys) {
      _t[k] = TextEditingController();
    }
    _t['name']!.text = 'Aether';
  }

  @override
  void dispose() {
    for (final x in _t.values) {
      x.dispose();
    }
    super.dispose();
  }

  String _v(String key) => (_t[key]?.text ?? '').trim();

  String _link() {
    final q = <String, String>{};
    q['protocol'] = _protocol;
    q['scan'] = _scanMode;
    q['ip'] = _ip;
    if (_transport != 'auto') q['transport'] = _transport;
    if (_noize != 'auto') q['noize'] = _noize;
    void put(String param, String key) {
      final x = _v(key);
      if (x.isNotEmpty) q[param] = x;
    }

    if (_protocol == 'mim') {
      put('outer', 'outer');
      put('inner', 'inner');
    }
    put('sni', 'sni');
    put('dns', 'dns');
    put('exit_loc', 'exit_loc');
    if (_fragment) q['fragment'] = '1';
    if (_psiphon != 'off') {
      q['psiphon'] = _psiphon;
      q['psiphon_mode'] = _pmode;
      put('region', 'region');
      put('cdn_ips', 'cdn_ips');
      put('cdn_sni', 'cdn_sni');
      put('cdn_sets', 'cdn_sets');
      if (!_bundled) q['bundled'] = '0';
    }
    put('api_address', 'api_address');
    put('api_sni', 'api_sni');
    put('api_host', 'api_host');
    put('cmd', 'cmd');
    final auth = _protocol == 'mim' ? '' : _v('peer');
    final name = _v('name');
    final tail = name.isEmpty ? '' : '#${Uri.encodeComponent(name)}';
    return 'aether://$auth?${Uri(queryParameters: q).query}$tail';
  }

  Future<void> _create() async {
    final link = _link();
    if (parseAetherLink(link) == null) {
      toast(context, tr('aether_bad'));
      return;
    }
    final r = await c.addLinks(link);
    if (!mounted) return;
    toast(context, r.added > 0 ? tr('added_n', [r.added]) : tr('nothing_new'));
    if (r.added > 0) Navigator.pop(context);
  }

  Future<void> _copy() async {
    final link = _link();
    if (parseAetherLink(link) == null) {
      toast(context, tr('aether_bad'));
      return;
    }
    await Clipboard.setData(ClipboardData(text: link));
    if (mounted) toast(context, tr('aether_copied'));
  }

  Future<void> _reset() async {
    final yes = await confirmDialog(context, tr('aether_reset_ask'));
    if (!yes) return;
    final ok = await c.resetAetherData();
    if (mounted) toast(context, ok ? tr('aether_reset_done') : tr('admin_fail'));
  }

  bool _aetherBusy() {
    if (AetherRunner.running) {
      toast(context, tr('aether_busy'));
      return true;
    }
    return false;
  }

  Future<void> _getKey() async {
    if (_busyKey || _busyScan || _aetherBusy()) return;
    setState(() {
      _busyKey = true;
      _keyMsg = '';
    });
    final err = await AetherRunner.registerKey(_protocol, {
      'fragment': _fragment ? '1' : '',
      'api_address': _v('api_address'),
      'api_sni': _v('api_sni'),
      'api_host': _v('api_host'),
    });
    if (!mounted) return;
    setState(() {
      _busyKey = false;
      _keyMsg = err;
    });
    toast(context, err.isEmpty ? tr('aether_key_ok') : tr('aether_key_fail'));
  }

  Future<void> _scan() async {
    if (_busyKey || _busyScan || _aetherBusy()) return;
    if (c.phase == VpnPhase.connected ||
        c.phase == VpnPhase.connecting ||
        c.phase == VpnPhase.searching) {
      toast(context, tr('aether_busy'));
      return;
    }
    final spec = parseAetherLink(_link());
    if (spec == null) {
      toast(context, tr('aether_bad'));
      return;
    }
    setState(() {
      _busyScan = true;
      _keyMsg = '';
    });
    final r = await AetherRunner.scan(spec);
    if (!mounted) return;
    setState(() {
      _busyScan = false;
      if (r == null) {
        _keyMsg = AetherRunner.summary();
      } else if (_protocol == 'mim') {
        final parts = r.split('|');
        _t['outer']!.text = parts[0];
        _t['inner']!.text = parts.length > 1 ? parts[1] : '';
      } else {
        _t['peer']!.text = r;
      }
    });
    toast(context,
        r == null ? tr('aether_scan_fail') : '${tr('aether_scan_ok')} $r');
  }

  Widget _keySection() {
    final k = AetherRunner.keyInfo(_protocol);
    final busy = _busyKey || _busyScan;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _title('WARP key'),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    k == null
                        ? Icons.warning_amber_rounded
                        : Icons.check_circle_rounded,
                    size: 18,
                    color: k == null ? AppColors.warn : AppColors.ok,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    k == null ? tr('aether_key_none') : tr('aether_key_ready'),
                    style: TextStyle(
                        color: AppColors.text, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              if (k != null) const SizedBox(height: 6),
              if (k != null)
                SelectableText(
                  k.where((e) => e.isNotEmpty).join('\n'),
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: AppColors.muted, fontSize: 12),
                ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(tr('aether_key_hint'),
            style: TextStyle(color: AppColors.muted, fontSize: 12)),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: busy ? null : _getKey,
          icon: _busyKey
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.vpn_key_rounded),
          label: Text(tr('aether_get_key')),
        ),
        const SizedBox(height: 14),
        Text(tr('aether_scan_hint'),
            style: TextStyle(color: AppColors.muted, fontSize: 12)),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: busy ? null : _scan,
          icon: _busyScan
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.travel_explore_rounded),
          label: Text(tr('aether_scan')),
        ),
        ListenableBuilder(
          listenable: c,
          builder: (context, _) => (busy && c.aetherLive.isNotEmpty)
              ? Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    c.aetherLive,
                    textDirection: TextDirection.ltr,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: AppColors.muted, fontSize: 11),
                  ),
                )
              : const SizedBox.shrink(),
        ),
        if (_keyMsg.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: SelectableText(
              _keyMsg,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: AppColors.bad, fontSize: 11),
            ),
          ),
      ],
    );
  }

  InputDecoration _dec(String label, [String hint = '']) => InputDecoration(
        labelText: label,
        hintText: hint.isEmpty ? null : hint,
        filled: true,
        fillColor: AppColors.card,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      );

  Widget _title(String text) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 8),
        child: Text(
          text,
          style: TextStyle(
            color: AppColors.purpleLight,
            fontWeight: FontWeight.w700,
            fontSize: 14,
          ),
        ),
      );

  Widget _field(String label, String key, [String hint = '']) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: _t[key],
          textDirection: TextDirection.ltr,
          style: TextStyle(color: AppColors.text),
          decoration: _dec(label, hint),
        ),
      );

  Widget _drop(
    String label,
    String value,
    List<String> items,
    void Function(String) onPick,
  ) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InputDecorator(
          decoration: _dec(label),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              isDense: true,
              dropdownColor: AppColors.card,
              style: TextStyle(color: AppColors.text, fontSize: 15),
              items: items
                  .map((e) => DropdownMenuItem<String>(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) {
                if (v != null) setState(() => onPick(v));
              },
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final mim = _protocol == 'mim';
    final psi = _psiphon != 'off';
    return Scaffold(
      appBar: AppBar(title: Text(tr('aether_new'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Text(tr('aether_hint'),
              style: TextStyle(color: AppColors.muted, fontSize: 12)),
          _title('Aether'),
          _field('Name', 'name'),
          _drop('Aether protocol', _protocol, const ['masque', 'wg', 'gool', 'mim'],
              (v) => _protocol = v),
          if (!mim) _field('Endpoint (IP:PORT, optional)', 'peer', '162.159.198.240:4443'),
          if (mim) _field('Outer hop (IP:PORT)', 'outer'),
          if (mim) _field('Inner hop (IP:PORT)', 'inner'),
          _drop(
              'Scan mode',
              _scanMode,
              const ['turbo', 'balanced', 'thorough', 'verified', 'ironclad'],
              (v) => _scanMode = v),
          _drop(
              'Obfuscation',
              _noize,
              const ['auto', 'off', 'light', 'firewall', 'balanced', 'gfw', 'aggressive'],
              (v) => _noize = v),
          _drop('IP version', _ip, const ['both', 'v4', 'v6'], (v) => _ip = v),
          _drop('Transport', _transport, const ['auto', 'h2', 'h3'],
              (v) => _transport = v),
          _field('MASQUE SNI (default www.cloudflare.com)', 'sni'),
          _field('Resolvers', 'dns', '1.1.1.1,1.0.0.1'),
          _field('Exit country filter', 'exit_loc', '!IR,RU  /  DE,SE'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Fragment TLS ClientHello',
                style: TextStyle(color: AppColors.text)),
            value: _fragment,
            onChanged: (v) => setState(() => _fragment = v),
          ),
          _keySection(),
          _title('Psiphon'),
          _drop('Psiphon', _psiphon, const ['off', 'chain', 'reverse', 'only'],
              (v) => _psiphon = v),
          if (psi) _drop('Psiphon mode', _pmode, const ['auto', 'cdn', 'direct'],
              (v) => _pmode = v),
          if (psi) _field('Psiphon region (e.g. DE)', 'region'),
          if (psi) _field('Psiphon CDN IPs', 'cdn_ips'),
          if (psi) _field('Psiphon CDN server name', 'cdn_sni'),
          if (psi) _field('Psiphon CDN edge lists', 'cdn_sets'),
          if (psi)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('Use the bundled server list',
                  style: TextStyle(color: AppColors.text)),
              value: _bundled,
              onChanged: (v) => setState(() => _bundled = v),
            ),
          _title('WARP API'),
          _field('WARP API address', 'api_address'),
          _field('WARP API server name (SNI)', 'api_sni'),
          _field('WARP API host', 'api_host'),
          _title('Advanced'),
          _field('Aether command, used in place of these settings', 'cmd',
              '--masque --h2 --scan turbo'),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _create,
            icon: const Icon(Icons.add_rounded),
            label: Text(tr('aether_create')),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _copy,
            icon: const Icon(Icons.copy_rounded),
            label: Text(tr('aether_copy')),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: _reset,
            icon: const Icon(Icons.restart_alt_rounded),
            label: Text(tr('aether_reset')),
          ),
        ],
      ),
    );
  }
}
